verilator.o: \
 /home/abdulbasit/electrical-and-electronics-engineering/VLSI/isqed-2026-dv-challenge/.venv/lib/python3.12/site-packages/cocotb/share/lib/verilator/verilator.cpp \
 Vtop.h /home/abdulbasit/open-source/verilator/include/verilated.h \
 /home/abdulbasit/open-source/verilator/include/verilated_config.h \
 /home/abdulbasit/open-source/verilator/include/verilatedos.h \
 /home/abdulbasit/open-source/verilator/include/verilated_types.h \
 /home/abdulbasit/open-source/verilator/include/verilated_funcs.h \
 /home/abdulbasit/open-source/verilator/include/verilated_cov.h \
 /home/abdulbasit/open-source/verilator/include/verilated.h \
 /home/abdulbasit/open-source/verilator/include/vltstd/svdpi.h \
 /home/abdulbasit/open-source/verilator/include/verilated_vpi.h \
 /home/abdulbasit/open-source/verilator/include/verilated_syms.h \
 /home/abdulbasit/open-source/verilator/include/verilated_sym_props.h \
 /home/abdulbasit/open-source/verilator/include/vltstd/sv_vpi_user.h \
 /home/abdulbasit/open-source/verilator/include/vltstd/vpi_user.h
