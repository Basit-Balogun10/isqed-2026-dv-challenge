// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vtop.h for the primary calling header

#ifndef VERILATED_VTOP_DV_COMMON_PKG_H_
#define VERILATED_VTOP_DV_COMMON_PKG_H_  // guard

#include "verilated.h"
#include "verilated_cov.h"


class Vtop__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vtop_dv_common_pkg final {
  public:

    // INTERNAL VARIABLES
    Vtop__Syms* vlSymsp;
    const char* vlNamep;

    // PARAMETERS
    static constexpr CData/*2:0*/ TL_OP_PUT_FULL = 0U;
    static constexpr CData/*2:0*/ TL_OP_PUT_PARTIAL = 1U;
    static constexpr CData/*2:0*/ TL_OP_GET = 4U;
    static constexpr CData/*2:0*/ TL_OP_ACCESS_ACK = 0U;
    static constexpr CData/*2:0*/ TL_OP_ACCESS_ACK_DATA = 1U;

    // CONSTRUCTORS
    Vtop_dv_common_pkg();
    ~Vtop_dv_common_pkg();
    void ctor(Vtop__Syms* symsp, const char* namep);
    void dtor();
    VL_UNCOPYABLE(Vtop_dv_common_pkg);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
    void __vlCoverInsert(uint32_t* countp, bool enable, const char* filenamep, int lineno, int column,
        const char* hierp, const char* pagep, const char* commentp, const char* linescovp);
    void __vlCoverToggleInsert(int begin, int end, bool ranged, uint32_t* countp, bool enable, const char* filenamep, int lineno, int column,
        const char* hierp, const char* pagep, const char* commentp);
};


#endif  // guard
