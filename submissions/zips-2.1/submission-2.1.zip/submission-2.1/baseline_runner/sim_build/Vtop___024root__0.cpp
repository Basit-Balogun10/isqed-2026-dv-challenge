// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtop.h for the primary calling header

#include "Vtop__pch.h"

void Vtop___024root___eval_triggers_vec__ico(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_triggers_vec__ico\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VicoTriggered[0U] = ((0xfffffffffffffffeULL 
                                      & vlSelfRef.__VicoTriggered[0U]) 
                                     | (IData)((IData)(vlSelfRef.__VicoFirstIteration)));
}

bool Vtop___024root___trigger_anySet__ico(const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___trigger_anySet__ico\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

void Vtop___024root___ico_sequent__TOP__0(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___ico_sequent__TOP__0\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ rampart_i2c__DOT____VdfgExtracted_h748dde20__0;
    rampart_i2c__DOT____VdfgExtracted_h748dde20__0 = 0;
    CData/*0:0*/ rampart_i2c__DOT____VdfgExtracted_he4f4c8eb__0;
    rampart_i2c__DOT____VdfgExtracted_he4f4c8eb__0 = 0;
    CData/*0:0*/ __VdfgRegularize_h6e95ff9d_0_1;
    __VdfgRegularize_h6e95ff9d_0_1 = 0;
    CData/*0:0*/ __VdfgRegularize_h6e95ff9d_0_5;
    __VdfgRegularize_h6e95ff9d_0_5 = 0;
    CData/*0:0*/ __VdfgRegularize_h6e95ff9d_0_6;
    __VdfgRegularize_h6e95ff9d_0_6 = 0;
    // Body
    if ((((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr) 
                 >> 6U)) != (1U & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr) 
                                   >> 6U))) & ((0x0000003fU 
                                                & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr)) 
                                               == (0x0000003fU 
                                                   & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr))))) {
        ++(vlSymsp->__Vcoverage[1869]);
    }
    if (((0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr)) 
         != (0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr)))) {
        ++(vlSymsp->__Vcoverage[1870]);
    }
    if (((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr) 
                >> 6U)) == (1U & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr) 
                                  >> 6U)))) {
        ++(vlSymsp->__Vcoverage[1871]);
    }
    ++(vlSymsp->__Vcoverage[1872]);
    if ((((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr) 
                 >> 6U)) != (1U & ((IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr) 
                                   >> 6U))) & ((0x0000003fU 
                                                & (IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr)) 
                                               == (0x0000003fU 
                                                   & (IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr))))) {
        ++(vlSymsp->__Vcoverage[1894]);
    }
    if (((0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr)) 
         != (0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr)))) {
        ++(vlSymsp->__Vcoverage[1895]);
    }
    if (((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr) 
                >> 6U)) == (1U & ((IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr) 
                                  >> 6U)))) {
        ++(vlSymsp->__Vcoverage[1896]);
    }
    ++(vlSymsp->__Vcoverage[1897]);
    if ((((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr) 
                 >> 6U)) != (1U & ((IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr) 
                                   >> 6U))) & ((0x0000003fU 
                                                & (IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr)) 
                                               == (0x0000003fU 
                                                   & (IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr))))) {
        ++(vlSymsp->__Vcoverage[1919]);
    }
    if (((0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr)) 
         != (0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr)))) {
        ++(vlSymsp->__Vcoverage[1920]);
    }
    if (((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr) 
                >> 6U)) == (1U & ((IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr) 
                                  >> 6U)))) {
        ++(vlSymsp->__Vcoverage[1921]);
    }
    ++(vlSymsp->__Vcoverage[1922]);
    if ((((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr) 
                 >> 6U)) != (1U & ((IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr) 
                                   >> 6U))) & ((0x0000003fU 
                                                & (IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr)) 
                                               == (0x0000003fU 
                                                   & (IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr))))) {
        ++(vlSymsp->__Vcoverage[1944]);
    }
    if (((0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr)) 
         != (0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr)))) {
        ++(vlSymsp->__Vcoverage[1945]);
    }
    if (((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr) 
                >> 6U)) == (1U & ((IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr) 
                                  >> 6U)))) {
        ++(vlSymsp->__Vcoverage[1946]);
    }
    ++(vlSymsp->__Vcoverage[1947]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_d_valid_o) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_valid_o))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 170, vlSelfRef.rampart_i2c__DOT__tl_d_valid_o, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_valid_o);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_valid_o 
            = vlSelfRef.rampart_i2c__DOT__tl_d_valid_o;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_d_opcode_o) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_opcode_o))) {
        VL_COV_TOGGLE_CHG_ST_I(3, vlSymsp->__Vcoverage + 174, vlSelfRef.rampart_i2c__DOT__tl_d_opcode_o, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_opcode_o);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_opcode_o 
            = vlSelfRef.rampart_i2c__DOT__tl_d_opcode_o;
    }
    if ((vlSelfRef.rampart_i2c__DOT__tl_d_data_o ^ vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_data_o)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 180, vlSelfRef.rampart_i2c__DOT__tl_d_data_o, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_data_o);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_data_o 
            = vlSelfRef.rampart_i2c__DOT__tl_d_data_o;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_d_source_o) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_source_o))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 244, vlSelfRef.rampart_i2c__DOT__tl_d_source_o, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_source_o);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_source_o 
            = vlSelfRef.rampart_i2c__DOT__tl_d_source_o;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_d_error_o) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_error_o))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 260, vlSelfRef.rampart_i2c__DOT__tl_d_error_o, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_error_o);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_error_o 
            = vlSelfRef.rampart_i2c__DOT__tl_d_error_o;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_host_enable))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 304, vlSelfRef.rampart_i2c__DOT__ctrl_host_enable, vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_host_enable);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_host_enable 
            = vlSelfRef.rampart_i2c__DOT__ctrl_host_enable;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_target_enable))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 306, vlSelfRef.rampart_i2c__DOT__ctrl_target_enable, vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_target_enable);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_target_enable 
            = vlSelfRef.rampart_i2c__DOT__ctrl_target_enable;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_line_loopback) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_line_loopback))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 308, vlSelfRef.rampart_i2c__DOT__ctrl_line_loopback, vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_line_loopback);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_line_loopback 
            = vlSelfRef.rampart_i2c__DOT__ctrl_line_loopback;
    }
    if ((vlSelfRef.rampart_i2c__DOT__ctrl_reg ^ vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_reg)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 310, vlSelfRef.rampart_i2c__DOT__ctrl_reg, vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_reg);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_reg 
            = vlSelfRef.rampart_i2c__DOT__ctrl_reg;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_tlow) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tlow))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 374, vlSelfRef.rampart_i2c__DOT__timing_tlow, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tlow);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tlow 
            = vlSelfRef.rampart_i2c__DOT__timing_tlow;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_thigh) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_thigh))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 406, vlSelfRef.rampart_i2c__DOT__timing_thigh, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_thigh);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_thigh 
            = vlSelfRef.rampart_i2c__DOT__timing_thigh;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_t_r) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_t_r))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 438, vlSelfRef.rampart_i2c__DOT__timing_t_r, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_t_r);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_t_r 
            = vlSelfRef.rampart_i2c__DOT__timing_t_r;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_t_f) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_t_f))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 470, vlSelfRef.rampart_i2c__DOT__timing_t_f, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_t_f);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_t_f 
            = vlSelfRef.rampart_i2c__DOT__timing_t_f;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_tsu_sta) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tsu_sta))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 502, vlSelfRef.rampart_i2c__DOT__timing_tsu_sta, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tsu_sta);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tsu_sta 
            = vlSelfRef.rampart_i2c__DOT__timing_tsu_sta;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_thd_sta) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_thd_sta))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 534, vlSelfRef.rampart_i2c__DOT__timing_thd_sta, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_thd_sta);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_thd_sta 
            = vlSelfRef.rampart_i2c__DOT__timing_thd_sta;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_tsu_dat) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tsu_dat))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 566, vlSelfRef.rampart_i2c__DOT__timing_tsu_dat, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tsu_dat);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tsu_dat 
            = vlSelfRef.rampart_i2c__DOT__timing_tsu_dat;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_thd_dat) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_thd_dat))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 598, vlSelfRef.rampart_i2c__DOT__timing_thd_dat, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_thd_dat);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_thd_dat 
            = vlSelfRef.rampart_i2c__DOT__timing_thd_dat;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_tsu_sto) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tsu_sto))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 630, vlSelfRef.rampart_i2c__DOT__timing_tsu_sto, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tsu_sto);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tsu_sto 
            = vlSelfRef.rampart_i2c__DOT__timing_tsu_sto;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_t_buf) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_t_buf))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 662, vlSelfRef.rampart_i2c__DOT__timing_t_buf, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_t_buf);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_t_buf 
            = vlSelfRef.rampart_i2c__DOT__timing_t_buf;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__target_address) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__target_address))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 694, vlSelfRef.rampart_i2c__DOT__target_address, vlSelfRef.rampart_i2c__DOT____Vtogcov__target_address);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__target_address 
            = vlSelfRef.rampart_i2c__DOT__target_address;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__target_mask) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__target_mask))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 708, vlSelfRef.rampart_i2c__DOT__target_mask, vlSelfRef.rampart_i2c__DOT____Vtogcov__target_mask);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__target_mask 
            = vlSelfRef.rampart_i2c__DOT__target_mask;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__ovrd_txovrden) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__ovrd_txovrden))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 722, vlSelfRef.rampart_i2c__DOT__ovrd_txovrden, vlSelfRef.rampart_i2c__DOT____Vtogcov__ovrd_txovrden);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__ovrd_txovrden 
            = vlSelfRef.rampart_i2c__DOT__ovrd_txovrden;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__ovrd_sclval) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__ovrd_sclval))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 724, vlSelfRef.rampart_i2c__DOT__ovrd_sclval, vlSelfRef.rampart_i2c__DOT____Vtogcov__ovrd_sclval);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__ovrd_sclval 
            = vlSelfRef.rampart_i2c__DOT__ovrd_sclval;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__ovrd_sdaval) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__ovrd_sdaval))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 726, vlSelfRef.rampart_i2c__DOT__ovrd_sdaval, vlSelfRef.rampart_i2c__DOT____Vtogcov__ovrd_sdaval);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__ovrd_sdaval 
            = vlSelfRef.rampart_i2c__DOT__ovrd_sdaval;
    }
    if ((vlSelfRef.rampart_i2c__DOT__host_timeout_val 
         ^ vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_val)) {
        VL_COV_TOGGLE_CHG_ST_I(20, vlSymsp->__Vcoverage + 728, vlSelfRef.rampart_i2c__DOT__host_timeout_val, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_val);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_val 
            = vlSelfRef.rampart_i2c__DOT__host_timeout_val;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_timeout_en) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_en))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 768, vlSelfRef.rampart_i2c__DOT__host_timeout_en, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_en);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_en 
            = vlSelfRef.rampart_i2c__DOT__host_timeout_en;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__intr_state) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_state))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 770, vlSelfRef.rampart_i2c__DOT__intr_state, vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_state);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_state 
            = vlSelfRef.rampart_i2c__DOT__intr_state;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__intr_enable) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_enable))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 802, vlSelfRef.rampart_i2c__DOT__intr_enable, vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_enable);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_enable 
            = vlSelfRef.rampart_i2c__DOT__intr_enable;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_wptr))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 866, vlSelfRef.rampart_i2c__DOT__fmt_wptr, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_wptr);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_wptr 
            = vlSelfRef.rampart_i2c__DOT__fmt_wptr;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_rptr))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 880, vlSelfRef.rampart_i2c__DOT__fmt_rptr, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_rptr);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_rptr 
            = vlSelfRef.rampart_i2c__DOT__fmt_rptr;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_wptr))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 968, vlSelfRef.rampart_i2c__DOT__rx_wptr, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_wptr);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_wptr 
            = vlSelfRef.rampart_i2c__DOT__rx_wptr;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_rptr))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 982, vlSelfRef.rampart_i2c__DOT__rx_rptr, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_rptr);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_rptr 
            = vlSelfRef.rampart_i2c__DOT__rx_rptr;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_wptr))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 1050, vlSelfRef.rampart_i2c__DOT__tx_wptr, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_wptr);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_wptr 
            = vlSelfRef.rampart_i2c__DOT__tx_wptr;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_rptr))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 1064, vlSelfRef.rampart_i2c__DOT__tx_rptr, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_rptr);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_rptr 
            = vlSelfRef.rampart_i2c__DOT__tx_rptr;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_pop) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_pop))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1098, vlSelfRef.rampart_i2c__DOT__tx_fifo_pop, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_pop);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_pop 
            = vlSelfRef.rampart_i2c__DOT__tx_fifo_pop;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_wptr))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 1132, vlSelfRef.rampart_i2c__DOT__acq_wptr, vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_wptr);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_wptr 
            = vlSelfRef.rampart_i2c__DOT__acq_wptr;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_rptr))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 1146, vlSelfRef.rampart_i2c__DOT__acq_rptr, vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_rptr);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_rptr 
            = vlSelfRef.rampart_i2c__DOT__acq_rptr;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_push) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_push))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1178, vlSelfRef.rampart_i2c__DOT__acq_fifo_push, vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_push);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_push 
            = vlSelfRef.rampart_i2c__DOT__acq_fifo_push;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_wdata) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_wdata))) {
        VL_COV_TOGGLE_CHG_ST_I(10, vlSymsp->__Vcoverage + 1182, vlSelfRef.rampart_i2c__DOT__acq_fifo_wdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_wdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_wdata 
            = vlSelfRef.rampart_i2c__DOT__acq_fifo_wdata;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fifo_ctrl_fmt_rst) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_fmt_rst))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1222, vlSelfRef.rampart_i2c__DOT__fifo_ctrl_fmt_rst, vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_fmt_rst);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_fmt_rst 
            = vlSelfRef.rampart_i2c__DOT__fifo_ctrl_fmt_rst;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fifo_ctrl_rx_rst) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_rx_rst))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1224, vlSelfRef.rampart_i2c__DOT__fifo_ctrl_rx_rst, vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_rx_rst);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_rx_rst 
            = vlSelfRef.rampart_i2c__DOT__fifo_ctrl_rx_rst;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fifo_ctrl_tx_rst) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_tx_rst))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1226, vlSelfRef.rampart_i2c__DOT__fifo_ctrl_tx_rst, vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_tx_rst);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_tx_rst 
            = vlSelfRef.rampart_i2c__DOT__fifo_ctrl_tx_rst;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fifo_ctrl_acq_rst) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_acq_rst))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1228, vlSelfRef.rampart_i2c__DOT__fifo_ctrl_acq_rst, vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_acq_rst);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_acq_rst 
            = vlSelfRef.rampart_i2c__DOT__fifo_ctrl_acq_rst;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_in_q))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1234, vlSelfRef.rampart_i2c__DOT__scl_in_q, vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_in_q);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_in_q 
            = vlSelfRef.rampart_i2c__DOT__scl_in_q;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_in_q))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1236, vlSelfRef.rampart_i2c__DOT__sda_in_q, vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_in_q);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_in_q 
            = vlSelfRef.rampart_i2c__DOT__sda_in_q;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_in_qq))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1238, vlSelfRef.rampart_i2c__DOT__scl_in_qq, vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_in_qq);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_in_qq 
            = vlSelfRef.rampart_i2c__DOT__scl_in_qq;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_in_qq))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1240, vlSelfRef.rampart_i2c__DOT__sda_in_qq, vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_in_qq);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_in_qq 
            = vlSelfRef.rampart_i2c__DOT__sda_in_qq;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_state) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_state))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 1250, vlSelfRef.rampart_i2c__DOT__host_state, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_state);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_state 
            = vlSelfRef.rampart_i2c__DOT__host_state;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_state) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_state))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 1258, vlSelfRef.rampart_i2c__DOT__tgt_state, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_state);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_state 
            = vlSelfRef.rampart_i2c__DOT__tgt_state;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_timing_cnt) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timing_cnt))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 1266, vlSelfRef.rampart_i2c__DOT__host_timing_cnt, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timing_cnt);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timing_cnt 
            = vlSelfRef.rampart_i2c__DOT__host_timing_cnt;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_bit_idx))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 1298, vlSelfRef.rampart_i2c__DOT__host_bit_idx, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_bit_idx);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_bit_idx 
            = vlSelfRef.rampart_i2c__DOT__host_bit_idx;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_shift_reg) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_shift_reg))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1306, vlSelfRef.rampart_i2c__DOT__host_shift_reg, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_shift_reg);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_shift_reg 
            = vlSelfRef.rampart_i2c__DOT__host_shift_reg;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_ack_received) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_ack_received))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1322, vlSelfRef.rampart_i2c__DOT__host_ack_received, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_ack_received);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_ack_received 
            = vlSelfRef.rampart_i2c__DOT__host_ack_received;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_read_byte_cnt) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_byte_cnt))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1324, vlSelfRef.rampart_i2c__DOT__host_read_byte_cnt, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_byte_cnt);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_byte_cnt 
            = vlSelfRef.rampart_i2c__DOT__host_read_byte_cnt;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_read_shift) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_shift))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1340, vlSelfRef.rampart_i2c__DOT__host_read_shift, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_shift);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_shift 
            = vlSelfRef.rampart_i2c__DOT__host_read_shift;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_read_rcont) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_rcont))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1356, vlSelfRef.rampart_i2c__DOT__host_read_rcont, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_rcont);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_rcont 
            = vlSelfRef.rampart_i2c__DOT__host_read_rcont;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_read_stop) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_stop))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1358, vlSelfRef.rampart_i2c__DOT__host_read_stop, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_stop);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_stop 
            = vlSelfRef.rampart_i2c__DOT__host_read_stop;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_arb_lost) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_arb_lost))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1386, vlSelfRef.rampart_i2c__DOT__host_arb_lost, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_arb_lost);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_arb_lost 
            = vlSelfRef.rampart_i2c__DOT__host_arb_lost;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_addr_shift) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_addr_shift))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 1388, vlSelfRef.rampart_i2c__DOT__tgt_addr_shift, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_addr_shift);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_addr_shift 
            = vlSelfRef.rampart_i2c__DOT__tgt_addr_shift;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_rw_bit) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_rw_bit))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1402, vlSelfRef.rampart_i2c__DOT__tgt_rw_bit, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_rw_bit);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_rw_bit 
            = vlSelfRef.rampart_i2c__DOT__tgt_rw_bit;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_bit_idx) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_bit_idx))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 1404, vlSelfRef.rampart_i2c__DOT__tgt_bit_idx, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_bit_idx);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_bit_idx 
            = vlSelfRef.rampart_i2c__DOT__tgt_bit_idx;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_rx_shift) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_rx_shift))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1412, vlSelfRef.rampart_i2c__DOT__tgt_rx_shift, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_rx_shift);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_rx_shift 
            = vlSelfRef.rampart_i2c__DOT__tgt_rx_shift;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_tx_shift) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_tx_shift))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1428, vlSelfRef.rampart_i2c__DOT__tgt_tx_shift, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_tx_shift);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_tx_shift 
            = vlSelfRef.rampart_i2c__DOT__tgt_tx_shift;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_addr_match) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_addr_match))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1444, vlSelfRef.rampart_i2c__DOT__tgt_addr_match, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_addr_match);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_addr_match 
            = vlSelfRef.rampart_i2c__DOT__tgt_addr_match;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_stretch_needed))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1446, vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_stretch_needed);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_stretch_needed 
            = vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed;
    }
    if ((vlSelfRef.rampart_i2c__DOT__host_timeout_cnt 
         ^ vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_cnt)) {
        VL_COV_TOGGLE_CHG_ST_I(20, vlSymsp->__Vcoverage + 1448, vlSelfRef.rampart_i2c__DOT__host_timeout_cnt, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_cnt);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_cnt 
            = vlSelfRef.rampart_i2c__DOT__host_timeout_cnt;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_timeout_event) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_event))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1488, vlSelfRef.rampart_i2c__DOT__host_timeout_event, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_event);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_event 
            = vlSelfRef.rampart_i2c__DOT__host_timeout_event;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__bus_active) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__bus_active))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1490, vlSelfRef.rampart_i2c__DOT__bus_active, vlSelfRef.rampart_i2c__DOT____Vtogcov__bus_active);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__bus_active 
            = vlSelfRef.rampart_i2c__DOT__bus_active;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_rsp_pending) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_rsp_pending))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1714, vlSelfRef.rampart_i2c__DOT__tl_rsp_pending, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_rsp_pending);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_rsp_pending 
            = vlSelfRef.rampart_i2c__DOT__tl_rsp_pending;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_pop_req) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_pop_req))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2037, vlSelfRef.rampart_i2c__DOT__fmt_pop_req, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_pop_req);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_pop_req 
            = vlSelfRef.rampart_i2c__DOT__fmt_pop_req;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_scl_drive_low) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_scl_drive_low))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2043, vlSelfRef.rampart_i2c__DOT__host_scl_drive_low, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_scl_drive_low);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_scl_drive_low 
            = vlSelfRef.rampart_i2c__DOT__host_scl_drive_low;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_sda_drive_low) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_sda_drive_low))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2045, vlSelfRef.rampart_i2c__DOT__host_sda_drive_low, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_sda_drive_low);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_sda_drive_low 
            = vlSelfRef.rampart_i2c__DOT__host_sda_drive_low;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_push_valid) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_push_valid))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2184, vlSelfRef.rampart_i2c__DOT__rx_push_valid, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_push_valid);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_push_valid 
            = vlSelfRef.rampart_i2c__DOT__rx_push_valid;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_push_data) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_push_data))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 2186, vlSelfRef.rampart_i2c__DOT__rx_push_data, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_push_data);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_push_data 
            = vlSelfRef.rampart_i2c__DOT__rx_push_data;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_scl_drive_low))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2213, vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_scl_drive_low);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_scl_drive_low 
            = vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_sda_drive_low))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2215, vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_sda_drive_low);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_sda_drive_low 
            = vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low;
    }
    vlSelfRef.tl_d_valid_o = vlSelfRef.rampart_i2c__DOT__tl_d_valid_o;
    vlSelfRef.tl_d_opcode_o = vlSelfRef.rampart_i2c__DOT__tl_d_opcode_o;
    vlSelfRef.tl_d_data_o = vlSelfRef.rampart_i2c__DOT__tl_d_data_o;
    vlSelfRef.tl_d_source_o = vlSelfRef.rampart_i2c__DOT__tl_d_source_o;
    vlSelfRef.tl_d_error_o = vlSelfRef.rampart_i2c__DOT__tl_d_error_o;
    if (((~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q))) {
        ++(vlSymsp->__Vcoverage[1993]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)))) {
        ++(vlSymsp->__Vcoverage[1994]);
    }
    if (vlSelfRef.rampart_i2c__DOT__scl_in_qq) {
        ++(vlSymsp->__Vcoverage[1995]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq) 
         & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)))) {
        ++(vlSymsp->__Vcoverage[1996]);
    }
    if (vlSelfRef.rampart_i2c__DOT__scl_in_q) {
        ++(vlSymsp->__Vcoverage[1997]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq)))) {
        ++(vlSymsp->__Vcoverage[1998]);
    }
    if (((~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q))) {
        ++(vlSymsp->__Vcoverage[1999]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)))) {
        ++(vlSymsp->__Vcoverage[2000]);
    }
    if (vlSelfRef.rampart_i2c__DOT__sda_in_qq) {
        ++(vlSymsp->__Vcoverage[2001]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq) 
         & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)))) {
        ++(vlSymsp->__Vcoverage[2002]);
    }
    if (vlSelfRef.rampart_i2c__DOT__sda_in_q) {
        ++(vlSymsp->__Vcoverage[2003]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq)))) {
        ++(vlSymsp->__Vcoverage[2004]);
    }
    if (((((IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq) 
           & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)) 
          & (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq)) 
         & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)))) {
        ++(vlSymsp->__Vcoverage[2005]);
    }
    if (vlSelfRef.rampart_i2c__DOT__sda_in_q) {
        ++(vlSymsp->__Vcoverage[2006]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq)))) {
        ++(vlSymsp->__Vcoverage[2007]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)))) {
        ++(vlSymsp->__Vcoverage[2008]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq)))) {
        ++(vlSymsp->__Vcoverage[2009]);
    }
    if (((((IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq) 
           & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)) 
          & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq))) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q))) {
        ++(vlSymsp->__Vcoverage[2010]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)))) {
        ++(vlSymsp->__Vcoverage[2011]);
    }
    if (vlSelfRef.rampart_i2c__DOT__sda_in_qq) {
        ++(vlSymsp->__Vcoverage[2012]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)))) {
        ++(vlSymsp->__Vcoverage[2013]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq)))) {
        ++(vlSymsp->__Vcoverage[2014]);
    }
    ++(vlSymsp->__Vcoverage[2015]);
    vlSelfRef.rampart_i2c__DOT__clk_i = vlSelfRef.clk_i;
    vlSelfRef.rampart_i2c__DOT__rst_ni = vlSelfRef.rst_ni;
    vlSelfRef.rampart_i2c__DOT__tl_a_size_i = vlSelfRef.tl_a_size_i;
    vlSelfRef.rampart_i2c__DOT__fmt_fifo_pop = vlSelfRef.rampart_i2c__DOT__fmt_pop_req;
    vlSelfRef.rampart_i2c__DOT__rx_fifo_wdata = vlSelfRef.rampart_i2c__DOT__rx_push_data;
    vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata = vlSelfRef.rampart_i2c__DOT__tx_fifo_mem
        [(0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr))];
    vlSelfRef.rampart_i2c__DOT__scl_rising = ((~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq)) 
                                              & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q));
    vlSelfRef.rampart_i2c__DOT__scl_falling = ((~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)) 
                                               & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq));
    vlSelfRef.rampart_i2c__DOT__intr_o = ((IData)(vlSelfRef.rampart_i2c__DOT__intr_enable) 
                                          & (IData)(vlSelfRef.rampart_i2c__DOT__intr_state));
    vlSelfRef.rampart_i2c__DOT__tl_a_mask_i = vlSelfRef.tl_a_mask_i;
    vlSelfRef.rampart_i2c__DOT__tl_a_source_i = vlSelfRef.tl_a_source_i;
    vlSelfRef.rampart_i2c__DOT__scl_i = vlSelfRef.scl_i;
    vlSelfRef.rampart_i2c__DOT__sda_i = vlSelfRef.sda_i;
    vlSelfRef.rampart_i2c__DOT__acq_fifo_full = (((1U 
                                                   & ((IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr) 
                                                      >> 6U)) 
                                                  != 
                                                  (1U 
                                                   & ((IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr) 
                                                      >> 6U))) 
                                                 & ((0x0000003fU 
                                                     & (IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr)) 
                                                    == 
                                                    (0x0000003fU 
                                                     & (IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr))));
    vlSelfRef.rampart_i2c__DOT__scl_interference_det 
        = ((~ (IData)(vlSelfRef.rampart_i2c__DOT__host_scl_drive_low)) 
           & ((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable) 
              & ((~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)) 
                 & (0U != (IData)(vlSelfRef.rampart_i2c__DOT__host_state)))));
    vlSelfRef.rampart_i2c__DOT__sda_interference_det 
        = ((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable) 
           & (((~ (IData)(vlSelfRef.rampart_i2c__DOT__host_sda_drive_low)) 
               & ((4U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
                  | (2U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state)))) 
              & ((~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)) 
                 & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q))));
    vlSelfRef.rampart_i2c__DOT__rx_fifo_push = vlSelfRef.rampart_i2c__DOT__rx_push_valid;
    __VdfgRegularize_h6e95ff9d_0_6 = ((~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)) 
                                      & (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq));
    vlSelfRef.rampart_i2c__DOT__host_timing_done = 
        (0U == (IData)(vlSelfRef.rampart_i2c__DOT__host_timing_cnt));
    __VdfgRegularize_h6e95ff9d_0_1 = ((~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq)) 
                                      & (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q));
    vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata = vlSelfRef.rampart_i2c__DOT__fmt_fifo_mem
        [(0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr))];
    vlSelfRef.rampart_i2c__DOT__host_scl_oe = vlSelfRef.rampart_i2c__DOT__host_scl_drive_low;
    vlSelfRef.rampart_i2c__DOT__tgt_scl_oe = vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low;
    vlSelfRef.rampart_i2c__DOT__host_sda_oe = vlSelfRef.rampart_i2c__DOT__host_sda_drive_low;
    vlSelfRef.rampart_i2c__DOT__tgt_sda_oe = vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low;
    vlSelfRef.rampart_i2c__DOT__rx_fifo_rdata = vlSelfRef.rampart_i2c__DOT__rx_fifo_mem
        [(0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr))];
    vlSelfRef.rampart_i2c__DOT__acq_fifo_rdata = vlSelfRef.rampart_i2c__DOT__acq_fifo_mem
        [(0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr))];
    vlSelfRef.rampart_i2c__DOT__rx_fifo_empty = ((IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr) 
                                                 == (IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr));
    vlSelfRef.rampart_i2c__DOT__acq_fifo_empty = ((IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr) 
                                                  == (IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr));
    vlSelfRef.rampart_i2c__DOT__tl_a_address_i = vlSelfRef.tl_a_address_i;
    vlSelfRef.rampart_i2c__DOT__tl_a_data_i = vlSelfRef.tl_a_data_i;
    vlSelfRef.rampart_i2c__DOT__tl_a_opcode_i = vlSelfRef.tl_a_opcode_i;
    vlSelfRef.rampart_i2c__DOT__tl_a_valid_i = vlSelfRef.tl_a_valid_i;
    vlSelfRef.rampart_i2c__DOT__fmt_fifo_full = (((1U 
                                                   & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr) 
                                                      >> 6U)) 
                                                  != 
                                                  (1U 
                                                   & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr) 
                                                      >> 6U))) 
                                                 & ((0x0000003fU 
                                                     & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr)) 
                                                    == 
                                                    (0x0000003fU 
                                                     & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr))));
    vlSelfRef.rampart_i2c__DOT__tx_fifo_full = (((1U 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr) 
                                                     >> 6U)) 
                                                 != 
                                                 (1U 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr) 
                                                     >> 6U))) 
                                                & ((0x0000003fU 
                                                    & (IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr)) 
                                                   == 
                                                   (0x0000003fU 
                                                    & (IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr))));
    vlSelfRef.rampart_i2c__DOT__tl_d_ready_i = vlSelfRef.tl_d_ready_i;
    vlSelfRef.rampart_i2c__DOT__fmt_fifo_level = (0x0000007fU 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr) 
                                                     - (IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr)));
    vlSelfRef.rampart_i2c__DOT__rx_fifo_level = (0x0000007fU 
                                                 & ((IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr) 
                                                    - (IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr)));
    vlSelfRef.rampart_i2c__DOT__tx_fifo_empty = ((IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr) 
                                                 == (IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr));
    vlSelfRef.rampart_i2c__DOT__tx_fifo_level = (0x0000007fU 
                                                 & ((IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr) 
                                                    - (IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr)));
    vlSelfRef.rampart_i2c__DOT__acq_fifo_level = (0x0000007fU 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr) 
                                                     - (IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr)));
    vlSelfRef.rampart_i2c__DOT__rx_fifo_full = (((1U 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr) 
                                                     >> 6U)) 
                                                 != 
                                                 (1U 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr) 
                                                     >> 6U))) 
                                                & ((0x0000003fU 
                                                    & (IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr)) 
                                                   == 
                                                   (0x0000003fU 
                                                    & (IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr))));
    __VdfgRegularize_h6e95ff9d_0_5 = ((IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q) 
                                      & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq));
    vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty = ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr) 
                                                  == (IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__clk_i) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__clk_i))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 0, vlSelfRef.rampart_i2c__DOT__clk_i, vlSelfRef.rampart_i2c__DOT____Vtogcov__clk_i);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__clk_i 
            = vlSelfRef.rampart_i2c__DOT__clk_i;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rst_ni) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rst_ni))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2, vlSelfRef.rampart_i2c__DOT__rst_ni, vlSelfRef.rampart_i2c__DOT____Vtogcov__rst_ni);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rst_ni 
            = vlSelfRef.rampart_i2c__DOT__rst_ni;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_a_size_i) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_size_i))) {
        VL_COV_TOGGLE_CHG_ST_I(2, vlSymsp->__Vcoverage + 166, vlSelfRef.rampart_i2c__DOT__tl_a_size_i, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_size_i);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_size_i 
            = vlSelfRef.rampart_i2c__DOT__tl_a_size_i;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_pop) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_pop))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 914, vlSelfRef.rampart_i2c__DOT__fmt_fifo_pop, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_pop);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_pop 
            = vlSelfRef.rampart_i2c__DOT__fmt_fifo_pop;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_wdata) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_wdata))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1018, vlSelfRef.rampart_i2c__DOT__rx_fifo_wdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_wdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_wdata 
            = vlSelfRef.rampart_i2c__DOT__rx_fifo_wdata;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_rdata))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1116, vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_rdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_rdata 
            = vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_rising) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_rising))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1981, vlSelfRef.rampart_i2c__DOT__scl_rising, vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_rising);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_rising 
            = vlSelfRef.rampart_i2c__DOT__scl_rising;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_falling) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_falling))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1983, vlSelfRef.rampart_i2c__DOT__scl_falling, vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_falling);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_falling 
            = vlSelfRef.rampart_i2c__DOT__scl_falling;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__intr_o) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_o))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 272, vlSelfRef.rampart_i2c__DOT__intr_o, vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_o);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_o 
            = vlSelfRef.rampart_i2c__DOT__intr_o;
    }
    vlSelfRef.intr_o = vlSelfRef.rampart_i2c__DOT__intr_o;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_a_mask_i) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_mask_i))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 142, vlSelfRef.rampart_i2c__DOT__tl_a_mask_i, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_mask_i);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_mask_i 
            = vlSelfRef.rampart_i2c__DOT__tl_a_mask_i;
    }
    vlSelfRef.rampart_i2c__DOT__tl_req_mask = vlSelfRef.rampart_i2c__DOT__tl_a_mask_i;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_a_source_i) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_source_i))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 150, vlSelfRef.rampart_i2c__DOT__tl_a_source_i, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_source_i);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_source_i 
            = vlSelfRef.rampart_i2c__DOT__tl_a_source_i;
    }
    vlSelfRef.rampart_i2c__DOT__tl_req_source = vlSelfRef.rampart_i2c__DOT__tl_a_source_i;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_i) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_i))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 262, vlSelfRef.rampart_i2c__DOT__scl_i, vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_i);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_i 
            = vlSelfRef.rampart_i2c__DOT__scl_i;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_i) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_i))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 268, vlSelfRef.rampart_i2c__DOT__sda_i, vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_i);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_i 
            = vlSelfRef.rampart_i2c__DOT__sda_i;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_full) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_full))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1162, vlSelfRef.rampart_i2c__DOT__acq_fifo_full, vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_full);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_full 
            = vlSelfRef.rampart_i2c__DOT__acq_fifo_full;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_interference_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_interference_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2331, vlSelfRef.rampart_i2c__DOT__scl_interference_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_interference_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_interference_det 
            = vlSelfRef.rampart_i2c__DOT__scl_interference_det;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_interference_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_interference_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2329, vlSelfRef.rampart_i2c__DOT__sda_interference_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_interference_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_interference_det 
            = vlSelfRef.rampart_i2c__DOT__sda_interference_det;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_push) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_push))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1014, vlSelfRef.rampart_i2c__DOT__rx_fifo_push, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_push);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_push 
            = vlSelfRef.rampart_i2c__DOT__rx_fifo_push;
    }
    vlSelfRef.rampart_i2c__DOT__sda_falling = __VdfgRegularize_h6e95ff9d_0_6;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timing_done))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2040, vlSelfRef.rampart_i2c__DOT__host_timing_done, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timing_done);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timing_done 
            = vlSelfRef.rampart_i2c__DOT__host_timing_done;
    }
    vlSelfRef.rampart_i2c__DOT__sda_rising = __VdfgRegularize_h6e95ff9d_0_1;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_rdata))) {
        VL_COV_TOGGLE_CHG_ST_I(13, vlSymsp->__Vcoverage + 942, vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_rdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_rdata 
            = vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata;
    }
    vlSelfRef.rampart_i2c__DOT__host_cmd_byte = (0x000000ffU 
                                                 & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata));
    vlSelfRef.rampart_i2c__DOT__host_cmd_start = (1U 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata) 
                                                     >> 8U));
    vlSelfRef.rampart_i2c__DOT__host_cmd_stop = (1U 
                                                 & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata) 
                                                    >> 9U));
    vlSelfRef.rampart_i2c__DOT__host_cmd_readb = (1U 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata) 
                                                     >> 0x0000000aU));
    vlSelfRef.rampart_i2c__DOT__host_cmd_rcont = (1U 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata) 
                                                     >> 0x0000000bU));
    vlSelfRef.rampart_i2c__DOT__host_cmd_nakok = (1U 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata) 
                                                     >> 0x0000000cU));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_scl_oe) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_scl_oe))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1242, vlSelfRef.rampart_i2c__DOT__host_scl_oe, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_scl_oe);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_scl_oe 
            = vlSelfRef.rampart_i2c__DOT__host_scl_oe;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_scl_oe) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_scl_oe))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1246, vlSelfRef.rampart_i2c__DOT__tgt_scl_oe, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_scl_oe);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_scl_oe 
            = vlSelfRef.rampart_i2c__DOT__tgt_scl_oe;
    }
    rampart_i2c__DOT____VdfgExtracted_h748dde20__0 
        = ((IData)(vlSelfRef.rampart_i2c__DOT__host_scl_oe) 
           | (IData)(vlSelfRef.rampart_i2c__DOT__tgt_scl_oe));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_sda_oe) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_sda_oe))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1244, vlSelfRef.rampart_i2c__DOT__host_sda_oe, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_sda_oe);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_sda_oe 
            = vlSelfRef.rampart_i2c__DOT__host_sda_oe;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_sda_oe) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_sda_oe))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1248, vlSelfRef.rampart_i2c__DOT__tgt_sda_oe, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_sda_oe);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_sda_oe 
            = vlSelfRef.rampart_i2c__DOT__tgt_sda_oe;
    }
    rampart_i2c__DOT____VdfgExtracted_he4f4c8eb__0 
        = ((IData)(vlSelfRef.rampart_i2c__DOT__host_sda_oe) 
           | (IData)(vlSelfRef.rampart_i2c__DOT__tgt_sda_oe));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_rdata) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_rdata))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1034, vlSelfRef.rampart_i2c__DOT__rx_fifo_rdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_rdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_rdata 
            = vlSelfRef.rampart_i2c__DOT__rx_fifo_rdata;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_rdata) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_rdata))) {
        VL_COV_TOGGLE_CHG_ST_I(10, vlSymsp->__Vcoverage + 1202, vlSelfRef.rampart_i2c__DOT__acq_fifo_rdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_rdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_rdata 
            = vlSelfRef.rampart_i2c__DOT__acq_fifo_rdata;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_empty) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_empty))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 996, vlSelfRef.rampart_i2c__DOT__rx_fifo_empty, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_empty);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_empty 
            = vlSelfRef.rampart_i2c__DOT__rx_fifo_empty;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_empty) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_empty))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1160, vlSelfRef.rampart_i2c__DOT__acq_fifo_empty, vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_empty);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_empty 
            = vlSelfRef.rampart_i2c__DOT__acq_fifo_empty;
    }
    if ((vlSelfRef.rampart_i2c__DOT__tl_a_address_i 
         ^ vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_address_i)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 14, vlSelfRef.rampart_i2c__DOT__tl_a_address_i, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_address_i);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_address_i 
            = vlSelfRef.rampart_i2c__DOT__tl_a_address_i;
    }
    vlSelfRef.rampart_i2c__DOT__tl_req_addr = (0xfffffffcU 
                                               & vlSelfRef.rampart_i2c__DOT__tl_a_address_i);
    if ((vlSelfRef.rampart_i2c__DOT__tl_a_data_i ^ vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_data_i)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 78, vlSelfRef.rampart_i2c__DOT__tl_a_data_i, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_data_i);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_data_i 
            = vlSelfRef.rampart_i2c__DOT__tl_a_data_i;
    }
    vlSelfRef.rampart_i2c__DOT__tl_req_wdata = vlSelfRef.rampart_i2c__DOT__tl_a_data_i;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_a_opcode_i) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_opcode_i))) {
        VL_COV_TOGGLE_CHG_ST_I(3, vlSymsp->__Vcoverage + 8, vlSelfRef.rampart_i2c__DOT__tl_a_opcode_i, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_opcode_i);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_opcode_i 
            = vlSelfRef.rampart_i2c__DOT__tl_a_opcode_i;
    }
    vlSelfRef.rampart_i2c__DOT__tl_req_write = ((0U 
                                                 == (IData)(vlSelfRef.rampart_i2c__DOT__tl_a_opcode_i)) 
                                                | (1U 
                                                   == (IData)(vlSelfRef.rampart_i2c__DOT__tl_a_opcode_i)));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_a_valid_i) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_valid_i))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 4, vlSelfRef.rampart_i2c__DOT__tl_a_valid_i, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_valid_i);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_valid_i 
            = vlSelfRef.rampart_i2c__DOT__tl_a_valid_i;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_full) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_full))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 896, vlSelfRef.rampart_i2c__DOT__fmt_fifo_full, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_full);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_full 
            = vlSelfRef.rampart_i2c__DOT__fmt_fifo_full;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_full) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_full))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1080, vlSelfRef.rampart_i2c__DOT__tx_fifo_full, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_full);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_full 
            = vlSelfRef.rampart_i2c__DOT__tx_fifo_full;
    }
    if (vlSelfRef.rampart_i2c__DOT__tl_d_ready_i) {
        ++(vlSymsp->__Vcoverage[1723]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_rsp_pending)))) {
        ++(vlSymsp->__Vcoverage[1724]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_rsp_pending) 
         & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_d_ready_i)))) {
        ++(vlSymsp->__Vcoverage[1725]);
    }
    ++(vlSymsp->__Vcoverage[1726]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_d_ready_i) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_ready_i))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 172, vlSelfRef.rampart_i2c__DOT__tl_d_ready_i, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_ready_i);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_ready_i 
            = vlSelfRef.rampart_i2c__DOT__tl_d_ready_i;
    }
    vlSelfRef.rampart_i2c__DOT__tl_a_ready_o = (1U 
                                                & ((~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_rsp_pending)) 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__tl_d_ready_i)));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_level) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_level))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 898, vlSelfRef.rampart_i2c__DOT__fmt_fifo_level, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_level);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_level 
            = vlSelfRef.rampart_i2c__DOT__fmt_fifo_level;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_level) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_level))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 1000, vlSelfRef.rampart_i2c__DOT__rx_fifo_level, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_level);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_level 
            = vlSelfRef.rampart_i2c__DOT__rx_fifo_level;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_empty) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_empty))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1078, vlSelfRef.rampart_i2c__DOT__tx_fifo_empty, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_empty);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_empty 
            = vlSelfRef.rampart_i2c__DOT__tx_fifo_empty;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_level) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_level))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 1082, vlSelfRef.rampart_i2c__DOT__tx_fifo_level, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_level);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_level 
            = vlSelfRef.rampart_i2c__DOT__tx_fifo_level;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_level) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_level))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 1164, vlSelfRef.rampart_i2c__DOT__acq_fifo_level, vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_level);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_level 
            = vlSelfRef.rampart_i2c__DOT__acq_fifo_level;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_full) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_full))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 998, vlSelfRef.rampart_i2c__DOT__rx_fifo_full, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_full);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_full 
            = vlSelfRef.rampart_i2c__DOT__rx_fifo_full;
    }
    vlSelfRef.rampart_i2c__DOT__rx_overflow_det = ((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_full) 
                                                   & (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_push));
    vlSelfRef.rampart_i2c__DOT__start_det = ((IData)(__VdfgRegularize_h6e95ff9d_0_5) 
                                             & (IData)(__VdfgRegularize_h6e95ff9d_0_6));
    vlSelfRef.rampart_i2c__DOT__stop_det = ((IData)(__VdfgRegularize_h6e95ff9d_0_5) 
                                            & (IData)(__VdfgRegularize_h6e95ff9d_0_1));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_empty))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 894, vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_empty);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_empty 
            = vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty;
    }
    vlSelfRef.rampart_i2c__DOT__trans_complete_det 
        = ((0U != (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
           & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty) 
              & ((0x0aU == (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
                 & (IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done))));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_mask) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_mask))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 1624, vlSelfRef.rampart_i2c__DOT__tl_req_mask, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_mask);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_mask 
            = vlSelfRef.rampart_i2c__DOT__tl_req_mask;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_source) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_source))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1632, vlSelfRef.rampart_i2c__DOT__tl_req_source, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_source);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_source 
            = vlSelfRef.rampart_i2c__DOT__tl_req_source;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_falling) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_falling))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1987, vlSelfRef.rampart_i2c__DOT__sda_falling, vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_falling);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_falling 
            = vlSelfRef.rampart_i2c__DOT__sda_falling;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_rising) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_rising))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1985, vlSelfRef.rampart_i2c__DOT__sda_rising, vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_rising);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_rising 
            = vlSelfRef.rampart_i2c__DOT__sda_rising;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_byte) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_byte))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1370, vlSelfRef.rampart_i2c__DOT__host_cmd_byte, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_byte);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_byte 
            = vlSelfRef.rampart_i2c__DOT__host_cmd_byte;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_start) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_start))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1360, vlSelfRef.rampart_i2c__DOT__host_cmd_start, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_start);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_start 
            = vlSelfRef.rampart_i2c__DOT__host_cmd_start;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_stop) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_stop))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1362, vlSelfRef.rampart_i2c__DOT__host_cmd_stop, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_stop);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_stop 
            = vlSelfRef.rampart_i2c__DOT__host_cmd_stop;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_readb) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_readb))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1364, vlSelfRef.rampart_i2c__DOT__host_cmd_readb, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_readb);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_readb 
            = vlSelfRef.rampart_i2c__DOT__host_cmd_readb;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_rcont) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_rcont))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1366, vlSelfRef.rampart_i2c__DOT__host_cmd_rcont, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_rcont);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_rcont 
            = vlSelfRef.rampart_i2c__DOT__host_cmd_rcont;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_nakok) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_nakok))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1368, vlSelfRef.rampart_i2c__DOT__host_cmd_nakok, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_nakok);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_nakok 
            = vlSelfRef.rampart_i2c__DOT__host_cmd_nakok;
    }
    vlSelfRef.rampart_i2c__DOT__nak_det = (((3U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
                                            | (5U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) 
                                           & ((~ (IData)(vlSelfRef.rampart_i2c__DOT__host_scl_drive_low)) 
                                              & ((IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done) 
                                                 & ((~ (IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_nakok)) 
                                                    & (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)))));
    if (vlSelfRef.rampart_i2c__DOT__ovrd_txovrden) {
        vlSelfRef.rampart_i2c__DOT__scl_oe_o = (1U 
                                                & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ovrd_sclval)));
        vlSelfRef.rampart_i2c__DOT__sda_oe_o = (1U 
                                                & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ovrd_sdaval)));
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ovrd_sclval)))) {
            ++(vlSymsp->__Vcoverage[2024]);
        }
        if (vlSelfRef.rampart_i2c__DOT__ovrd_sclval) {
            ++(vlSymsp->__Vcoverage[2025]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ovrd_sdaval)))) {
            ++(vlSymsp->__Vcoverage[2026]);
        }
        if (vlSelfRef.rampart_i2c__DOT__ovrd_sdaval) {
            ++(vlSymsp->__Vcoverage[2027]);
        }
        ++(vlSymsp->__Vcoverage[2034]);
    } else {
        vlSelfRef.rampart_i2c__DOT__scl_oe_o = rampart_i2c__DOT____VdfgExtracted_h748dde20__0;
        vlSelfRef.rampart_i2c__DOT__sda_oe_o = rampart_i2c__DOT____VdfgExtracted_he4f4c8eb__0;
        if (vlSelfRef.rampart_i2c__DOT__tgt_scl_oe) {
            ++(vlSymsp->__Vcoverage[2028]);
        }
        if (vlSelfRef.rampart_i2c__DOT__host_scl_oe) {
            ++(vlSymsp->__Vcoverage[2029]);
        }
        if ((1U & (~ (IData)(rampart_i2c__DOT____VdfgExtracted_h748dde20__0)))) {
            ++(vlSymsp->__Vcoverage[2030]);
        }
        if (vlSelfRef.rampart_i2c__DOT__tgt_sda_oe) {
            ++(vlSymsp->__Vcoverage[2031]);
        }
        if (vlSelfRef.rampart_i2c__DOT__host_sda_oe) {
            ++(vlSymsp->__Vcoverage[2032]);
        }
        if ((1U & (~ (IData)(rampart_i2c__DOT____VdfgExtracted_he4f4c8eb__0)))) {
            ++(vlSymsp->__Vcoverage[2033]);
        }
        ++(vlSymsp->__Vcoverage[2035]);
    }
    ++(vlSymsp->__Vcoverage[2036]);
    if ((vlSelfRef.rampart_i2c__DOT__tl_req_addr ^ vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_addr)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 1496, vlSelfRef.rampart_i2c__DOT__tl_req_addr, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_addr);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_addr 
            = vlSelfRef.rampart_i2c__DOT__tl_req_addr;
    }
    if ((vlSelfRef.rampart_i2c__DOT__tl_req_wdata ^ vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_wdata)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 1560, vlSelfRef.rampart_i2c__DOT__tl_req_wdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_wdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_wdata 
            = vlSelfRef.rampart_i2c__DOT__tl_req_wdata;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_write))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1494, vlSelfRef.rampart_i2c__DOT__tl_req_write, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_write);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_write 
            = vlSelfRef.rampart_i2c__DOT__tl_req_write;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_a_valid_i) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__tl_a_ready_o))) {
        ++(vlSymsp->__Vcoverage[1716]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_a_ready_o)))) {
        ++(vlSymsp->__Vcoverage[1717]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_a_valid_i)))) {
        ++(vlSymsp->__Vcoverage[1718]);
    }
    if ((1U == (IData)(vlSelfRef.rampart_i2c__DOT__tl_a_opcode_i))) {
        ++(vlSymsp->__Vcoverage[1719]);
    }
    if ((0U == (IData)(vlSelfRef.rampart_i2c__DOT__tl_a_opcode_i))) {
        ++(vlSymsp->__Vcoverage[1720]);
    }
    if (((0U != (IData)(vlSelfRef.rampart_i2c__DOT__tl_a_opcode_i)) 
         & (1U != (IData)(vlSelfRef.rampart_i2c__DOT__tl_a_opcode_i)))) {
        ++(vlSymsp->__Vcoverage[1721]);
    }
    ++(vlSymsp->__Vcoverage[1722]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_a_ready_o) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_ready_o))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 6, vlSelfRef.rampart_i2c__DOT__tl_a_ready_o, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_ready_o);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_ready_o 
            = vlSelfRef.rampart_i2c__DOT__tl_a_ready_o;
    }
    vlSelfRef.tl_a_ready_o = vlSelfRef.rampart_i2c__DOT__tl_a_ready_o;
    vlSelfRef.rampart_i2c__DOT__tl_req_valid = ((IData)(vlSelfRef.rampart_i2c__DOT__tl_a_ready_o) 
                                                & (IData)(vlSelfRef.rampart_i2c__DOT__tl_a_valid_i));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_overflow_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_overflow_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2357, vlSelfRef.rampart_i2c__DOT__rx_overflow_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_overflow_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_overflow_det 
            = vlSelfRef.rampart_i2c__DOT__rx_overflow_det;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__start_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__start_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1989, vlSelfRef.rampart_i2c__DOT__start_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__start_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__start_det 
            = vlSelfRef.rampart_i2c__DOT__start_det;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__stop_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__stop_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1991, vlSelfRef.rampart_i2c__DOT__stop_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__stop_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__stop_det 
            = vlSelfRef.rampart_i2c__DOT__stop_det;
    }
    if (((((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable) 
           & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_scl_drive_low))) 
          & (0U != (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) 
         & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)))) {
        ++(vlSymsp->__Vcoverage[2335]);
    }
    if (vlSelfRef.rampart_i2c__DOT__scl_in_q) {
        ++(vlSymsp->__Vcoverage[2336]);
    }
    if ((0U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
        ++(vlSymsp->__Vcoverage[2337]);
    }
    if (vlSelfRef.rampart_i2c__DOT__host_scl_drive_low) {
        ++(vlSymsp->__Vcoverage[2338]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable)))) {
        ++(vlSymsp->__Vcoverage[2339]);
    }
    if ((((((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable) 
            & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_sda_drive_low))) 
           & (2U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) 
          & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q))) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q))) {
        ++(vlSymsp->__Vcoverage[2340]);
    }
    if ((((((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable) 
            & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_sda_drive_low))) 
           & (4U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) 
          & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q))) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q))) {
        ++(vlSymsp->__Vcoverage[2341]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)))) {
        ++(vlSymsp->__Vcoverage[2342]);
    }
    if (vlSelfRef.rampart_i2c__DOT__sda_in_q) {
        ++(vlSymsp->__Vcoverage[2343]);
    }
    if (((4U != (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
         & (2U != (IData)(vlSelfRef.rampart_i2c__DOT__host_state)))) {
        ++(vlSymsp->__Vcoverage[2344]);
    }
    if (vlSelfRef.rampart_i2c__DOT__host_sda_drive_low) {
        ++(vlSymsp->__Vcoverage[2345]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable)))) {
        ++(vlSymsp->__Vcoverage[2346]);
    }
    if (((((((IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q) 
             & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq)) 
            & ((IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q) 
               != (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq))) 
           & (~ (IData)(vlSelfRef.rampart_i2c__DOT__start_det))) 
          & (~ (IData)(vlSelfRef.rampart_i2c__DOT__stop_det))) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__bus_active))) {
        ++(vlSymsp->__Vcoverage[2347]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__bus_active)))) {
        ++(vlSymsp->__Vcoverage[2348]);
    }
    if (vlSelfRef.rampart_i2c__DOT__stop_det) {
        ++(vlSymsp->__Vcoverage[2349]);
    }
    if (vlSelfRef.rampart_i2c__DOT__start_det) {
        ++(vlSymsp->__Vcoverage[2350]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q) 
         == (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq))) {
        ++(vlSymsp->__Vcoverage[2351]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq)))) {
        ++(vlSymsp->__Vcoverage[2352]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)))) {
        ++(vlSymsp->__Vcoverage[2353]);
    }
    ++(vlSymsp->__Vcoverage[2354]);
    vlSelfRef.rampart_i2c__DOT__sda_unstable_det = 
        ((IData)(__VdfgRegularize_h6e95ff9d_0_5) & 
         ((~ (IData)(vlSelfRef.rampart_i2c__DOT__start_det)) 
          & (((IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q) 
              != (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq)) 
             & ((~ (IData)(vlSelfRef.rampart_i2c__DOT__stop_det)) 
                & (IData)(vlSelfRef.rampart_i2c__DOT__bus_active)))));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__trans_complete_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__trans_complete_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2363, vlSelfRef.rampart_i2c__DOT__trans_complete_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__trans_complete_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__trans_complete_det 
            = vlSelfRef.rampart_i2c__DOT__trans_complete_det;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__nak_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__nak_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2361, vlSelfRef.rampart_i2c__DOT__nak_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__nak_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__nak_det 
            = vlSelfRef.rampart_i2c__DOT__nak_det;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_oe_o) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_oe_o))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 266, vlSelfRef.rampart_i2c__DOT__scl_oe_o, vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_oe_o);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_oe_o 
            = vlSelfRef.rampart_i2c__DOT__scl_oe_o;
    }
    vlSelfRef.scl_oe_o = vlSelfRef.rampart_i2c__DOT__scl_oe_o;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_oe_o) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_oe_o))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 270, vlSelfRef.rampart_i2c__DOT__sda_oe_o, vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_oe_o);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_oe_o 
            = vlSelfRef.rampart_i2c__DOT__sda_oe_o;
    }
    vlSelfRef.sda_oe_o = vlSelfRef.rampart_i2c__DOT__sda_oe_o;
    if (vlSelfRef.rampart_i2c__DOT__ctrl_line_loopback) {
        vlSelfRef.rampart_i2c__DOT__scl_in = (1U & 
                                              (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_oe_o)));
        vlSelfRef.rampart_i2c__DOT__sda_in = (1U & 
                                              (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_oe_o)));
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_oe_o)))) {
            ++(vlSymsp->__Vcoverage[1969]);
        }
        if (vlSelfRef.rampart_i2c__DOT__scl_oe_o) {
            ++(vlSymsp->__Vcoverage[1970]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_oe_o)))) {
            ++(vlSymsp->__Vcoverage[1971]);
        }
        if (vlSelfRef.rampart_i2c__DOT__sda_oe_o) {
            ++(vlSymsp->__Vcoverage[1972]);
        }
        ++(vlSymsp->__Vcoverage[1973]);
    } else {
        vlSelfRef.rampart_i2c__DOT__scl_in = vlSelfRef.rampart_i2c__DOT__scl_i;
        vlSelfRef.rampart_i2c__DOT__sda_in = vlSelfRef.rampart_i2c__DOT__sda_i;
        ++(vlSymsp->__Vcoverage[1974]);
    }
    ++(vlSymsp->__Vcoverage[1975]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_valid))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1492, vlSelfRef.rampart_i2c__DOT__tl_req_valid, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_valid);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_valid 
            = vlSelfRef.rampart_i2c__DOT__tl_req_valid;
    }
    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata = 0U;
    vlSelfRef.rampart_i2c__DOT__tl_rsp_error = 0U;
    vlSelfRef.rampart_i2c__DOT__fmt_fifo_push = 0U;
    vlSelfRef.rampart_i2c__DOT__fmt_fifo_wdata = 0U;
    vlSelfRef.rampart_i2c__DOT__rx_fifo_pop = 0U;
    vlSelfRef.rampart_i2c__DOT__tx_fifo_push = 0U;
    vlSelfRef.rampart_i2c__DOT__tx_fifo_wdata = 0U;
    vlSelfRef.rampart_i2c__DOT__acq_fifo_pop = 0U;
    if (vlSelfRef.rampart_i2c__DOT__tl_req_valid) {
        if (vlSelfRef.rampart_i2c__DOT__tl_req_write) {
            if ((((((((((((((((0U == vlSelfRef.rampart_i2c__DOT__tl_req_addr) 
                              || (0x0000000cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                             || (0x00000010U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                            || (0x00000018U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                           || (0x0000001cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                          || (0x00000020U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                         || (0x00000024U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                        || (0x00000028U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                       || (0x0000002cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                      || (0x00000030U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                     || (0x00000038U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                    || (0x0000003cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                   || (0x00000040U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                  || (0x00000044U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                 || (0x00000048U == vlSelfRef.rampart_i2c__DOT__tl_req_addr))) {
                ++(vlSymsp->__Vcoverage[1743]);
            } else {
                vlSelfRef.rampart_i2c__DOT__tl_rsp_error = 1U;
                ++(vlSymsp->__Vcoverage[1744]);
            }
            if ((0x0000000cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                vlSelfRef.rampart_i2c__DOT__fmt_fifo_push = 1U;
                vlSelfRef.rampart_i2c__DOT__fmt_fifo_wdata 
                    = (0x00001fffU & vlSelfRef.rampart_i2c__DOT__tl_req_wdata);
                ++(vlSymsp->__Vcoverage[1745]);
            } else {
                ++(vlSymsp->__Vcoverage[1746]);
            }
            if ((0x00000038U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                vlSelfRef.rampart_i2c__DOT__tx_fifo_push = 1U;
                vlSelfRef.rampart_i2c__DOT__tx_fifo_wdata 
                    = (0x000000ffU & vlSelfRef.rampart_i2c__DOT__tl_req_wdata);
                ++(vlSymsp->__Vcoverage[1747]);
            } else {
                ++(vlSymsp->__Vcoverage[1748]);
            }
            ++(vlSymsp->__Vcoverage[1773]);
        } else {
            if (((((((((0U == vlSelfRef.rampart_i2c__DOT__tl_req_addr) 
                       | (4U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                      | (8U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                     | (0x0000000cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                    | (0x00000010U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                   | (0x00000014U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                  | (0x00000018U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                 | (0x0000001cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr))) {
                if ((0U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = vlSelfRef.rampart_i2c__DOT__ctrl_reg;
                    ++(vlSymsp->__Vcoverage[1749]);
                } else if ((4U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed) 
                            << 9U) | ((((((IData)(vlSelfRef.rampart_i2c__DOT__bus_active) 
                                          << 4U) | 
                                         (((0U == (IData)(vlSelfRef.rampart_i2c__DOT__tgt_state)) 
                                           << 3U) | 
                                          ((0U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
                                           << 2U))) 
                                        | (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_empty) 
                                            << 1U) 
                                           | (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_full))) 
                                       << 4U) | ((((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_empty) 
                                                   << 3U) 
                                                  | ((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_full) 
                                                     << 2U)) 
                                                 | (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty) 
                                                     << 1U) 
                                                    | (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_full)))));
                    ++(vlSymsp->__Vcoverage[1750]);
                } else if ((8U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = vlSelfRef.rampart_i2c__DOT__rx_fifo_rdata;
                    vlSelfRef.rampart_i2c__DOT__rx_fifo_pop 
                        = (1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_empty)));
                    ++(vlSymsp->__Vcoverage[1753]);
                } else if ((0x0000000cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata = 0U;
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_error = 1U;
                    ++(vlSymsp->__Vcoverage[1754]);
                } else if ((0x00000010U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata = 0U;
                    ++(vlSymsp->__Vcoverage[1755]);
                } else if ((0x00000014U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_level) 
                            << 0x00000015U) | (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_level) 
                                                << 0x0000000eU) 
                                               | (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_level) 
                                                   << 7U) 
                                                  | (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_level))));
                    ++(vlSymsp->__Vcoverage[1756]);
                } else if ((0x00000018U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__ovrd_sdaval) 
                            << 2U) | (((IData)(vlSelfRef.rampart_i2c__DOT__ovrd_sclval) 
                                       << 1U) | (IData)(vlSelfRef.rampart_i2c__DOT__ovrd_txovrden)));
                    ++(vlSymsp->__Vcoverage[1757]);
                } else {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__timing_thigh) 
                            << 0x00000010U) | (IData)(vlSelfRef.rampart_i2c__DOT__timing_tlow));
                    ++(vlSymsp->__Vcoverage[1758]);
                }
            } else if (((((((((0x00000020U == vlSelfRef.rampart_i2c__DOT__tl_req_addr) 
                              | (0x00000024U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                             | (0x00000028U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                            | (0x0000002cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                           | (0x00000030U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                          | (0x00000034U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                         | (0x00000038U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                        | (0x0000003cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr))) {
                if ((0x00000020U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__timing_t_r) 
                            << 0x00000010U) | (IData)(vlSelfRef.rampart_i2c__DOT__timing_t_f));
                    ++(vlSymsp->__Vcoverage[1759]);
                } else if ((0x00000024U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__timing_tsu_sta) 
                            << 0x00000010U) | (IData)(vlSelfRef.rampart_i2c__DOT__timing_thd_sta));
                    ++(vlSymsp->__Vcoverage[1760]);
                } else if ((0x00000028U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__timing_tsu_dat) 
                            << 0x00000010U) | (IData)(vlSelfRef.rampart_i2c__DOT__timing_thd_dat));
                    ++(vlSymsp->__Vcoverage[1761]);
                } else if ((0x0000002cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__timing_tsu_sto) 
                            << 0x00000010U) | (IData)(vlSelfRef.rampart_i2c__DOT__timing_t_buf));
                    ++(vlSymsp->__Vcoverage[1762]);
                } else if ((0x00000030U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__target_mask) 
                            << 7U) | (IData)(vlSelfRef.rampart_i2c__DOT__target_address));
                    ++(vlSymsp->__Vcoverage[1763]);
                } else if ((0x00000034U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = vlSelfRef.rampart_i2c__DOT__acq_fifo_rdata;
                    vlSelfRef.rampart_i2c__DOT__acq_fifo_pop 
                        = (1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_empty)));
                    ++(vlSymsp->__Vcoverage[1766]);
                } else if ((0x00000038U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata = 0U;
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_error = 1U;
                    ++(vlSymsp->__Vcoverage[1767]);
                } else {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__host_timeout_en) 
                            << 0x00000014U) | vlSelfRef.rampart_i2c__DOT__host_timeout_val);
                    ++(vlSymsp->__Vcoverage[1768]);
                }
            } else if ((0x00000040U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                    = vlSelfRef.rampart_i2c__DOT__intr_state;
                ++(vlSymsp->__Vcoverage[1769]);
            } else if ((0x00000044U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                    = vlSelfRef.rampart_i2c__DOT__intr_enable;
                ++(vlSymsp->__Vcoverage[1770]);
            } else if ((0x00000048U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata = 0U;
                ++(vlSymsp->__Vcoverage[1771]);
            } else {
                vlSelfRef.rampart_i2c__DOT__tl_rsp_error = 1U;
                ++(vlSymsp->__Vcoverage[1772]);
            }
            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_empty)))) {
                ++(vlSymsp->__Vcoverage[1751]);
            }
            if (vlSelfRef.rampart_i2c__DOT__rx_fifo_empty) {
                ++(vlSymsp->__Vcoverage[1752]);
            }
            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_empty)))) {
                ++(vlSymsp->__Vcoverage[1764]);
            }
            if (vlSelfRef.rampart_i2c__DOT__acq_fifo_empty) {
                ++(vlSymsp->__Vcoverage[1765]);
            }
            ++(vlSymsp->__Vcoverage[1774]);
        }
        ++(vlSymsp->__Vcoverage[1775]);
    } else {
        ++(vlSymsp->__Vcoverage[1776]);
    }
    ++(vlSymsp->__Vcoverage[1777]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_unstable_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_unstable_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2333, vlSelfRef.rampart_i2c__DOT__sda_unstable_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_unstable_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_unstable_det 
            = vlSelfRef.rampart_i2c__DOT__sda_unstable_det;
    }
    vlSelfRef.rampart_i2c__DOT__intr_hw_set = 0U;
    if (((1U >= (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_level)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable))) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (1U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2387]);
    } else {
        ++(vlSymsp->__Vcoverage[2388]);
    }
    if (((1U <= (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_level)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable))) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (2U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2392]);
    } else {
        ++(vlSymsp->__Vcoverage[2393]);
    }
    if (((1U <= (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_level)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (4U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2397]);
    } else {
        ++(vlSymsp->__Vcoverage[2398]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rx_overflow_det) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (8U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2402]);
    } else {
        ++(vlSymsp->__Vcoverage[2403]);
    }
    if (vlSelfRef.rampart_i2c__DOT__nak_det) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00000010U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2404]);
    } else {
        ++(vlSymsp->__Vcoverage[2405]);
    }
    if (vlSelfRef.rampart_i2c__DOT__scl_interference_det) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00000020U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2406]);
    } else {
        ++(vlSymsp->__Vcoverage[2407]);
    }
    if (vlSelfRef.rampart_i2c__DOT__sda_interference_det) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00000040U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2408]);
    } else {
        ++(vlSymsp->__Vcoverage[2409]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__host_timeout_event))) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00000080U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2410]);
    } else {
        ++(vlSymsp->__Vcoverage[2411]);
    }
    if (vlSelfRef.rampart_i2c__DOT__sda_unstable_det) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00000100U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2415]);
    } else {
        ++(vlSymsp->__Vcoverage[2416]);
    }
    if (vlSelfRef.rampart_i2c__DOT__trans_complete_det) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00000200U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2417]);
    } else {
        ++(vlSymsp->__Vcoverage[2418]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_empty) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00000400U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2419]);
    } else {
        ++(vlSymsp->__Vcoverage[2420]);
    }
    if (((1U >= (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_level)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00000800U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2424]);
    } else {
        ++(vlSymsp->__Vcoverage[2425]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_full) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00001000U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2429]);
    } else {
        ++(vlSymsp->__Vcoverage[2430]);
    }
    if ((((IData)(vlSelfRef.rampart_i2c__DOT__stop_det) 
          & (IData)(vlSelfRef.rampart_i2c__DOT__tgt_addr_match)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00002000U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2434]);
    } else {
        ++(vlSymsp->__Vcoverage[2435]);
    }
    if (vlSelfRef.rampart_i2c__DOT__host_timeout_event) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00004000U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2440]);
    } else {
        ++(vlSymsp->__Vcoverage[2441]);
    }
    if (vlSelfRef.rampart_i2c__DOT__host_arb_lost) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00008000U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2442]);
    } else {
        ++(vlSymsp->__Vcoverage[2443]);
    }
    if (((1U >= (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_level)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable))) {
        ++(vlSymsp->__Vcoverage[2389]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable)))) {
        ++(vlSymsp->__Vcoverage[2390]);
    }
    if ((1U < (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_level))) {
        ++(vlSymsp->__Vcoverage[2391]);
    }
    if (((1U <= (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_level)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable))) {
        ++(vlSymsp->__Vcoverage[2394]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable)))) {
        ++(vlSymsp->__Vcoverage[2395]);
    }
    if ((1U > (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_level))) {
        ++(vlSymsp->__Vcoverage[2396]);
    }
    if (((1U <= (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_level)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        ++(vlSymsp->__Vcoverage[2399]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable)))) {
        ++(vlSymsp->__Vcoverage[2400]);
    }
    if ((1U > (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_level))) {
        ++(vlSymsp->__Vcoverage[2401]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__host_timeout_event))) {
        ++(vlSymsp->__Vcoverage[2412]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_timeout_event)))) {
        ++(vlSymsp->__Vcoverage[2413]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed)))) {
        ++(vlSymsp->__Vcoverage[2414]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_empty) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        ++(vlSymsp->__Vcoverage[2421]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable)))) {
        ++(vlSymsp->__Vcoverage[2422]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_empty)))) {
        ++(vlSymsp->__Vcoverage[2423]);
    }
    if (((1U >= (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_level)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        ++(vlSymsp->__Vcoverage[2426]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable)))) {
        ++(vlSymsp->__Vcoverage[2427]);
    }
    if ((1U < (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_level))) {
        ++(vlSymsp->__Vcoverage[2428]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_full) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        ++(vlSymsp->__Vcoverage[2431]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable)))) {
        ++(vlSymsp->__Vcoverage[2432]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_full)))) {
        ++(vlSymsp->__Vcoverage[2433]);
    }
    if ((((IData)(vlSelfRef.rampart_i2c__DOT__stop_det) 
          & (IData)(vlSelfRef.rampart_i2c__DOT__tgt_addr_match)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        ++(vlSymsp->__Vcoverage[2436]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable)))) {
        ++(vlSymsp->__Vcoverage[2437]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tgt_addr_match)))) {
        ++(vlSymsp->__Vcoverage[2438]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__stop_det)))) {
        ++(vlSymsp->__Vcoverage[2439]);
    }
    ++(vlSymsp->__Vcoverage[2444]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_in) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_in))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1230, vlSelfRef.rampart_i2c__DOT__scl_in, vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_in);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_in 
            = vlSelfRef.rampart_i2c__DOT__scl_in;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_in) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_in))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1232, vlSelfRef.rampart_i2c__DOT__sda_in, vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_in);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_in 
            = vlSelfRef.rampart_i2c__DOT__sda_in;
    }
    if ((vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata ^ vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_rsp_rdata)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 1648, vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_rsp_rdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_rsp_rdata 
            = vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_rsp_error) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_rsp_error))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1712, vlSelfRef.rampart_i2c__DOT__tl_rsp_error, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_rsp_error);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_rsp_error 
            = vlSelfRef.rampart_i2c__DOT__tl_rsp_error;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_wdata) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_wdata))) {
        VL_COV_TOGGLE_CHG_ST_I(13, vlSymsp->__Vcoverage + 916, vlSelfRef.rampart_i2c__DOT__fmt_fifo_wdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_wdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_wdata 
            = vlSelfRef.rampart_i2c__DOT__fmt_fifo_wdata;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_pop) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_pop))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1016, vlSelfRef.rampart_i2c__DOT__rx_fifo_pop, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_pop);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_pop 
            = vlSelfRef.rampart_i2c__DOT__rx_fifo_pop;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_wdata) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_wdata))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1100, vlSelfRef.rampart_i2c__DOT__tx_fifo_wdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_wdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_wdata 
            = vlSelfRef.rampart_i2c__DOT__tx_fifo_wdata;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_pop) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_pop))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1180, vlSelfRef.rampart_i2c__DOT__acq_fifo_pop, vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_pop);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_pop 
            = vlSelfRef.rampart_i2c__DOT__acq_fifo_pop;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_push) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_push))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 912, vlSelfRef.rampart_i2c__DOT__fmt_fifo_push, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_push);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_push 
            = vlSelfRef.rampart_i2c__DOT__fmt_fifo_push;
    }
    vlSelfRef.rampart_i2c__DOT__fmt_overflow_det = 
        ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_full) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_push));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_push) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_push))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1096, vlSelfRef.rampart_i2c__DOT__tx_fifo_push, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_push);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_push 
            = vlSelfRef.rampart_i2c__DOT__tx_fifo_push;
    }
    vlSelfRef.rampart_i2c__DOT__tx_overflow_det = ((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_full) 
                                                   & (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_push));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_push) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_full))) {
        ++(vlSymsp->__Vcoverage[2365]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_full)))) {
        ++(vlSymsp->__Vcoverage[2366]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_push)))) {
        ++(vlSymsp->__Vcoverage[2367]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_push) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_full))) {
        ++(vlSymsp->__Vcoverage[2368]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_full)))) {
        ++(vlSymsp->__Vcoverage[2369]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_push)))) {
        ++(vlSymsp->__Vcoverage[2370]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_push) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_full))) {
        ++(vlSymsp->__Vcoverage[2371]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_full)))) {
        ++(vlSymsp->__Vcoverage[2372]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_push)))) {
        ++(vlSymsp->__Vcoverage[2373]);
    }
    if ((((((5U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
            & (IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done)) 
           & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_scl_drive_low))) 
          & (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)) 
         & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_nakok)))) {
        ++(vlSymsp->__Vcoverage[2374]);
    }
    if ((((((3U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
            & (IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done)) 
           & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_scl_drive_low))) 
          & (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)) 
         & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_nakok)))) {
        ++(vlSymsp->__Vcoverage[2375]);
    }
    if (vlSelfRef.rampart_i2c__DOT__host_cmd_nakok) {
        ++(vlSymsp->__Vcoverage[2376]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)))) {
        ++(vlSymsp->__Vcoverage[2377]);
    }
    if (vlSelfRef.rampart_i2c__DOT__host_scl_drive_low) {
        ++(vlSymsp->__Vcoverage[2378]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done)))) {
        ++(vlSymsp->__Vcoverage[2379]);
    }
    if (((3U != (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
         & (5U != (IData)(vlSelfRef.rampart_i2c__DOT__host_state)))) {
        ++(vlSymsp->__Vcoverage[2380]);
    }
    if (((((0U != (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
           & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty)) 
          & (0x0aU == (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done))) {
        ++(vlSymsp->__Vcoverage[2381]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done)))) {
        ++(vlSymsp->__Vcoverage[2382]);
    }
    if ((0x0aU != (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
        ++(vlSymsp->__Vcoverage[2383]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty)))) {
        ++(vlSymsp->__Vcoverage[2384]);
    }
    if ((0U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
        ++(vlSymsp->__Vcoverage[2385]);
    }
    ++(vlSymsp->__Vcoverage[2386]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_hw_set))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 834, vlSelfRef.rampart_i2c__DOT__intr_hw_set, vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_hw_set);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_hw_set 
            = vlSelfRef.rampart_i2c__DOT__intr_hw_set;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_overflow_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_overflow_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2355, vlSelfRef.rampart_i2c__DOT__fmt_overflow_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_overflow_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_overflow_det 
            = vlSelfRef.rampart_i2c__DOT__fmt_overflow_det;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_overflow_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_overflow_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2359, vlSelfRef.rampart_i2c__DOT__tx_overflow_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_overflow_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_overflow_det 
            = vlSelfRef.rampart_i2c__DOT__tx_overflow_det;
    }
}

void Vtop___024root___eval_ico(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_ico\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VicoTriggered[0U])) {
        Vtop___024root___ico_sequent__TOP__0(vlSelf);
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtop___024root___dump_triggers__ico(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG

bool Vtop___024root___eval_phase__ico(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_phase__ico\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VicoExecute;
    // Body
    Vtop___024root___eval_triggers_vec__ico(vlSelf);
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vtop___024root___dump_triggers__ico(vlSelfRef.__VicoTriggered, "ico"s);
    }
#endif
    __VicoExecute = Vtop___024root___trigger_anySet__ico(vlSelfRef.__VicoTriggered);
    if (__VicoExecute) {
        Vtop___024root___eval_ico(vlSelf);
    }
    return (__VicoExecute);
}

void Vtop___024root___eval_triggers_vec__act(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_triggers_vec__act\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VactTriggered[0U] = (QData)((IData)(
                                                    ((((~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)) 
                                                       & (IData)(vlSelfRef.__Vtrigprevexpr___TOP__rampart_i2c__DOT__rst_ni__0)) 
                                                      << 1U) 
                                                     | ((IData)(vlSelfRef.rampart_i2c__DOT__clk_i) 
                                                        & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__rampart_i2c__DOT__clk_i__0))))));
    vlSelfRef.__Vtrigprevexpr___TOP__rampart_i2c__DOT__clk_i__0 
        = vlSelfRef.rampart_i2c__DOT__clk_i;
    vlSelfRef.__Vtrigprevexpr___TOP__rampart_i2c__DOT__rst_ni__0 
        = vlSelfRef.rampart_i2c__DOT__rst_ni;
}

bool Vtop___024root___trigger_anySet__act(const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___trigger_anySet__act\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

void Vtop___024root___nba_sequent__TOP__0(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___nba_sequent__TOP__0\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ rampart_i2c__DOT____VdfgExtracted_h748dde20__0;
    rampart_i2c__DOT____VdfgExtracted_h748dde20__0 = 0;
    CData/*0:0*/ rampart_i2c__DOT____VdfgExtracted_he4f4c8eb__0;
    rampart_i2c__DOT____VdfgExtracted_he4f4c8eb__0 = 0;
    CData/*0:0*/ __VdfgRegularize_h6e95ff9d_0_1;
    __VdfgRegularize_h6e95ff9d_0_1 = 0;
    CData/*0:0*/ __VdfgRegularize_h6e95ff9d_0_5;
    __VdfgRegularize_h6e95ff9d_0_5 = 0;
    CData/*0:0*/ __VdfgRegularize_h6e95ff9d_0_6;
    __VdfgRegularize_h6e95ff9d_0_6 = 0;
    CData/*0:0*/ __Vdly__rampart_i2c__DOT__tl_rsp_pending;
    __Vdly__rampart_i2c__DOT__tl_rsp_pending = 0;
    CData/*0:0*/ __Vdly__rampart_i2c__DOT__fifo_ctrl_fmt_rst;
    __Vdly__rampart_i2c__DOT__fifo_ctrl_fmt_rst = 0;
    CData/*0:0*/ __Vdly__rampart_i2c__DOT__fifo_ctrl_rx_rst;
    __Vdly__rampart_i2c__DOT__fifo_ctrl_rx_rst = 0;
    CData/*0:0*/ __Vdly__rampart_i2c__DOT__fifo_ctrl_tx_rst;
    __Vdly__rampart_i2c__DOT__fifo_ctrl_tx_rst = 0;
    CData/*0:0*/ __Vdly__rampart_i2c__DOT__fifo_ctrl_acq_rst;
    __Vdly__rampart_i2c__DOT__fifo_ctrl_acq_rst = 0;
    SData/*15:0*/ __Vdly__rampart_i2c__DOT__intr_state;
    __Vdly__rampart_i2c__DOT__intr_state = 0;
    CData/*6:0*/ __Vdly__rampart_i2c__DOT__fmt_wptr;
    __Vdly__rampart_i2c__DOT__fmt_wptr = 0;
    CData/*6:0*/ __Vdly__rampart_i2c__DOT__fmt_rptr;
    __Vdly__rampart_i2c__DOT__fmt_rptr = 0;
    CData/*6:0*/ __Vdly__rampart_i2c__DOT__rx_wptr;
    __Vdly__rampart_i2c__DOT__rx_wptr = 0;
    CData/*6:0*/ __Vdly__rampart_i2c__DOT__rx_rptr;
    __Vdly__rampart_i2c__DOT__rx_rptr = 0;
    CData/*6:0*/ __Vdly__rampart_i2c__DOT__tx_wptr;
    __Vdly__rampart_i2c__DOT__tx_wptr = 0;
    CData/*6:0*/ __Vdly__rampart_i2c__DOT__tx_rptr;
    __Vdly__rampart_i2c__DOT__tx_rptr = 0;
    CData/*6:0*/ __Vdly__rampart_i2c__DOT__acq_wptr;
    __Vdly__rampart_i2c__DOT__acq_wptr = 0;
    CData/*6:0*/ __Vdly__rampart_i2c__DOT__acq_rptr;
    __Vdly__rampart_i2c__DOT__acq_rptr = 0;
    CData/*0:0*/ __Vdly__rampart_i2c__DOT__scl_in_q;
    __Vdly__rampart_i2c__DOT__scl_in_q = 0;
    CData/*0:0*/ __Vdly__rampart_i2c__DOT__sda_in_q;
    __Vdly__rampart_i2c__DOT__sda_in_q = 0;
    CData/*3:0*/ __Vdly__rampart_i2c__DOT__host_state;
    __Vdly__rampart_i2c__DOT__host_state = 0;
    CData/*0:0*/ __Vdly__rampart_i2c__DOT__host_sda_drive_low;
    __Vdly__rampart_i2c__DOT__host_sda_drive_low = 0;
    CData/*0:0*/ __Vdly__rampart_i2c__DOT__host_scl_drive_low;
    __Vdly__rampart_i2c__DOT__host_scl_drive_low = 0;
    CData/*3:0*/ __Vdly__rampart_i2c__DOT__host_bit_idx;
    __Vdly__rampart_i2c__DOT__host_bit_idx = 0;
    CData/*7:0*/ __Vdly__rampart_i2c__DOT__host_shift_reg;
    __Vdly__rampart_i2c__DOT__host_shift_reg = 0;
    CData/*3:0*/ __Vdly__rampart_i2c__DOT__tgt_state;
    __Vdly__rampart_i2c__DOT__tgt_state = 0;
    CData/*7:0*/ __Vdly__rampart_i2c__DOT__tgt_tx_shift;
    __Vdly__rampart_i2c__DOT__tgt_tx_shift = 0;
    CData/*3:0*/ __Vdly__rampart_i2c__DOT__tgt_bit_idx;
    __Vdly__rampart_i2c__DOT__tgt_bit_idx = 0;
    CData/*7:0*/ __Vdly__rampart_i2c__DOT__tgt_rx_shift;
    __Vdly__rampart_i2c__DOT__tgt_rx_shift = 0;
    CData/*6:0*/ __Vdly__rampart_i2c__DOT__tgt_addr_shift;
    __Vdly__rampart_i2c__DOT__tgt_addr_shift = 0;
    CData/*0:0*/ __Vdly__rampart_i2c__DOT__tgt_rw_bit;
    __Vdly__rampart_i2c__DOT__tgt_rw_bit = 0;
    CData/*0:0*/ __Vdly__rampart_i2c__DOT__tgt_addr_match;
    __Vdly__rampart_i2c__DOT__tgt_addr_match = 0;
    IData/*19:0*/ __Vdly__rampart_i2c__DOT__host_timeout_cnt;
    __Vdly__rampart_i2c__DOT__host_timeout_cnt = 0;
    SData/*12:0*/ __VdlyVal__rampart_i2c__DOT__fmt_fifo_mem__v0;
    __VdlyVal__rampart_i2c__DOT__fmt_fifo_mem__v0 = 0;
    CData/*5:0*/ __VdlyDim0__rampart_i2c__DOT__fmt_fifo_mem__v0;
    __VdlyDim0__rampart_i2c__DOT__fmt_fifo_mem__v0 = 0;
    CData/*0:0*/ __VdlySet__rampart_i2c__DOT__fmt_fifo_mem__v0;
    __VdlySet__rampart_i2c__DOT__fmt_fifo_mem__v0 = 0;
    CData/*7:0*/ __VdlyVal__rampart_i2c__DOT__rx_fifo_mem__v0;
    __VdlyVal__rampart_i2c__DOT__rx_fifo_mem__v0 = 0;
    CData/*5:0*/ __VdlyDim0__rampart_i2c__DOT__rx_fifo_mem__v0;
    __VdlyDim0__rampart_i2c__DOT__rx_fifo_mem__v0 = 0;
    CData/*0:0*/ __VdlySet__rampart_i2c__DOT__rx_fifo_mem__v0;
    __VdlySet__rampart_i2c__DOT__rx_fifo_mem__v0 = 0;
    CData/*7:0*/ __VdlyVal__rampart_i2c__DOT__tx_fifo_mem__v0;
    __VdlyVal__rampart_i2c__DOT__tx_fifo_mem__v0 = 0;
    CData/*5:0*/ __VdlyDim0__rampart_i2c__DOT__tx_fifo_mem__v0;
    __VdlyDim0__rampart_i2c__DOT__tx_fifo_mem__v0 = 0;
    CData/*0:0*/ __VdlySet__rampart_i2c__DOT__tx_fifo_mem__v0;
    __VdlySet__rampart_i2c__DOT__tx_fifo_mem__v0 = 0;
    SData/*9:0*/ __VdlyVal__rampart_i2c__DOT__acq_fifo_mem__v0;
    __VdlyVal__rampart_i2c__DOT__acq_fifo_mem__v0 = 0;
    CData/*5:0*/ __VdlyDim0__rampart_i2c__DOT__acq_fifo_mem__v0;
    __VdlyDim0__rampart_i2c__DOT__acq_fifo_mem__v0 = 0;
    CData/*0:0*/ __VdlySet__rampart_i2c__DOT__acq_fifo_mem__v0;
    __VdlySet__rampart_i2c__DOT__acq_fifo_mem__v0 = 0;
    // Body
    __Vdly__rampart_i2c__DOT__fifo_ctrl_fmt_rst = vlSelfRef.rampart_i2c__DOT__fifo_ctrl_fmt_rst;
    __Vdly__rampart_i2c__DOT__fifo_ctrl_rx_rst = vlSelfRef.rampart_i2c__DOT__fifo_ctrl_rx_rst;
    __Vdly__rampart_i2c__DOT__fifo_ctrl_tx_rst = vlSelfRef.rampart_i2c__DOT__fifo_ctrl_tx_rst;
    __Vdly__rampart_i2c__DOT__fifo_ctrl_acq_rst = vlSelfRef.rampart_i2c__DOT__fifo_ctrl_acq_rst;
    __Vdly__rampart_i2c__DOT__intr_state = vlSelfRef.rampart_i2c__DOT__intr_state;
    __Vdly__rampart_i2c__DOT__tl_rsp_pending = vlSelfRef.rampart_i2c__DOT__tl_rsp_pending;
    __VdlySet__rampart_i2c__DOT__tx_fifo_mem__v0 = 0U;
    __Vdly__rampart_i2c__DOT__acq_rptr = vlSelfRef.rampart_i2c__DOT__acq_rptr;
    __VdlySet__rampart_i2c__DOT__rx_fifo_mem__v0 = 0U;
    __VdlySet__rampart_i2c__DOT__fmt_fifo_mem__v0 = 0U;
    __Vdly__rampart_i2c__DOT__tx_wptr = vlSelfRef.rampart_i2c__DOT__tx_wptr;
    __Vdly__rampart_i2c__DOT__scl_in_q = vlSelfRef.rampart_i2c__DOT__scl_in_q;
    __Vdly__rampart_i2c__DOT__sda_in_q = vlSelfRef.rampart_i2c__DOT__sda_in_q;
    __Vdly__rampart_i2c__DOT__fmt_rptr = vlSelfRef.rampart_i2c__DOT__fmt_rptr;
    __Vdly__rampart_i2c__DOT__rx_rptr = vlSelfRef.rampart_i2c__DOT__rx_rptr;
    __Vdly__rampart_i2c__DOT__rx_wptr = vlSelfRef.rampart_i2c__DOT__rx_wptr;
    __Vdly__rampart_i2c__DOT__fmt_wptr = vlSelfRef.rampart_i2c__DOT__fmt_wptr;
    __Vdly__rampart_i2c__DOT__host_timeout_cnt = vlSelfRef.rampart_i2c__DOT__host_timeout_cnt;
    __Vdly__rampart_i2c__DOT__tgt_tx_shift = vlSelfRef.rampart_i2c__DOT__tgt_tx_shift;
    __Vdly__rampart_i2c__DOT__tgt_bit_idx = vlSelfRef.rampart_i2c__DOT__tgt_bit_idx;
    __Vdly__rampart_i2c__DOT__tgt_rx_shift = vlSelfRef.rampart_i2c__DOT__tgt_rx_shift;
    __Vdly__rampart_i2c__DOT__tgt_addr_shift = vlSelfRef.rampart_i2c__DOT__tgt_addr_shift;
    __Vdly__rampart_i2c__DOT__tgt_rw_bit = vlSelfRef.rampart_i2c__DOT__tgt_rw_bit;
    __Vdly__rampart_i2c__DOT__tgt_addr_match = vlSelfRef.rampart_i2c__DOT__tgt_addr_match;
    __Vdly__rampart_i2c__DOT__tgt_state = vlSelfRef.rampart_i2c__DOT__tgt_state;
    __Vdly__rampart_i2c__DOT__tx_rptr = vlSelfRef.rampart_i2c__DOT__tx_rptr;
    __VdlySet__rampart_i2c__DOT__acq_fifo_mem__v0 = 0U;
    __Vdly__rampart_i2c__DOT__acq_wptr = vlSelfRef.rampart_i2c__DOT__acq_wptr;
    __Vdly__rampart_i2c__DOT__host_bit_idx = vlSelfRef.rampart_i2c__DOT__host_bit_idx;
    __Vdly__rampart_i2c__DOT__host_shift_reg = vlSelfRef.rampart_i2c__DOT__host_shift_reg;
    __Vdly__rampart_i2c__DOT__host_sda_drive_low = vlSelfRef.rampart_i2c__DOT__host_sda_drive_low;
    __Vdly__rampart_i2c__DOT__host_scl_drive_low = vlSelfRef.rampart_i2c__DOT__host_scl_drive_low;
    __Vdly__rampart_i2c__DOT__host_state = vlSelfRef.rampart_i2c__DOT__host_state;
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        if (vlSelfRef.rampart_i2c__DOT__fifo_ctrl_fmt_rst) {
            ++(vlSymsp->__Vcoverage[1833]);
            __Vdly__rampart_i2c__DOT__fifo_ctrl_fmt_rst = 0U;
        } else {
            ++(vlSymsp->__Vcoverage[1834]);
        }
        if (vlSelfRef.rampart_i2c__DOT__fifo_ctrl_rx_rst) {
            ++(vlSymsp->__Vcoverage[1835]);
            __Vdly__rampart_i2c__DOT__fifo_ctrl_rx_rst = 0U;
        } else {
            ++(vlSymsp->__Vcoverage[1836]);
        }
        if (vlSelfRef.rampart_i2c__DOT__fifo_ctrl_tx_rst) {
            ++(vlSymsp->__Vcoverage[1837]);
            __Vdly__rampart_i2c__DOT__fifo_ctrl_tx_rst = 0U;
        } else {
            ++(vlSymsp->__Vcoverage[1838]);
        }
        if (vlSelfRef.rampart_i2c__DOT__fifo_ctrl_acq_rst) {
            ++(vlSymsp->__Vcoverage[1839]);
            __Vdly__rampart_i2c__DOT__fifo_ctrl_acq_rst = 0U;
        } else {
            ++(vlSymsp->__Vcoverage[1840]);
        }
        if ((((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid) 
              & (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)) 
             & (0x00000010U == vlSelfRef.rampart_i2c__DOT__tl_req_addr))) {
            ++(vlSymsp->__Vcoverage[1841]);
            __Vdly__rampart_i2c__DOT__fifo_ctrl_fmt_rst 
                = (1U & vlSelfRef.rampart_i2c__DOT__tl_req_wdata);
            __Vdly__rampart_i2c__DOT__fifo_ctrl_rx_rst 
                = (1U & (vlSelfRef.rampart_i2c__DOT__tl_req_wdata 
                         >> 1U));
            __Vdly__rampart_i2c__DOT__fifo_ctrl_tx_rst 
                = (1U & (vlSelfRef.rampart_i2c__DOT__tl_req_wdata 
                         >> 2U));
            __Vdly__rampart_i2c__DOT__fifo_ctrl_acq_rst 
                = (1U & (vlSelfRef.rampart_i2c__DOT__tl_req_wdata 
                         >> 3U));
        } else {
            ++(vlSymsp->__Vcoverage[1842]);
        }
        if ((((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid) 
              & (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)) 
             & (0x00000010U == vlSelfRef.rampart_i2c__DOT__tl_req_addr))) {
            ++(vlSymsp->__Vcoverage[1843]);
        }
        if ((0x00000010U != vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
            ++(vlSymsp->__Vcoverage[1844]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)))) {
            ++(vlSymsp->__Vcoverage[1845]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid)))) {
            ++(vlSymsp->__Vcoverage[1846]);
        }
        ++(vlSymsp->__Vcoverage[1848]);
    } else {
        ++(vlSymsp->__Vcoverage[1847]);
        __Vdly__rampart_i2c__DOT__fifo_ctrl_fmt_rst = 0U;
        __Vdly__rampart_i2c__DOT__fifo_ctrl_rx_rst = 0U;
        __Vdly__rampart_i2c__DOT__fifo_ctrl_tx_rst = 0U;
        __Vdly__rampart_i2c__DOT__fifo_ctrl_acq_rst = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[1849]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[1850]);
    }
    ++(vlSymsp->__Vcoverage[1851]);
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        if (vlSelfRef.rampart_i2c__DOT__fifo_ctrl_acq_rst) {
            ++(vlSymsp->__Vcoverage[1963]);
            __Vdly__rampart_i2c__DOT__acq_rptr = 0U;
        } else {
            if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_pop) 
                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_empty)))) {
                __Vdly__rampart_i2c__DOT__acq_rptr 
                    = (0x0000007fU & ((IData)(1U) + (IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr)));
                ++(vlSymsp->__Vcoverage[1958]);
            } else {
                ++(vlSymsp->__Vcoverage[1959]);
            }
            if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_pop) 
                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_empty)))) {
                ++(vlSymsp->__Vcoverage[1960]);
            }
            if (vlSelfRef.rampart_i2c__DOT__acq_fifo_empty) {
                ++(vlSymsp->__Vcoverage[1961]);
            }
            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_pop)))) {
                ++(vlSymsp->__Vcoverage[1962]);
            }
        }
    } else {
        ++(vlSymsp->__Vcoverage[1964]);
        __Vdly__rampart_i2c__DOT__acq_rptr = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[1965]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[1966]);
    }
    ++(vlSymsp->__Vcoverage[1967]);
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        if (vlSelfRef.rampart_i2c__DOT__fifo_ctrl_tx_rst) {
            ++(vlSymsp->__Vcoverage[1928]);
            __Vdly__rampart_i2c__DOT__tx_wptr = 0U;
        } else {
            if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_push) 
                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_full)))) {
                ++(vlSymsp->__Vcoverage[1923]);
                __VdlyVal__rampart_i2c__DOT__tx_fifo_mem__v0 
                    = vlSelfRef.rampart_i2c__DOT__tx_fifo_wdata;
                __VdlyDim0__rampart_i2c__DOT__tx_fifo_mem__v0 
                    = (0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr));
                __VdlySet__rampart_i2c__DOT__tx_fifo_mem__v0 = 1U;
                __Vdly__rampart_i2c__DOT__tx_wptr = 
                    (0x0000007fU & ((IData)(1U) + (IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr)));
            } else {
                ++(vlSymsp->__Vcoverage[1924]);
            }
            if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_push) 
                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_full)))) {
                ++(vlSymsp->__Vcoverage[1925]);
            }
            if (vlSelfRef.rampart_i2c__DOT__tx_fifo_full) {
                ++(vlSymsp->__Vcoverage[1926]);
            }
            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_push)))) {
                ++(vlSymsp->__Vcoverage[1927]);
            }
        }
    } else {
        ++(vlSymsp->__Vcoverage[1929]);
        __Vdly__rampart_i2c__DOT__tx_wptr = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[1930]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[1931]);
    }
    ++(vlSymsp->__Vcoverage[1932]);
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        if (vlSelfRef.rampart_i2c__DOT__fifo_ctrl_fmt_rst) {
            ++(vlSymsp->__Vcoverage[1888]);
            __Vdly__rampart_i2c__DOT__fmt_rptr = 0U;
        } else {
            if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_pop) 
                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty)))) {
                __Vdly__rampart_i2c__DOT__fmt_rptr 
                    = (0x0000007fU & ((IData)(1U) + (IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr)));
                ++(vlSymsp->__Vcoverage[1883]);
            } else {
                ++(vlSymsp->__Vcoverage[1884]);
            }
            if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_pop) 
                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty)))) {
                ++(vlSymsp->__Vcoverage[1885]);
            }
            if (vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty) {
                ++(vlSymsp->__Vcoverage[1886]);
            }
            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_pop)))) {
                ++(vlSymsp->__Vcoverage[1887]);
            }
        }
    } else {
        ++(vlSymsp->__Vcoverage[1889]);
        __Vdly__rampart_i2c__DOT__fmt_rptr = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[1890]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[1891]);
    }
    ++(vlSymsp->__Vcoverage[1892]);
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        if (vlSelfRef.rampart_i2c__DOT__fifo_ctrl_rx_rst) {
            ++(vlSymsp->__Vcoverage[1913]);
            __Vdly__rampart_i2c__DOT__rx_rptr = 0U;
        } else {
            if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_pop) 
                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_empty)))) {
                __Vdly__rampart_i2c__DOT__rx_rptr = 
                    (0x0000007fU & ((IData)(1U) + (IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr)));
                ++(vlSymsp->__Vcoverage[1908]);
            } else {
                ++(vlSymsp->__Vcoverage[1909]);
            }
            if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_pop) 
                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_empty)))) {
                ++(vlSymsp->__Vcoverage[1910]);
            }
            if (vlSelfRef.rampart_i2c__DOT__rx_fifo_empty) {
                ++(vlSymsp->__Vcoverage[1911]);
            }
            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_pop)))) {
                ++(vlSymsp->__Vcoverage[1912]);
            }
        }
    } else {
        ++(vlSymsp->__Vcoverage[1914]);
        __Vdly__rampart_i2c__DOT__rx_rptr = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[1915]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[1916]);
    }
    ++(vlSymsp->__Vcoverage[1917]);
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        if (vlSelfRef.rampart_i2c__DOT__fifo_ctrl_rx_rst) {
            ++(vlSymsp->__Vcoverage[1903]);
            __Vdly__rampart_i2c__DOT__rx_wptr = 0U;
        } else {
            if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_push) 
                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_full)))) {
                ++(vlSymsp->__Vcoverage[1898]);
                __VdlyVal__rampart_i2c__DOT__rx_fifo_mem__v0 
                    = vlSelfRef.rampart_i2c__DOT__rx_fifo_wdata;
                __VdlyDim0__rampart_i2c__DOT__rx_fifo_mem__v0 
                    = (0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr));
                __VdlySet__rampart_i2c__DOT__rx_fifo_mem__v0 = 1U;
                __Vdly__rampart_i2c__DOT__rx_wptr = 
                    (0x0000007fU & ((IData)(1U) + (IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr)));
            } else {
                ++(vlSymsp->__Vcoverage[1899]);
            }
            if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_push) 
                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_full)))) {
                ++(vlSymsp->__Vcoverage[1900]);
            }
            if (vlSelfRef.rampart_i2c__DOT__rx_fifo_full) {
                ++(vlSymsp->__Vcoverage[1901]);
            }
            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_push)))) {
                ++(vlSymsp->__Vcoverage[1902]);
            }
        }
    } else {
        ++(vlSymsp->__Vcoverage[1904]);
        __Vdly__rampart_i2c__DOT__rx_wptr = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[1905]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[1906]);
    }
    ++(vlSymsp->__Vcoverage[1907]);
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        if (vlSelfRef.rampart_i2c__DOT__fifo_ctrl_fmt_rst) {
            ++(vlSymsp->__Vcoverage[1878]);
            __Vdly__rampart_i2c__DOT__fmt_wptr = 0U;
        } else {
            if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_push) 
                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_full)))) {
                ++(vlSymsp->__Vcoverage[1873]);
                __VdlyVal__rampart_i2c__DOT__fmt_fifo_mem__v0 
                    = vlSelfRef.rampart_i2c__DOT__fmt_fifo_wdata;
                __VdlyDim0__rampart_i2c__DOT__fmt_fifo_mem__v0 
                    = (0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr));
                __VdlySet__rampart_i2c__DOT__fmt_fifo_mem__v0 = 1U;
                __Vdly__rampart_i2c__DOT__fmt_wptr 
                    = (0x0000007fU & ((IData)(1U) + (IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr)));
            } else {
                ++(vlSymsp->__Vcoverage[1874]);
            }
            if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_push) 
                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_full)))) {
                ++(vlSymsp->__Vcoverage[1875]);
            }
            if (vlSelfRef.rampart_i2c__DOT__fmt_fifo_full) {
                ++(vlSymsp->__Vcoverage[1876]);
            }
            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_push)))) {
                ++(vlSymsp->__Vcoverage[1877]);
            }
        }
    } else {
        ++(vlSymsp->__Vcoverage[1879]);
        __Vdly__rampart_i2c__DOT__fmt_wptr = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[1880]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[1881]);
    }
    ++(vlSymsp->__Vcoverage[1882]);
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        if (vlSelfRef.rampart_i2c__DOT__fifo_ctrl_tx_rst) {
            ++(vlSymsp->__Vcoverage[1938]);
            __Vdly__rampart_i2c__DOT__tx_rptr = 0U;
        } else {
            if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_pop) 
                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_empty)))) {
                __Vdly__rampart_i2c__DOT__tx_rptr = 
                    (0x0000007fU & ((IData)(1U) + (IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr)));
                ++(vlSymsp->__Vcoverage[1933]);
            } else {
                ++(vlSymsp->__Vcoverage[1934]);
            }
            if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_pop) 
                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_empty)))) {
                ++(vlSymsp->__Vcoverage[1935]);
            }
            if (vlSelfRef.rampart_i2c__DOT__tx_fifo_empty) {
                ++(vlSymsp->__Vcoverage[1936]);
            }
            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_pop)))) {
                ++(vlSymsp->__Vcoverage[1937]);
            }
        }
    } else {
        ++(vlSymsp->__Vcoverage[1939]);
        __Vdly__rampart_i2c__DOT__tx_rptr = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[1940]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[1941]);
    }
    ++(vlSymsp->__Vcoverage[1942]);
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        if (vlSelfRef.rampart_i2c__DOT__fifo_ctrl_acq_rst) {
            ++(vlSymsp->__Vcoverage[1953]);
            __Vdly__rampart_i2c__DOT__acq_wptr = 0U;
        } else {
            if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_push) 
                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_full)))) {
                ++(vlSymsp->__Vcoverage[1948]);
                __VdlyVal__rampart_i2c__DOT__acq_fifo_mem__v0 
                    = vlSelfRef.rampart_i2c__DOT__acq_fifo_wdata;
                __VdlyDim0__rampart_i2c__DOT__acq_fifo_mem__v0 
                    = (0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr));
                __VdlySet__rampart_i2c__DOT__acq_fifo_mem__v0 = 1U;
                __Vdly__rampart_i2c__DOT__acq_wptr 
                    = (0x0000007fU & ((IData)(1U) + (IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr)));
            } else {
                ++(vlSymsp->__Vcoverage[1949]);
            }
            if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_push) 
                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_full)))) {
                ++(vlSymsp->__Vcoverage[1950]);
            }
            if (vlSelfRef.rampart_i2c__DOT__acq_fifo_full) {
                ++(vlSymsp->__Vcoverage[1951]);
            }
            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_push)))) {
                ++(vlSymsp->__Vcoverage[1952]);
            }
        }
    } else {
        ++(vlSymsp->__Vcoverage[1954]);
        __Vdly__rampart_i2c__DOT__acq_wptr = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[1955]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[1956]);
    }
    ++(vlSymsp->__Vcoverage[1957]);
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        if (vlSelfRef.rampart_i2c__DOT__start_det) {
            ++(vlSymsp->__Vcoverage[2018]);
            vlSelfRef.rampart_i2c__DOT__bus_active = 1U;
        } else if (vlSelfRef.rampart_i2c__DOT__stop_det) {
            ++(vlSymsp->__Vcoverage[2016]);
            vlSelfRef.rampart_i2c__DOT__bus_active = 0U;
        } else {
            ++(vlSymsp->__Vcoverage[2017]);
        }
        ++(vlSymsp->__Vcoverage[2020]);
    } else {
        ++(vlSymsp->__Vcoverage[2019]);
        vlSelfRef.rampart_i2c__DOT__bus_active = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[2021]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[2022]);
    }
    ++(vlSymsp->__Vcoverage[2023]);
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        vlSelfRef.rampart_i2c__DOT__rx_push_valid = 0U;
        if ((((7U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
              & (IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done)) 
             & (0U != (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx)))) {
            ++(vlSymsp->__Vcoverage[2202]);
            vlSelfRef.rampart_i2c__DOT__rx_push_valid = 1U;
            vlSelfRef.rampart_i2c__DOT__rx_push_data 
                = vlSelfRef.rampart_i2c__DOT__host_read_shift;
        } else {
            ++(vlSymsp->__Vcoverage[2203]);
        }
        if ((((7U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
              & (IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done)) 
             & (0U != (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx)))) {
            ++(vlSymsp->__Vcoverage[2204]);
        }
        if ((0U == (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx))) {
            ++(vlSymsp->__Vcoverage[2205]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done)))) {
            ++(vlSymsp->__Vcoverage[2206]);
        }
        if ((7U != (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
            ++(vlSymsp->__Vcoverage[2207]);
        }
        ++(vlSymsp->__Vcoverage[2209]);
    } else {
        ++(vlSymsp->__Vcoverage[2208]);
        vlSelfRef.rampart_i2c__DOT__rx_push_valid = 0U;
        vlSelfRef.rampart_i2c__DOT__rx_push_data = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[2210]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[2211]);
    }
    ++(vlSymsp->__Vcoverage[2212]);
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_rsp_pending) 
             & (IData)(vlSelfRef.rampart_i2c__DOT__tl_d_ready_i))) {
            ++(vlSymsp->__Vcoverage[1727]);
            __Vdly__rampart_i2c__DOT__tl_rsp_pending = 0U;
            vlSelfRef.rampart_i2c__DOT__tl_d_valid_o = 0U;
        } else {
            ++(vlSymsp->__Vcoverage[1728]);
        }
        if (vlSelfRef.rampart_i2c__DOT__tl_req_valid) {
            __Vdly__rampart_i2c__DOT__tl_rsp_pending = 1U;
            vlSelfRef.rampart_i2c__DOT__tl_d_valid_o = 1U;
            vlSelfRef.rampart_i2c__DOT__tl_d_opcode_o 
                = ((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)
                    ? ([&]() {
                        ++(vlSymsp->__Vcoverage[1734]);
                    }(), 0U) : ([&]() {
                        ++(vlSymsp->__Vcoverage[1735]);
                    }(), 1U));
            vlSelfRef.rampart_i2c__DOT__tl_d_data_o 
                = vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata;
            vlSelfRef.rampart_i2c__DOT__tl_d_source_o 
                = vlSelfRef.rampart_i2c__DOT__tl_req_source;
            vlSelfRef.rampart_i2c__DOT__tl_d_error_o 
                = vlSelfRef.rampart_i2c__DOT__tl_rsp_error;
            if (vlSelfRef.rampart_i2c__DOT__tl_req_write) {
                ++(vlSymsp->__Vcoverage[1732]);
            }
            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)))) {
                ++(vlSymsp->__Vcoverage[1733]);
            }
            ++(vlSymsp->__Vcoverage[1736]);
        } else {
            ++(vlSymsp->__Vcoverage[1737]);
        }
        if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_rsp_pending) 
             & (IData)(vlSelfRef.rampart_i2c__DOT__tl_d_ready_i))) {
            ++(vlSymsp->__Vcoverage[1729]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_d_ready_i)))) {
            ++(vlSymsp->__Vcoverage[1730]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_rsp_pending)))) {
            ++(vlSymsp->__Vcoverage[1731]);
        }
        ++(vlSymsp->__Vcoverage[1739]);
    } else {
        ++(vlSymsp->__Vcoverage[1738]);
        __Vdly__rampart_i2c__DOT__tl_rsp_pending = 0U;
        vlSelfRef.rampart_i2c__DOT__tl_d_valid_o = 0U;
        vlSelfRef.rampart_i2c__DOT__tl_d_opcode_o = 0U;
        vlSelfRef.rampart_i2c__DOT__tl_d_data_o = 0U;
        vlSelfRef.rampart_i2c__DOT__tl_d_source_o = 0U;
        vlSelfRef.rampart_i2c__DOT__tl_d_error_o = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[1740]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[1741]);
    }
    ++(vlSymsp->__Vcoverage[1742]);
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        __Vdly__rampart_i2c__DOT__intr_state = ((IData)(vlSelfRef.rampart_i2c__DOT__intr_state) 
                                                | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid) 
             & (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write))) {
            if ((0x00000040U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                __Vdly__rampart_i2c__DOT__intr_state 
                    = (((IData)(vlSelfRef.rampart_i2c__DOT__intr_state) 
                        | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set)) 
                       & (~ vlSelfRef.rampart_i2c__DOT__tl_req_wdata));
                ++(vlSymsp->__Vcoverage[1852]);
            } else {
                ++(vlSymsp->__Vcoverage[1853]);
            }
            if ((0x00000044U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                ++(vlSymsp->__Vcoverage[1854]);
                vlSelfRef.rampart_i2c__DOT__intr_enable 
                    = (0x0000ffffU & vlSelfRef.rampart_i2c__DOT__tl_req_wdata);
            } else {
                ++(vlSymsp->__Vcoverage[1855]);
            }
            if ((0x00000048U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                __Vdly__rampart_i2c__DOT__intr_state 
                    = (0x0000ffffU & (((IData)(vlSelfRef.rampart_i2c__DOT__intr_state) 
                                       | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set)) 
                                      | vlSelfRef.rampart_i2c__DOT__tl_req_wdata));
                ++(vlSymsp->__Vcoverage[1856]);
            } else {
                ++(vlSymsp->__Vcoverage[1857]);
            }
            ++(vlSymsp->__Vcoverage[1858]);
        } else {
            ++(vlSymsp->__Vcoverage[1859]);
        }
        if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid) 
             & (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write))) {
            ++(vlSymsp->__Vcoverage[1860]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)))) {
            ++(vlSymsp->__Vcoverage[1861]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid)))) {
            ++(vlSymsp->__Vcoverage[1862]);
        }
        ++(vlSymsp->__Vcoverage[1864]);
    } else {
        ++(vlSymsp->__Vcoverage[1863]);
        __Vdly__rampart_i2c__DOT__intr_state = 0U;
        vlSelfRef.rampart_i2c__DOT__intr_enable = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[1865]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[1866]);
    }
    ++(vlSymsp->__Vcoverage[1867]);
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        if ((((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid) 
              & (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)) 
             & (0x00000018U == vlSelfRef.rampart_i2c__DOT__tl_req_addr))) {
            ++(vlSymsp->__Vcoverage[1813]);
            vlSelfRef.rampart_i2c__DOT__ovrd_txovrden 
                = (1U & vlSelfRef.rampart_i2c__DOT__tl_req_wdata);
            vlSelfRef.rampart_i2c__DOT__ovrd_sclval 
                = (1U & (vlSelfRef.rampart_i2c__DOT__tl_req_wdata 
                         >> 1U));
            vlSelfRef.rampart_i2c__DOT__ovrd_sdaval 
                = (1U & (vlSelfRef.rampart_i2c__DOT__tl_req_wdata 
                         >> 2U));
        } else {
            ++(vlSymsp->__Vcoverage[1814]);
        }
        if ((((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid) 
              & (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)) 
             & (0x00000018U == vlSelfRef.rampart_i2c__DOT__tl_req_addr))) {
            ++(vlSymsp->__Vcoverage[1815]);
        }
        if ((0x00000018U != vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
            ++(vlSymsp->__Vcoverage[1816]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)))) {
            ++(vlSymsp->__Vcoverage[1817]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid)))) {
            ++(vlSymsp->__Vcoverage[1818]);
        }
    } else {
        ++(vlSymsp->__Vcoverage[1819]);
        vlSelfRef.rampart_i2c__DOT__ovrd_txovrden = 0U;
        vlSelfRef.rampart_i2c__DOT__ovrd_sclval = 1U;
        vlSelfRef.rampart_i2c__DOT__ovrd_sdaval = 1U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[1820]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[1821]);
    }
    ++(vlSymsp->__Vcoverage[1822]);
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[1977]);
        vlSelfRef.rampart_i2c__DOT__scl_in_qq = vlSelfRef.rampart_i2c__DOT__scl_in_q;
        vlSelfRef.rampart_i2c__DOT__sda_in_qq = vlSelfRef.rampart_i2c__DOT__sda_in_q;
        __Vdly__rampart_i2c__DOT__scl_in_q = vlSelfRef.rampart_i2c__DOT__scl_in;
        __Vdly__rampart_i2c__DOT__sda_in_q = vlSelfRef.rampart_i2c__DOT__sda_in;
    } else {
        ++(vlSymsp->__Vcoverage[1976]);
        __Vdly__rampart_i2c__DOT__scl_in_q = 1U;
        __Vdly__rampart_i2c__DOT__sda_in_q = 1U;
        vlSelfRef.rampart_i2c__DOT__scl_in_qq = 1U;
        vlSelfRef.rampart_i2c__DOT__sda_in_qq = 1U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[1978]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[1979]);
    }
    ++(vlSymsp->__Vcoverage[1980]);
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        vlSelfRef.rampart_i2c__DOT__host_timeout_event = 0U;
        if (vlSelfRef.rampart_i2c__DOT__host_timeout_en) {
            if (vlSelfRef.rampart_i2c__DOT__scl_in_q) {
                ++(vlSymsp->__Vcoverage[2319]);
                __Vdly__rampart_i2c__DOT__host_timeout_cnt = 0U;
            } else {
                if ((vlSelfRef.rampart_i2c__DOT__host_timeout_cnt 
                     < vlSelfRef.rampart_i2c__DOT__host_timeout_val)) {
                    __Vdly__rampart_i2c__DOT__host_timeout_cnt 
                        = (0x000fffffU & ((IData)(1U) 
                                          + vlSelfRef.rampart_i2c__DOT__host_timeout_cnt));
                    ++(vlSymsp->__Vcoverage[2316]);
                } else {
                    ++(vlSymsp->__Vcoverage[2317]);
                    vlSelfRef.rampart_i2c__DOT__host_timeout_event = 1U;
                }
                ++(vlSymsp->__Vcoverage[2318]);
            }
            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)))) {
                ++(vlSymsp->__Vcoverage[2320]);
            }
            if (vlSelfRef.rampart_i2c__DOT__scl_in_q) {
                ++(vlSymsp->__Vcoverage[2321]);
            }
            ++(vlSymsp->__Vcoverage[2322]);
        } else {
            __Vdly__rampart_i2c__DOT__host_timeout_cnt = 0U;
            ++(vlSymsp->__Vcoverage[2323]);
        }
        ++(vlSymsp->__Vcoverage[2325]);
    } else {
        __Vdly__rampart_i2c__DOT__host_timeout_cnt = 0U;
        ++(vlSymsp->__Vcoverage[2324]);
        vlSelfRef.rampart_i2c__DOT__host_timeout_event = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[2326]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[2327]);
    }
    ++(vlSymsp->__Vcoverage[2328]);
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        vlSelfRef.rampart_i2c__DOT__fmt_pop_req = 0U;
        vlSelfRef.rampart_i2c__DOT__host_arb_lost = 0U;
        if ((0U < (IData)(vlSelfRef.rampart_i2c__DOT__host_timing_cnt))) {
            vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                = (0x0000ffffU & ((IData)(vlSelfRef.rampart_i2c__DOT__host_timing_cnt) 
                                  - (IData)(1U)));
            ++(vlSymsp->__Vcoverage[2047]);
        } else {
            ++(vlSymsp->__Vcoverage[2048]);
        }
        if ((8U & (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
            if ((4U & (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
                ++(vlSymsp->__Vcoverage[2174]);
                __Vdly__rampart_i2c__DOT__host_state = 0U;
            } else if ((2U & (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
                if ((1U & (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
                    ++(vlSymsp->__Vcoverage[2174]);
                    __Vdly__rampart_i2c__DOT__host_state = 0U;
                } else {
                    if (vlSelfRef.rampart_i2c__DOT__host_timing_done) {
                        ++(vlSymsp->__Vcoverage[2171]);
                        __Vdly__rampart_i2c__DOT__host_state = 0U;
                    } else {
                        ++(vlSymsp->__Vcoverage[2172]);
                    }
                    ++(vlSymsp->__Vcoverage[2173]);
                }
            } else if ((1U & (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
                if (vlSelfRef.rampart_i2c__DOT__host_timing_done) {
                    if ((0U == (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx))) {
                        vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                            = vlSelfRef.rampart_i2c__DOT__timing_tlow;
                        ++(vlSymsp->__Vcoverage[2167]);
                        __Vdly__rampart_i2c__DOT__host_sda_drive_low = 0U;
                        __Vdly__rampart_i2c__DOT__host_scl_drive_low = 1U;
                        __Vdly__rampart_i2c__DOT__host_bit_idx = 1U;
                    } else if ((1U == (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx))) {
                        vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                            = vlSelfRef.rampart_i2c__DOT__timing_tsu_sta;
                        ++(vlSymsp->__Vcoverage[2165]);
                        __Vdly__rampart_i2c__DOT__host_scl_drive_low = 0U;
                        __Vdly__rampart_i2c__DOT__host_bit_idx = 2U;
                    } else {
                        vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                            = vlSelfRef.rampart_i2c__DOT__timing_thd_sta;
                        ++(vlSymsp->__Vcoverage[2166]);
                        __Vdly__rampart_i2c__DOT__host_sda_drive_low = 1U;
                        __Vdly__rampart_i2c__DOT__host_shift_reg 
                            = (0x000000ffU & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata));
                        vlSelfRef.rampart_i2c__DOT__fmt_pop_req = 1U;
                        __Vdly__rampart_i2c__DOT__host_state = 2U;
                        __Vdly__rampart_i2c__DOT__host_bit_idx = 0U;
                    }
                    ++(vlSymsp->__Vcoverage[2168]);
                } else {
                    ++(vlSymsp->__Vcoverage[2169]);
                }
                ++(vlSymsp->__Vcoverage[2170]);
            } else {
                if (vlSelfRef.rampart_i2c__DOT__host_timing_done) {
                    if ((0U == (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx))) {
                        vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                            = vlSelfRef.rampart_i2c__DOT__timing_tlow;
                        __Vdly__rampart_i2c__DOT__host_bit_idx = 1U;
                        ++(vlSymsp->__Vcoverage[2161]);
                        __Vdly__rampart_i2c__DOT__host_scl_drive_low = 1U;
                        __Vdly__rampart_i2c__DOT__host_sda_drive_low = 1U;
                    } else if ((1U == (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx))) {
                        vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                            = vlSelfRef.rampart_i2c__DOT__timing_tsu_sto;
                        __Vdly__rampart_i2c__DOT__host_bit_idx = 2U;
                        ++(vlSymsp->__Vcoverage[2159]);
                        __Vdly__rampart_i2c__DOT__host_scl_drive_low = 0U;
                    } else {
                        vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                            = vlSelfRef.rampart_i2c__DOT__timing_t_buf;
                        __Vdly__rampart_i2c__DOT__host_bit_idx = 0U;
                        ++(vlSymsp->__Vcoverage[2160]);
                        __Vdly__rampart_i2c__DOT__host_sda_drive_low = 0U;
                        __Vdly__rampart_i2c__DOT__host_scl_drive_low = 0U;
                        __Vdly__rampart_i2c__DOT__host_state = 0x0aU;
                    }
                    ++(vlSymsp->__Vcoverage[2162]);
                } else {
                    ++(vlSymsp->__Vcoverage[2163]);
                }
                ++(vlSymsp->__Vcoverage[2164]);
            }
        } else if ((4U & (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
            if ((2U & (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
                if ((1U & (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
                    if (vlSelfRef.rampart_i2c__DOT__host_timing_done) {
                        if (((IData)(vlSelfRef.rampart_i2c__DOT__host_scl_drive_low) 
                             & (0U == (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx)))) {
                            vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                                = vlSelfRef.rampart_i2c__DOT__timing_thigh;
                            __Vdly__rampart_i2c__DOT__host_bit_idx = 1U;
                            if (vlSelfRef.rampart_i2c__DOT__host_read_rcont) {
                                ++(vlSymsp->__Vcoverage[2141]);
                                __Vdly__rampart_i2c__DOT__host_sda_drive_low = 1U;
                            } else {
                                ++(vlSymsp->__Vcoverage[2142]);
                                __Vdly__rampart_i2c__DOT__host_sda_drive_low = 0U;
                            }
                            __Vdly__rampart_i2c__DOT__host_scl_drive_low = 0U;
                            ++(vlSymsp->__Vcoverage[2151]);
                        } else {
                            vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                                = vlSelfRef.rampart_i2c__DOT__timing_tlow;
                            __Vdly__rampart_i2c__DOT__host_bit_idx = 0U;
                            __Vdly__rampart_i2c__DOT__host_scl_drive_low = 1U;
                            __Vdly__rampart_i2c__DOT__host_sda_drive_low = 0U;
                            if ((1U < (IData)(vlSelfRef.rampart_i2c__DOT__host_read_byte_cnt))) {
                                vlSelfRef.rampart_i2c__DOT__host_read_byte_cnt 
                                    = (0x000000ffU 
                                       & ((IData)(vlSelfRef.rampart_i2c__DOT__host_read_byte_cnt) 
                                          - (IData)(1U)));
                                ++(vlSymsp->__Vcoverage[2150]);
                                __Vdly__rampart_i2c__DOT__host_state = 6U;
                            } else if (vlSelfRef.rampart_i2c__DOT__host_read_stop) {
                                ++(vlSymsp->__Vcoverage[2149]);
                                __Vdly__rampart_i2c__DOT__host_state = 8U;
                            } else {
                                if (vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty) {
                                    ++(vlSymsp->__Vcoverage[2146]);
                                    __Vdly__rampart_i2c__DOT__host_state = 0U;
                                } else {
                                    if ((0x00000100U 
                                         & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata))) {
                                        ++(vlSymsp->__Vcoverage[2143]);
                                        __Vdly__rampart_i2c__DOT__host_state = 9U;
                                    } else {
                                        ++(vlSymsp->__Vcoverage[2144]);
                                        __Vdly__rampart_i2c__DOT__host_state = 0U;
                                    }
                                    ++(vlSymsp->__Vcoverage[2145]);
                                }
                                if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty)))) {
                                    ++(vlSymsp->__Vcoverage[2147]);
                                }
                                if (vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty) {
                                    ++(vlSymsp->__Vcoverage[2148]);
                                }
                            }
                            ++(vlSymsp->__Vcoverage[2152]);
                        }
                        if (((IData)(vlSelfRef.rampart_i2c__DOT__host_scl_drive_low) 
                             & (0U == (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx)))) {
                            ++(vlSymsp->__Vcoverage[2153]);
                        }
                        if ((0U != (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx))) {
                            ++(vlSymsp->__Vcoverage[2154]);
                        }
                        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_scl_drive_low)))) {
                            ++(vlSymsp->__Vcoverage[2155]);
                        }
                        ++(vlSymsp->__Vcoverage[2156]);
                    } else {
                        ++(vlSymsp->__Vcoverage[2157]);
                    }
                    ++(vlSymsp->__Vcoverage[2158]);
                } else {
                    if (vlSelfRef.rampart_i2c__DOT__host_timing_done) {
                        if (vlSelfRef.rampart_i2c__DOT__host_scl_drive_low) {
                            vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                                = vlSelfRef.rampart_i2c__DOT__timing_thigh;
                            ++(vlSymsp->__Vcoverage[2136]);
                            __Vdly__rampart_i2c__DOT__host_scl_drive_low = 0U;
                            __Vdly__rampart_i2c__DOT__host_sda_drive_low = 0U;
                        } else {
                            vlSelfRef.rampart_i2c__DOT__host_read_shift 
                                = ((0x000000feU & ((IData)(vlSelfRef.rampart_i2c__DOT__host_read_shift) 
                                                   << 1U)) 
                                   | (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q));
                            vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                                = vlSelfRef.rampart_i2c__DOT__timing_tlow;
                            __Vdly__rampart_i2c__DOT__host_scl_drive_low = 1U;
                            if ((7U > (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx))) {
                                __Vdly__rampart_i2c__DOT__host_bit_idx 
                                    = (0x0000000fU 
                                       & ((IData)(1U) 
                                          + (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx)));
                                ++(vlSymsp->__Vcoverage[2134]);
                            } else {
                                __Vdly__rampart_i2c__DOT__host_bit_idx = 0U;
                                ++(vlSymsp->__Vcoverage[2135]);
                                __Vdly__rampart_i2c__DOT__host_state = 7U;
                            }
                            ++(vlSymsp->__Vcoverage[2137]);
                        }
                        ++(vlSymsp->__Vcoverage[2138]);
                    } else {
                        ++(vlSymsp->__Vcoverage[2139]);
                    }
                    ++(vlSymsp->__Vcoverage[2140]);
                }
            } else if ((1U & (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
                if (vlSelfRef.rampart_i2c__DOT__host_timing_done) {
                    if (vlSelfRef.rampart_i2c__DOT__host_scl_drive_low) {
                        vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                            = vlSelfRef.rampart_i2c__DOT__timing_thigh;
                        ++(vlSymsp->__Vcoverage[2129]);
                        __Vdly__rampart_i2c__DOT__host_scl_drive_low = 0U;
                    } else {
                        vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                            = vlSelfRef.rampart_i2c__DOT__timing_tlow;
                        vlSelfRef.rampart_i2c__DOT__host_ack_received 
                            = (1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)));
                        __Vdly__rampart_i2c__DOT__host_scl_drive_low = 1U;
                        if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q) 
                             & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_nakok)))) {
                            ++(vlSymsp->__Vcoverage[2125]);
                            __Vdly__rampart_i2c__DOT__host_state = 8U;
                        } else {
                            if (vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty) {
                                ++(vlSymsp->__Vcoverage[2122]);
                                __Vdly__rampart_i2c__DOT__host_state = 8U;
                            } else {
                                if ((0x00000100U & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata))) {
                                    ++(vlSymsp->__Vcoverage[2120]);
                                    __Vdly__rampart_i2c__DOT__host_state = 9U;
                                } else if ((0x00000400U 
                                            & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata))) {
                                    vlSelfRef.rampart_i2c__DOT__host_read_byte_cnt 
                                        = (0x000000ffU 
                                           & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata));
                                    __Vdly__rampart_i2c__DOT__host_bit_idx = 0U;
                                    ++(vlSymsp->__Vcoverage[2118]);
                                    vlSelfRef.rampart_i2c__DOT__host_read_rcont 
                                        = (1U & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata) 
                                                 >> 0x0bU));
                                    vlSelfRef.rampart_i2c__DOT__host_read_stop 
                                        = (1U & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata) 
                                                 >> 9U));
                                    __Vdly__rampart_i2c__DOT__host_state = 6U;
                                    __Vdly__rampart_i2c__DOT__host_sda_drive_low = 0U;
                                    vlSelfRef.rampart_i2c__DOT__fmt_pop_req = 1U;
                                } else {
                                    __Vdly__rampart_i2c__DOT__host_bit_idx = 0U;
                                    if ((1U & (~ ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata) 
                                                  >> 7U)))) {
                                        ++(vlSymsp->__Vcoverage[2116]);
                                    }
                                    __Vdly__rampart_i2c__DOT__host_shift_reg 
                                        = (0x000000ffU 
                                           & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata));
                                    __Vdly__rampart_i2c__DOT__host_sda_drive_low 
                                        = (1U & (~ 
                                                 ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata) 
                                                  >> 7U)));
                                    __Vdly__rampart_i2c__DOT__host_state = 4U;
                                    vlSelfRef.rampart_i2c__DOT__fmt_pop_req = 1U;
                                    if ((0x00000080U 
                                         & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata))) {
                                        ++(vlSymsp->__Vcoverage[2117]);
                                    }
                                    ++(vlSymsp->__Vcoverage[2119]);
                                }
                                ++(vlSymsp->__Vcoverage[2121]);
                            }
                            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty)))) {
                                ++(vlSymsp->__Vcoverage[2123]);
                            }
                            if (vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty) {
                                ++(vlSymsp->__Vcoverage[2124]);
                            }
                        }
                        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)))) {
                            ++(vlSymsp->__Vcoverage[2114]);
                        }
                        if (vlSelfRef.rampart_i2c__DOT__sda_in_q) {
                            ++(vlSymsp->__Vcoverage[2115]);
                        }
                        if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q) 
                             & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_nakok)))) {
                            ++(vlSymsp->__Vcoverage[2126]);
                        }
                        if (vlSelfRef.rampart_i2c__DOT__host_cmd_nakok) {
                            ++(vlSymsp->__Vcoverage[2127]);
                        }
                        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)))) {
                            ++(vlSymsp->__Vcoverage[2128]);
                        }
                        ++(vlSymsp->__Vcoverage[2130]);
                    }
                    ++(vlSymsp->__Vcoverage[2131]);
                } else {
                    ++(vlSymsp->__Vcoverage[2132]);
                }
                ++(vlSymsp->__Vcoverage[2133]);
            } else {
                if (vlSelfRef.rampart_i2c__DOT__host_timing_done) {
                    if (vlSelfRef.rampart_i2c__DOT__host_scl_drive_low) {
                        vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                            = vlSelfRef.rampart_i2c__DOT__timing_thigh;
                        ++(vlSymsp->__Vcoverage[2109]);
                        __Vdly__rampart_i2c__DOT__host_scl_drive_low = 0U;
                    } else {
                        if ((1U & ((~ (IData)(vlSelfRef.rampart_i2c__DOT__host_sda_drive_low)) 
                                   & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q))))) {
                            ++(vlSymsp->__Vcoverage[2104]);
                            vlSelfRef.rampart_i2c__DOT__host_arb_lost = 1U;
                            __Vdly__rampart_i2c__DOT__host_scl_drive_low = 0U;
                            __Vdly__rampart_i2c__DOT__host_sda_drive_low = 0U;
                            __Vdly__rampart_i2c__DOT__host_state = 0U;
                        } else {
                            __Vdly__rampart_i2c__DOT__host_scl_drive_low = 1U;
                            if ((7U > (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx))) {
                                __Vdly__rampart_i2c__DOT__host_bit_idx 
                                    = (0x0000000fU 
                                       & ((IData)(1U) 
                                          + (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx)));
                                vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                                    = vlSelfRef.rampart_i2c__DOT__timing_tlow;
                                __Vdly__rampart_i2c__DOT__host_sda_drive_low 
                                    = (1U & (~ ((IData)(vlSelfRef.rampart_i2c__DOT__host_shift_reg) 
                                                >> 
                                                (7U 
                                                 & ((IData)(6U) 
                                                    - (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx))))));
                                if ((1U & (~ ((IData)(vlSelfRef.rampart_i2c__DOT__host_shift_reg) 
                                              >> (7U 
                                                  & ((IData)(6U) 
                                                     - (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx))))))) {
                                    ++(vlSymsp->__Vcoverage[2100]);
                                }
                                if ((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__host_shift_reg) 
                                           >> (7U & 
                                               ((IData)(6U) 
                                                - (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx)))))) {
                                    ++(vlSymsp->__Vcoverage[2101]);
                                }
                                ++(vlSymsp->__Vcoverage[2102]);
                            } else {
                                vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                                    = vlSelfRef.rampart_i2c__DOT__timing_tlow;
                                __Vdly__rampart_i2c__DOT__host_bit_idx = 0U;
                                ++(vlSymsp->__Vcoverage[2103]);
                                __Vdly__rampart_i2c__DOT__host_sda_drive_low = 0U;
                                __Vdly__rampart_i2c__DOT__host_state = 5U;
                            }
                            ++(vlSymsp->__Vcoverage[2105]);
                        }
                        if ((1U & ((~ (IData)(vlSelfRef.rampart_i2c__DOT__host_sda_drive_low)) 
                                   & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q))))) {
                            ++(vlSymsp->__Vcoverage[2106]);
                        }
                        if (vlSelfRef.rampart_i2c__DOT__sda_in_q) {
                            ++(vlSymsp->__Vcoverage[2107]);
                        }
                        if (vlSelfRef.rampart_i2c__DOT__host_sda_drive_low) {
                            ++(vlSymsp->__Vcoverage[2108]);
                        }
                        ++(vlSymsp->__Vcoverage[2110]);
                    }
                    ++(vlSymsp->__Vcoverage[2111]);
                } else {
                    ++(vlSymsp->__Vcoverage[2112]);
                }
                ++(vlSymsp->__Vcoverage[2113]);
            }
        } else if ((2U & (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
            if ((1U & (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
                if (vlSelfRef.rampart_i2c__DOT__host_timing_done) {
                    if (vlSelfRef.rampart_i2c__DOT__host_scl_drive_low) {
                        vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                            = vlSelfRef.rampart_i2c__DOT__timing_thigh;
                        ++(vlSymsp->__Vcoverage[2095]);
                        __Vdly__rampart_i2c__DOT__host_scl_drive_low = 0U;
                    } else {
                        vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                            = vlSelfRef.rampart_i2c__DOT__timing_tlow;
                        vlSelfRef.rampart_i2c__DOT__host_ack_received 
                            = (1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)));
                        __Vdly__rampart_i2c__DOT__host_scl_drive_low = 1U;
                        vlSelfRef.rampart_i2c__DOT__fmt_pop_req = 1U;
                        if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q) 
                             & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_nakok)))) {
                            ++(vlSymsp->__Vcoverage[2091]);
                            __Vdly__rampart_i2c__DOT__host_state = 8U;
                        } else {
                            if (((IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_stop) 
                                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_readb)))) {
                                ++(vlSymsp->__Vcoverage[2087]);
                                __Vdly__rampart_i2c__DOT__host_state = 8U;
                            } else if (vlSelfRef.rampart_i2c__DOT__host_cmd_readb) {
                                vlSelfRef.rampart_i2c__DOT__host_read_byte_cnt 
                                    = vlSelfRef.rampart_i2c__DOT__host_cmd_byte;
                                __Vdly__rampart_i2c__DOT__host_bit_idx = 0U;
                                ++(vlSymsp->__Vcoverage[2085]);
                                vlSelfRef.rampart_i2c__DOT__host_read_rcont 
                                    = vlSelfRef.rampart_i2c__DOT__host_cmd_rcont;
                                vlSelfRef.rampart_i2c__DOT__host_read_stop 
                                    = vlSelfRef.rampart_i2c__DOT__host_cmd_stop;
                                __Vdly__rampart_i2c__DOT__host_state = 6U;
                                __Vdly__rampart_i2c__DOT__host_sda_drive_low = 0U;
                            } else {
                                ++(vlSymsp->__Vcoverage[2086]);
                                __Vdly__rampart_i2c__DOT__host_state = 0U;
                            }
                            if (((IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_stop) 
                                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_readb)))) {
                                ++(vlSymsp->__Vcoverage[2088]);
                            }
                            if (vlSelfRef.rampart_i2c__DOT__host_cmd_readb) {
                                ++(vlSymsp->__Vcoverage[2089]);
                            }
                            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_stop)))) {
                                ++(vlSymsp->__Vcoverage[2090]);
                            }
                        }
                        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)))) {
                            ++(vlSymsp->__Vcoverage[2083]);
                        }
                        if (vlSelfRef.rampart_i2c__DOT__sda_in_q) {
                            ++(vlSymsp->__Vcoverage[2084]);
                        }
                        if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q) 
                             & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_nakok)))) {
                            ++(vlSymsp->__Vcoverage[2092]);
                        }
                        if (vlSelfRef.rampart_i2c__DOT__host_cmd_nakok) {
                            ++(vlSymsp->__Vcoverage[2093]);
                        }
                        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)))) {
                            ++(vlSymsp->__Vcoverage[2094]);
                        }
                        ++(vlSymsp->__Vcoverage[2096]);
                    }
                    ++(vlSymsp->__Vcoverage[2097]);
                } else {
                    ++(vlSymsp->__Vcoverage[2098]);
                }
                ++(vlSymsp->__Vcoverage[2099]);
            } else {
                if (vlSelfRef.rampart_i2c__DOT__host_timing_done) {
                    if (((0U == (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx)) 
                         & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_scl_drive_low)))) {
                        vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                            = vlSelfRef.rampart_i2c__DOT__timing_tlow;
                        __Vdly__rampart_i2c__DOT__host_bit_idx = 0U;
                        __Vdly__rampart_i2c__DOT__host_scl_drive_low = 1U;
                        __Vdly__rampart_i2c__DOT__host_sda_drive_low 
                            = (1U & (~ ((IData)(vlSelfRef.rampart_i2c__DOT__host_shift_reg) 
                                        >> 7U)));
                        if ((1U & (~ ((IData)(vlSelfRef.rampart_i2c__DOT__host_shift_reg) 
                                      >> 7U)))) {
                            ++(vlSymsp->__Vcoverage[2063]);
                        }
                        if ((0x00000080U & (IData)(vlSelfRef.rampart_i2c__DOT__host_shift_reg))) {
                            ++(vlSymsp->__Vcoverage[2064]);
                        }
                        ++(vlSymsp->__Vcoverage[2076]);
                    } else if (vlSelfRef.rampart_i2c__DOT__host_scl_drive_low) {
                        vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                            = vlSelfRef.rampart_i2c__DOT__timing_thigh;
                        ++(vlSymsp->__Vcoverage[2074]);
                        __Vdly__rampart_i2c__DOT__host_scl_drive_low = 0U;
                    } else {
                        if ((1U & ((~ (IData)(vlSelfRef.rampart_i2c__DOT__host_sda_drive_low)) 
                                   & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q))))) {
                            ++(vlSymsp->__Vcoverage[2069]);
                            vlSelfRef.rampart_i2c__DOT__host_arb_lost = 1U;
                            __Vdly__rampart_i2c__DOT__host_scl_drive_low = 0U;
                            __Vdly__rampart_i2c__DOT__host_sda_drive_low = 0U;
                            __Vdly__rampart_i2c__DOT__host_state = 0U;
                            vlSelfRef.rampart_i2c__DOT__fmt_pop_req = 1U;
                        } else {
                            __Vdly__rampart_i2c__DOT__host_scl_drive_low = 1U;
                            if ((7U > (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx))) {
                                __Vdly__rampart_i2c__DOT__host_bit_idx 
                                    = (0x0000000fU 
                                       & ((IData)(1U) 
                                          + (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx)));
                                vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                                    = vlSelfRef.rampart_i2c__DOT__timing_tlow;
                                __Vdly__rampart_i2c__DOT__host_sda_drive_low 
                                    = (1U & (~ ((IData)(vlSelfRef.rampart_i2c__DOT__host_shift_reg) 
                                                >> 
                                                (7U 
                                                 & ((IData)(6U) 
                                                    - (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx))))));
                                if ((1U & (~ ((IData)(vlSelfRef.rampart_i2c__DOT__host_shift_reg) 
                                              >> (7U 
                                                  & ((IData)(6U) 
                                                     - (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx))))))) {
                                    ++(vlSymsp->__Vcoverage[2065]);
                                }
                                if ((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__host_shift_reg) 
                                           >> (7U & 
                                               ((IData)(6U) 
                                                - (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx)))))) {
                                    ++(vlSymsp->__Vcoverage[2066]);
                                }
                                ++(vlSymsp->__Vcoverage[2067]);
                            } else {
                                vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                                    = vlSelfRef.rampart_i2c__DOT__timing_tlow;
                                __Vdly__rampart_i2c__DOT__host_bit_idx = 0U;
                                ++(vlSymsp->__Vcoverage[2068]);
                                __Vdly__rampart_i2c__DOT__host_sda_drive_low = 0U;
                                __Vdly__rampart_i2c__DOT__host_state = 3U;
                            }
                            ++(vlSymsp->__Vcoverage[2070]);
                        }
                        if ((1U & ((~ (IData)(vlSelfRef.rampart_i2c__DOT__host_sda_drive_low)) 
                                   & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q))))) {
                            ++(vlSymsp->__Vcoverage[2071]);
                        }
                        if (vlSelfRef.rampart_i2c__DOT__sda_in_q) {
                            ++(vlSymsp->__Vcoverage[2072]);
                        }
                        if (vlSelfRef.rampart_i2c__DOT__host_sda_drive_low) {
                            ++(vlSymsp->__Vcoverage[2073]);
                        }
                        ++(vlSymsp->__Vcoverage[2075]);
                    }
                    if (((0U == (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx)) 
                         & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_scl_drive_low)))) {
                        ++(vlSymsp->__Vcoverage[2077]);
                    }
                    if (vlSelfRef.rampart_i2c__DOT__host_scl_drive_low) {
                        ++(vlSymsp->__Vcoverage[2078]);
                    }
                    if ((0U != (IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx))) {
                        ++(vlSymsp->__Vcoverage[2079]);
                    }
                    ++(vlSymsp->__Vcoverage[2080]);
                } else {
                    ++(vlSymsp->__Vcoverage[2081]);
                }
                ++(vlSymsp->__Vcoverage[2082]);
            }
        } else if ((1U & (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
            if (vlSelfRef.rampart_i2c__DOT__host_timing_done) {
                vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                    = vlSelfRef.rampart_i2c__DOT__timing_thd_sta;
                __Vdly__rampart_i2c__DOT__host_bit_idx = 0U;
                ++(vlSymsp->__Vcoverage[2060]);
                __Vdly__rampart_i2c__DOT__host_sda_drive_low = 1U;
                __Vdly__rampart_i2c__DOT__host_state = 2U;
            } else {
                ++(vlSymsp->__Vcoverage[2061]);
            }
            ++(vlSymsp->__Vcoverage[2062]);
        } else {
            __Vdly__rampart_i2c__DOT__host_scl_drive_low = 0U;
            __Vdly__rampart_i2c__DOT__host_sda_drive_low = 0U;
            __Vdly__rampart_i2c__DOT__host_bit_idx = 0U;
            if (((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable) 
                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty)))) {
                if (vlSelfRef.rampart_i2c__DOT__host_cmd_start) {
                    vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                        = vlSelfRef.rampart_i2c__DOT__timing_tsu_sta;
                    ++(vlSymsp->__Vcoverage[2053]);
                    __Vdly__rampart_i2c__DOT__host_sda_drive_low = 0U;
                    __Vdly__rampart_i2c__DOT__host_scl_drive_low = 0U;
                    __Vdly__rampart_i2c__DOT__host_state = 1U;
                    __Vdly__rampart_i2c__DOT__host_shift_reg 
                        = vlSelfRef.rampart_i2c__DOT__host_cmd_byte;
                } else if (vlSelfRef.rampart_i2c__DOT__host_cmd_readb) {
                    vlSelfRef.rampart_i2c__DOT__host_read_byte_cnt 
                        = vlSelfRef.rampart_i2c__DOT__host_cmd_byte;
                    __Vdly__rampart_i2c__DOT__host_bit_idx = 0U;
                    vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                        = vlSelfRef.rampart_i2c__DOT__timing_thd_dat;
                    ++(vlSymsp->__Vcoverage[2051]);
                    vlSelfRef.rampart_i2c__DOT__host_read_rcont 
                        = vlSelfRef.rampart_i2c__DOT__host_cmd_rcont;
                    vlSelfRef.rampart_i2c__DOT__host_read_stop 
                        = vlSelfRef.rampart_i2c__DOT__host_cmd_stop;
                    __Vdly__rampart_i2c__DOT__host_state = 6U;
                    __Vdly__rampart_i2c__DOT__host_scl_drive_low = 1U;
                    __Vdly__rampart_i2c__DOT__host_sda_drive_low = 0U;
                    vlSelfRef.rampart_i2c__DOT__fmt_pop_req = 1U;
                } else {
                    __Vdly__rampart_i2c__DOT__host_bit_idx = 0U;
                    vlSelfRef.rampart_i2c__DOT__host_timing_cnt 
                        = vlSelfRef.rampart_i2c__DOT__timing_thd_dat;
                    if ((1U & (~ ((IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_byte) 
                                  >> 7U)))) {
                        ++(vlSymsp->__Vcoverage[2049]);
                    }
                    __Vdly__rampart_i2c__DOT__host_shift_reg 
                        = vlSelfRef.rampart_i2c__DOT__host_cmd_byte;
                    __Vdly__rampart_i2c__DOT__host_state = 4U;
                    __Vdly__rampart_i2c__DOT__host_scl_drive_low = 1U;
                    __Vdly__rampart_i2c__DOT__host_sda_drive_low 
                        = (1U & (~ ((IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_byte) 
                                    >> 7U)));
                    vlSelfRef.rampart_i2c__DOT__fmt_pop_req = 1U;
                    if ((0x00000080U & (IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_byte))) {
                        ++(vlSymsp->__Vcoverage[2050]);
                    }
                    ++(vlSymsp->__Vcoverage[2052]);
                }
                ++(vlSymsp->__Vcoverage[2054]);
            } else {
                ++(vlSymsp->__Vcoverage[2055]);
            }
            ++(vlSymsp->__Vcoverage[2059]);
        }
        if (vlSelfRef.rampart_i2c__DOT__ctrl_host_enable) {
            ++(vlSymsp->__Vcoverage[2176]);
        } else {
            vlSelfRef.rampart_i2c__DOT__host_timing_cnt = 0U;
            ++(vlSymsp->__Vcoverage[2175]);
            __Vdly__rampart_i2c__DOT__host_state = 0U;
            __Vdly__rampart_i2c__DOT__host_scl_drive_low = 0U;
            __Vdly__rampart_i2c__DOT__host_sda_drive_low = 0U;
        }
        if (((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable) 
             & (~ (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty)))) {
            ++(vlSymsp->__Vcoverage[2056]);
        }
        if (vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty) {
            ++(vlSymsp->__Vcoverage[2057]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable)))) {
            ++(vlSymsp->__Vcoverage[2058]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable)))) {
            ++(vlSymsp->__Vcoverage[2177]);
        }
        if (vlSelfRef.rampart_i2c__DOT__ctrl_host_enable) {
            ++(vlSymsp->__Vcoverage[2178]);
        }
        ++(vlSymsp->__Vcoverage[2180]);
    } else {
        vlSelfRef.rampart_i2c__DOT__host_timing_cnt = 0U;
        __Vdly__rampart_i2c__DOT__host_bit_idx = 0U;
        vlSelfRef.rampart_i2c__DOT__host_read_byte_cnt = 0U;
        vlSelfRef.rampart_i2c__DOT__host_read_shift = 0U;
        ++(vlSymsp->__Vcoverage[2179]);
        __Vdly__rampart_i2c__DOT__host_state = 0U;
        __Vdly__rampart_i2c__DOT__host_shift_reg = 0U;
        vlSelfRef.rampart_i2c__DOT__host_ack_received = 0U;
        vlSelfRef.rampart_i2c__DOT__host_read_rcont = 0U;
        vlSelfRef.rampart_i2c__DOT__host_read_stop = 0U;
        vlSelfRef.rampart_i2c__DOT__host_arb_lost = 0U;
        __Vdly__rampart_i2c__DOT__host_scl_drive_low = 0U;
        __Vdly__rampart_i2c__DOT__host_sda_drive_low = 0U;
        vlSelfRef.rampart_i2c__DOT__fmt_pop_req = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[2181]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[2182]);
    }
    ++(vlSymsp->__Vcoverage[2183]);
    vlSelfRef.rampart_i2c__DOT__acq_rptr = __Vdly__rampart_i2c__DOT__acq_rptr;
    if (__VdlySet__rampart_i2c__DOT__tx_fifo_mem__v0) {
        vlSelfRef.rampart_i2c__DOT__tx_fifo_mem[__VdlyDim0__rampart_i2c__DOT__tx_fifo_mem__v0] 
            = __VdlyVal__rampart_i2c__DOT__tx_fifo_mem__v0;
    }
    vlSelfRef.rampart_i2c__DOT__tx_wptr = __Vdly__rampart_i2c__DOT__tx_wptr;
    vlSelfRef.rampart_i2c__DOT__fmt_rptr = __Vdly__rampart_i2c__DOT__fmt_rptr;
    vlSelfRef.rampart_i2c__DOT__rx_rptr = __Vdly__rampart_i2c__DOT__rx_rptr;
    vlSelfRef.rampart_i2c__DOT__fifo_ctrl_rx_rst = __Vdly__rampart_i2c__DOT__fifo_ctrl_rx_rst;
    if (__VdlySet__rampart_i2c__DOT__rx_fifo_mem__v0) {
        vlSelfRef.rampart_i2c__DOT__rx_fifo_mem[__VdlyDim0__rampart_i2c__DOT__rx_fifo_mem__v0] 
            = __VdlyVal__rampart_i2c__DOT__rx_fifo_mem__v0;
    }
    vlSelfRef.rampart_i2c__DOT__rx_wptr = __Vdly__rampart_i2c__DOT__rx_wptr;
    vlSelfRef.rampart_i2c__DOT__fifo_ctrl_fmt_rst = __Vdly__rampart_i2c__DOT__fifo_ctrl_fmt_rst;
    if (__VdlySet__rampart_i2c__DOT__fmt_fifo_mem__v0) {
        vlSelfRef.rampart_i2c__DOT__fmt_fifo_mem[__VdlyDim0__rampart_i2c__DOT__fmt_fifo_mem__v0] 
            = __VdlyVal__rampart_i2c__DOT__fmt_fifo_mem__v0;
    }
    vlSelfRef.rampart_i2c__DOT__fmt_wptr = __Vdly__rampart_i2c__DOT__fmt_wptr;
    vlSelfRef.rampart_i2c__DOT__fifo_ctrl_tx_rst = __Vdly__rampart_i2c__DOT__fifo_ctrl_tx_rst;
    vlSelfRef.rampart_i2c__DOT__tx_rptr = __Vdly__rampart_i2c__DOT__tx_rptr;
    vlSelfRef.rampart_i2c__DOT__fifo_ctrl_acq_rst = __Vdly__rampart_i2c__DOT__fifo_ctrl_acq_rst;
    if (__VdlySet__rampart_i2c__DOT__acq_fifo_mem__v0) {
        vlSelfRef.rampart_i2c__DOT__acq_fifo_mem[__VdlyDim0__rampart_i2c__DOT__acq_fifo_mem__v0] 
            = __VdlyVal__rampart_i2c__DOT__acq_fifo_mem__v0;
    }
    vlSelfRef.rampart_i2c__DOT__acq_wptr = __Vdly__rampart_i2c__DOT__acq_wptr;
    vlSelfRef.rampart_i2c__DOT__tl_rsp_pending = __Vdly__rampart_i2c__DOT__tl_rsp_pending;
    vlSelfRef.rampart_i2c__DOT__intr_state = __Vdly__rampart_i2c__DOT__intr_state;
    vlSelfRef.rampart_i2c__DOT__host_timeout_cnt = __Vdly__rampart_i2c__DOT__host_timeout_cnt;
    vlSelfRef.rampart_i2c__DOT__scl_in_q = __Vdly__rampart_i2c__DOT__scl_in_q;
    vlSelfRef.rampart_i2c__DOT__host_bit_idx = __Vdly__rampart_i2c__DOT__host_bit_idx;
    vlSelfRef.rampart_i2c__DOT__host_shift_reg = __Vdly__rampart_i2c__DOT__host_shift_reg;
    vlSelfRef.rampart_i2c__DOT__host_sda_drive_low 
        = __Vdly__rampart_i2c__DOT__host_sda_drive_low;
    vlSelfRef.rampart_i2c__DOT__host_scl_drive_low 
        = __Vdly__rampart_i2c__DOT__host_scl_drive_low;
    vlSelfRef.rampart_i2c__DOT__host_state = __Vdly__rampart_i2c__DOT__host_state;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_rptr))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 1146, vlSelfRef.rampart_i2c__DOT__acq_rptr, vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_rptr);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_rptr 
            = vlSelfRef.rampart_i2c__DOT__acq_rptr;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_wptr))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 1050, vlSelfRef.rampart_i2c__DOT__tx_wptr, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_wptr);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_wptr 
            = vlSelfRef.rampart_i2c__DOT__tx_wptr;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_rptr))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 880, vlSelfRef.rampart_i2c__DOT__fmt_rptr, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_rptr);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_rptr 
            = vlSelfRef.rampart_i2c__DOT__fmt_rptr;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_rptr))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 982, vlSelfRef.rampart_i2c__DOT__rx_rptr, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_rptr);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_rptr 
            = vlSelfRef.rampart_i2c__DOT__rx_rptr;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fifo_ctrl_rx_rst) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_rx_rst))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1224, vlSelfRef.rampart_i2c__DOT__fifo_ctrl_rx_rst, vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_rx_rst);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_rx_rst 
            = vlSelfRef.rampart_i2c__DOT__fifo_ctrl_rx_rst;
    }
    vlSelfRef.rampart_i2c__DOT__rx_fifo_rdata = vlSelfRef.rampart_i2c__DOT__rx_fifo_mem
        [(0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr))];
    if ((((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr) 
                 >> 6U)) != (1U & ((IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr) 
                                   >> 6U))) & ((0x0000003fU 
                                                & (IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr)) 
                                               == (0x0000003fU 
                                                   & (IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr))))) {
        ++(vlSymsp->__Vcoverage[1894]);
    }
    if (((0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr)) 
         != (0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr)))) {
        ++(vlSymsp->__Vcoverage[1895]);
    }
    if (((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr) 
                >> 6U)) == (1U & ((IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr) 
                                  >> 6U)))) {
        ++(vlSymsp->__Vcoverage[1896]);
    }
    ++(vlSymsp->__Vcoverage[1897]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_wptr))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 968, vlSelfRef.rampart_i2c__DOT__rx_wptr, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_wptr);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_wptr 
            = vlSelfRef.rampart_i2c__DOT__rx_wptr;
    }
    vlSelfRef.rampart_i2c__DOT__rx_fifo_empty = ((IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr) 
                                                 == (IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr));
    vlSelfRef.rampart_i2c__DOT__rx_fifo_level = (0x0000007fU 
                                                 & ((IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr) 
                                                    - (IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr)));
    vlSelfRef.rampart_i2c__DOT__rx_fifo_full = (((1U 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr) 
                                                     >> 6U)) 
                                                 != 
                                                 (1U 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr) 
                                                     >> 6U))) 
                                                & ((0x0000003fU 
                                                    & (IData)(vlSelfRef.rampart_i2c__DOT__rx_wptr)) 
                                                   == 
                                                   (0x0000003fU 
                                                    & (IData)(vlSelfRef.rampart_i2c__DOT__rx_rptr))));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fifo_ctrl_fmt_rst) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_fmt_rst))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1222, vlSelfRef.rampart_i2c__DOT__fifo_ctrl_fmt_rst, vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_fmt_rst);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_fmt_rst 
            = vlSelfRef.rampart_i2c__DOT__fifo_ctrl_fmt_rst;
    }
    vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata = vlSelfRef.rampart_i2c__DOT__fmt_fifo_mem
        [(0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr))];
    if ((((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr) 
                 >> 6U)) != (1U & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr) 
                                   >> 6U))) & ((0x0000003fU 
                                                & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr)) 
                                               == (0x0000003fU 
                                                   & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr))))) {
        ++(vlSymsp->__Vcoverage[1869]);
    }
    if (((0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr)) 
         != (0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr)))) {
        ++(vlSymsp->__Vcoverage[1870]);
    }
    if (((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr) 
                >> 6U)) == (1U & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr) 
                                  >> 6U)))) {
        ++(vlSymsp->__Vcoverage[1871]);
    }
    ++(vlSymsp->__Vcoverage[1872]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_wptr))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 866, vlSelfRef.rampart_i2c__DOT__fmt_wptr, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_wptr);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_wptr 
            = vlSelfRef.rampart_i2c__DOT__fmt_wptr;
    }
    vlSelfRef.rampart_i2c__DOT__fmt_fifo_full = (((1U 
                                                   & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr) 
                                                      >> 6U)) 
                                                  != 
                                                  (1U 
                                                   & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr) 
                                                      >> 6U))) 
                                                 & ((0x0000003fU 
                                                     & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr)) 
                                                    == 
                                                    (0x0000003fU 
                                                     & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr))));
    vlSelfRef.rampart_i2c__DOT__fmt_fifo_level = (0x0000007fU 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr) 
                                                     - (IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr)));
    vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty = ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_rptr) 
                                                  == (IData)(vlSelfRef.rampart_i2c__DOT__fmt_wptr));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fifo_ctrl_tx_rst) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_tx_rst))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1226, vlSelfRef.rampart_i2c__DOT__fifo_ctrl_tx_rst, vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_tx_rst);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_tx_rst 
            = vlSelfRef.rampart_i2c__DOT__fifo_ctrl_tx_rst;
    }
    if ((((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr) 
                 >> 6U)) != (1U & ((IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr) 
                                   >> 6U))) & ((0x0000003fU 
                                                & (IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr)) 
                                               == (0x0000003fU 
                                                   & (IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr))))) {
        ++(vlSymsp->__Vcoverage[1919]);
    }
    if (((0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr)) 
         != (0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr)))) {
        ++(vlSymsp->__Vcoverage[1920]);
    }
    if (((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr) 
                >> 6U)) == (1U & ((IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr) 
                                  >> 6U)))) {
        ++(vlSymsp->__Vcoverage[1921]);
    }
    ++(vlSymsp->__Vcoverage[1922]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_rptr))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 1064, vlSelfRef.rampart_i2c__DOT__tx_rptr, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_rptr);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_rptr 
            = vlSelfRef.rampart_i2c__DOT__tx_rptr;
    }
    vlSelfRef.rampart_i2c__DOT__tx_fifo_full = (((1U 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr) 
                                                     >> 6U)) 
                                                 != 
                                                 (1U 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr) 
                                                     >> 6U))) 
                                                & ((0x0000003fU 
                                                    & (IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr)) 
                                                   == 
                                                   (0x0000003fU 
                                                    & (IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr))));
    vlSelfRef.rampart_i2c__DOT__tx_fifo_level = (0x0000007fU 
                                                 & ((IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr) 
                                                    - (IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr)));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fifo_ctrl_acq_rst) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_acq_rst))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1228, vlSelfRef.rampart_i2c__DOT__fifo_ctrl_acq_rst, vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_acq_rst);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fifo_ctrl_acq_rst 
            = vlSelfRef.rampart_i2c__DOT__fifo_ctrl_acq_rst;
    }
    vlSelfRef.rampart_i2c__DOT__acq_fifo_rdata = vlSelfRef.rampart_i2c__DOT__acq_fifo_mem
        [(0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr))];
    if ((((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr) 
                 >> 6U)) != (1U & ((IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr) 
                                   >> 6U))) & ((0x0000003fU 
                                                & (IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr)) 
                                               == (0x0000003fU 
                                                   & (IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr))))) {
        ++(vlSymsp->__Vcoverage[1944]);
    }
    if (((0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr)) 
         != (0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr)))) {
        ++(vlSymsp->__Vcoverage[1945]);
    }
    if (((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr) 
                >> 6U)) == (1U & ((IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr) 
                                  >> 6U)))) {
        ++(vlSymsp->__Vcoverage[1946]);
    }
    ++(vlSymsp->__Vcoverage[1947]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_wptr))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 1132, vlSelfRef.rampart_i2c__DOT__acq_wptr, vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_wptr);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_wptr 
            = vlSelfRef.rampart_i2c__DOT__acq_wptr;
    }
    vlSelfRef.rampart_i2c__DOT__acq_fifo_empty = ((IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr) 
                                                  == (IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr));
    vlSelfRef.rampart_i2c__DOT__acq_fifo_level = (0x0000007fU 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr) 
                                                     - (IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr)));
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        vlSelfRef.rampart_i2c__DOT__acq_fifo_push = 0U;
        vlSelfRef.rampart_i2c__DOT__tx_fifo_pop = 0U;
        if (((IData)(vlSelfRef.rampart_i2c__DOT__stop_det) 
             & (0U != (IData)(vlSelfRef.rampart_i2c__DOT__tgt_state)))) {
            if (vlSelfRef.rampart_i2c__DOT__tgt_addr_match) {
                ++(vlSymsp->__Vcoverage[2217]);
                vlSelfRef.rampart_i2c__DOT__acq_fifo_push = 1U;
                vlSelfRef.rampart_i2c__DOT__acq_fifo_wdata = 0x0200U;
            } else {
                ++(vlSymsp->__Vcoverage[2218]);
            }
            __Vdly__rampart_i2c__DOT__tgt_state = 0U;
            vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low = 0U;
            vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low = 0U;
            vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed = 0U;
            ++(vlSymsp->__Vcoverage[2302]);
        } else {
            if ((8U & (IData)(vlSelfRef.rampart_i2c__DOT__tgt_state))) {
                if ((4U & (IData)(vlSelfRef.rampart_i2c__DOT__tgt_state))) {
                    ++(vlSymsp->__Vcoverage[2301]);
                    __Vdly__rampart_i2c__DOT__tgt_state = 0U;
                } else if ((2U & (IData)(vlSelfRef.rampart_i2c__DOT__tgt_state))) {
                    ++(vlSymsp->__Vcoverage[2301]);
                    __Vdly__rampart_i2c__DOT__tgt_state = 0U;
                } else if ((1U & (IData)(vlSelfRef.rampart_i2c__DOT__tgt_state))) {
                    ++(vlSymsp->__Vcoverage[2300]);
                    __Vdly__rampart_i2c__DOT__tgt_state = 0U;
                    vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low = 0U;
                    vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low = 0U;
                    vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed = 0U;
                } else {
                    vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low = 1U;
                    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_rw_bit) 
                         & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_empty)))) {
                        if ((1U & (~ ((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata) 
                                      >> 7U)))) {
                            ++(vlSymsp->__Vcoverage[2288]);
                        }
                        vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low = 0U;
                        vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed = 0U;
                        __Vdly__rampart_i2c__DOT__tgt_tx_shift 
                            = vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata;
                        vlSelfRef.rampart_i2c__DOT__tx_fifo_pop = 1U;
                        __Vdly__rampart_i2c__DOT__tgt_state = 6U;
                        __Vdly__rampart_i2c__DOT__tgt_bit_idx = 0U;
                        vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low 
                            = (1U & (~ ((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata) 
                                        >> 7U)));
                        if ((0x00000080U & (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata))) {
                            ++(vlSymsp->__Vcoverage[2289]);
                        }
                        ++(vlSymsp->__Vcoverage[2295]);
                    } else {
                        if ((1U & ((~ (IData)(vlSelfRef.rampart_i2c__DOT__tgt_rw_bit)) 
                                   & (~ (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_full))))) {
                            ++(vlSymsp->__Vcoverage[2290]);
                            vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low = 0U;
                            vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed = 0U;
                            vlSelfRef.rampart_i2c__DOT__acq_fifo_push = 1U;
                            vlSelfRef.rampart_i2c__DOT__acq_fifo_wdata 
                                = vlSelfRef.rampart_i2c__DOT__tgt_rx_shift;
                            __Vdly__rampart_i2c__DOT__tgt_state = 5U;
                            vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low = 1U;
                        } else {
                            ++(vlSymsp->__Vcoverage[2291]);
                        }
                        if ((1U & ((~ (IData)(vlSelfRef.rampart_i2c__DOT__tgt_rw_bit)) 
                                   & (~ (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_full))))) {
                            ++(vlSymsp->__Vcoverage[2292]);
                        }
                        if (vlSelfRef.rampart_i2c__DOT__acq_fifo_full) {
                            ++(vlSymsp->__Vcoverage[2293]);
                        }
                        if (vlSelfRef.rampart_i2c__DOT__tgt_rw_bit) {
                            ++(vlSymsp->__Vcoverage[2294]);
                        }
                    }
                    ++(vlSymsp->__Vcoverage[2299]);
                }
            } else if ((4U & (IData)(vlSelfRef.rampart_i2c__DOT__tgt_state))) {
                if ((2U & (IData)(vlSelfRef.rampart_i2c__DOT__tgt_state))) {
                    if ((1U & (IData)(vlSelfRef.rampart_i2c__DOT__tgt_state))) {
                        if (vlSelfRef.rampart_i2c__DOT__start_det) {
                            if (vlSelfRef.rampart_i2c__DOT__tgt_addr_match) {
                                ++(vlSymsp->__Vcoverage[2275]);
                                vlSelfRef.rampart_i2c__DOT__acq_fifo_push = 1U;
                                vlSelfRef.rampart_i2c__DOT__acq_fifo_wdata = 0x0300U;
                            } else {
                                ++(vlSymsp->__Vcoverage[2276]);
                            }
                            __Vdly__rampart_i2c__DOT__tgt_bit_idx = 0U;
                            __Vdly__rampart_i2c__DOT__tgt_state = 2U;
                            ++(vlSymsp->__Vcoverage[2286]);
                        } else if (vlSelfRef.rampart_i2c__DOT__scl_rising) {
                            if (vlSelfRef.rampart_i2c__DOT__sda_in_q) {
                                ++(vlSymsp->__Vcoverage[2277]);
                                __Vdly__rampart_i2c__DOT__tgt_state = 0U;
                            } else {
                                ++(vlSymsp->__Vcoverage[2278]);
                            }
                            ++(vlSymsp->__Vcoverage[2285]);
                        } else if (vlSelfRef.rampart_i2c__DOT__scl_falling) {
                            if (vlSelfRef.rampart_i2c__DOT__tx_fifo_empty) {
                                ++(vlSymsp->__Vcoverage[2281]);
                                __Vdly__rampart_i2c__DOT__tgt_state = 8U;
                                vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low = 1U;
                                vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed = 1U;
                            } else {
                                if ((1U & (~ ((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata) 
                                              >> 7U)))) {
                                    ++(vlSymsp->__Vcoverage[2279]);
                                }
                                __Vdly__rampart_i2c__DOT__tgt_tx_shift 
                                    = vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata;
                                vlSelfRef.rampart_i2c__DOT__tx_fifo_pop = 1U;
                                __Vdly__rampart_i2c__DOT__tgt_state = 6U;
                                __Vdly__rampart_i2c__DOT__tgt_bit_idx = 0U;
                                vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low 
                                    = (1U & (~ ((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata) 
                                                >> 7U)));
                                if ((0x00000080U & (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata))) {
                                    ++(vlSymsp->__Vcoverage[2280]);
                                }
                                ++(vlSymsp->__Vcoverage[2282]);
                            }
                            ++(vlSymsp->__Vcoverage[2283]);
                        } else {
                            ++(vlSymsp->__Vcoverage[2284]);
                        }
                        ++(vlSymsp->__Vcoverage[2287]);
                    } else {
                        if (vlSelfRef.rampart_i2c__DOT__start_det) {
                            vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low = 0U;
                            if (vlSelfRef.rampart_i2c__DOT__tgt_addr_match) {
                                ++(vlSymsp->__Vcoverage[2265]);
                                vlSelfRef.rampart_i2c__DOT__acq_fifo_push = 1U;
                                vlSelfRef.rampart_i2c__DOT__acq_fifo_wdata = 0x0300U;
                            } else {
                                ++(vlSymsp->__Vcoverage[2266]);
                            }
                            __Vdly__rampart_i2c__DOT__tgt_bit_idx = 0U;
                            __Vdly__rampart_i2c__DOT__tgt_state = 2U;
                            ++(vlSymsp->__Vcoverage[2273]);
                        } else if (vlSelfRef.rampart_i2c__DOT__scl_falling) {
                            if ((7U > (IData)(vlSelfRef.rampart_i2c__DOT__tgt_bit_idx))) {
                                __Vdly__rampart_i2c__DOT__tgt_bit_idx 
                                    = (0x0000000fU 
                                       & ((IData)(1U) 
                                          + (IData)(vlSelfRef.rampart_i2c__DOT__tgt_bit_idx)));
                                vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low 
                                    = (1U & (~ ((IData)(vlSelfRef.rampart_i2c__DOT__tgt_tx_shift) 
                                                >> 
                                                (7U 
                                                 & ((IData)(6U) 
                                                    - (IData)(vlSelfRef.rampart_i2c__DOT__tgt_bit_idx))))));
                                if ((1U & (~ ((IData)(vlSelfRef.rampart_i2c__DOT__tgt_tx_shift) 
                                              >> (7U 
                                                  & ((IData)(6U) 
                                                     - (IData)(vlSelfRef.rampart_i2c__DOT__tgt_bit_idx))))))) {
                                    ++(vlSymsp->__Vcoverage[2267]);
                                }
                                if ((1U & ((IData)(vlSelfRef.rampart_i2c__DOT__tgt_tx_shift) 
                                           >> (7U & 
                                               ((IData)(6U) 
                                                - (IData)(vlSelfRef.rampart_i2c__DOT__tgt_bit_idx)))))) {
                                    ++(vlSymsp->__Vcoverage[2268]);
                                }
                                ++(vlSymsp->__Vcoverage[2269]);
                            } else {
                                ++(vlSymsp->__Vcoverage[2270]);
                                vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low = 0U;
                                __Vdly__rampart_i2c__DOT__tgt_state = 7U;
                                __Vdly__rampart_i2c__DOT__tgt_bit_idx = 0U;
                            }
                            ++(vlSymsp->__Vcoverage[2271]);
                        } else {
                            ++(vlSymsp->__Vcoverage[2272]);
                        }
                        ++(vlSymsp->__Vcoverage[2274]);
                    }
                } else if ((1U & (IData)(vlSelfRef.rampart_i2c__DOT__tgt_state))) {
                    if (vlSelfRef.rampart_i2c__DOT__start_det) {
                        vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low = 0U;
                        if (vlSelfRef.rampart_i2c__DOT__tgt_addr_match) {
                            ++(vlSymsp->__Vcoverage[2259]);
                            vlSelfRef.rampart_i2c__DOT__acq_fifo_push = 1U;
                            vlSelfRef.rampart_i2c__DOT__acq_fifo_wdata = 0x0300U;
                        } else {
                            ++(vlSymsp->__Vcoverage[2260]);
                        }
                        __Vdly__rampart_i2c__DOT__tgt_bit_idx = 0U;
                        __Vdly__rampart_i2c__DOT__tgt_state = 2U;
                        ++(vlSymsp->__Vcoverage[2263]);
                    } else if (vlSelfRef.rampart_i2c__DOT__scl_falling) {
                        ++(vlSymsp->__Vcoverage[2261]);
                        vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low = 0U;
                        __Vdly__rampart_i2c__DOT__tgt_state = 4U;
                        __Vdly__rampart_i2c__DOT__tgt_bit_idx = 0U;
                    } else {
                        ++(vlSymsp->__Vcoverage[2262]);
                    }
                    ++(vlSymsp->__Vcoverage[2264]);
                } else {
                    if (vlSelfRef.rampart_i2c__DOT__start_det) {
                        if (vlSelfRef.rampart_i2c__DOT__tgt_addr_match) {
                            ++(vlSymsp->__Vcoverage[2247]);
                            vlSelfRef.rampart_i2c__DOT__acq_fifo_push = 1U;
                            vlSelfRef.rampart_i2c__DOT__acq_fifo_wdata = 0x0300U;
                        } else {
                            ++(vlSymsp->__Vcoverage[2248]);
                        }
                        __Vdly__rampart_i2c__DOT__tgt_bit_idx = 0U;
                        __Vdly__rampart_i2c__DOT__tgt_state = 2U;
                        ++(vlSymsp->__Vcoverage[2257]);
                    } else if (vlSelfRef.rampart_i2c__DOT__scl_rising) {
                        __Vdly__rampart_i2c__DOT__tgt_bit_idx 
                            = (0x0000000fU & ((IData)(1U) 
                                              + (IData)(vlSelfRef.rampart_i2c__DOT__tgt_bit_idx)));
                        __Vdly__rampart_i2c__DOT__tgt_rx_shift 
                            = ((0x000000feU & ((IData)(vlSelfRef.rampart_i2c__DOT__tgt_rx_shift) 
                                               << 1U)) 
                               | (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q));
                        ++(vlSymsp->__Vcoverage[2256]);
                    } else {
                        if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_falling) 
                             & (8U == (IData)(vlSelfRef.rampart_i2c__DOT__tgt_bit_idx)))) {
                            __Vdly__rampart_i2c__DOT__tgt_bit_idx = 0U;
                            if (vlSelfRef.rampart_i2c__DOT__acq_fifo_full) {
                                ++(vlSymsp->__Vcoverage[2249]);
                                __Vdly__rampart_i2c__DOT__tgt_state = 8U;
                                vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low = 1U;
                                vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed = 1U;
                            } else {
                                ++(vlSymsp->__Vcoverage[2250]);
                                vlSelfRef.rampart_i2c__DOT__acq_fifo_push = 1U;
                                vlSelfRef.rampart_i2c__DOT__acq_fifo_wdata 
                                    = vlSelfRef.rampart_i2c__DOT__tgt_rx_shift;
                                __Vdly__rampart_i2c__DOT__tgt_state = 5U;
                                vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low = 1U;
                            }
                            ++(vlSymsp->__Vcoverage[2251]);
                        } else {
                            ++(vlSymsp->__Vcoverage[2252]);
                        }
                        if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_falling) 
                             & (8U == (IData)(vlSelfRef.rampart_i2c__DOT__tgt_bit_idx)))) {
                            ++(vlSymsp->__Vcoverage[2253]);
                        }
                        if ((8U != (IData)(vlSelfRef.rampart_i2c__DOT__tgt_bit_idx))) {
                            ++(vlSymsp->__Vcoverage[2254]);
                        }
                        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_falling)))) {
                            ++(vlSymsp->__Vcoverage[2255]);
                        }
                    }
                    ++(vlSymsp->__Vcoverage[2258]);
                }
            } else if ((2U & (IData)(vlSelfRef.rampart_i2c__DOT__tgt_state))) {
                if ((1U & (IData)(vlSelfRef.rampart_i2c__DOT__tgt_state))) {
                    if (vlSelfRef.rampart_i2c__DOT__scl_falling) {
                        vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low = 0U;
                        if (vlSelfRef.rampart_i2c__DOT__tgt_rw_bit) {
                            if (vlSelfRef.rampart_i2c__DOT__tx_fifo_empty) {
                                ++(vlSymsp->__Vcoverage[2240]);
                                __Vdly__rampart_i2c__DOT__tgt_state = 8U;
                                vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low = 1U;
                                vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed = 1U;
                            } else {
                                if ((1U & (~ ((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata) 
                                              >> 7U)))) {
                                    ++(vlSymsp->__Vcoverage[2238]);
                                }
                                __Vdly__rampart_i2c__DOT__tgt_tx_shift 
                                    = vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata;
                                vlSelfRef.rampart_i2c__DOT__tx_fifo_pop = 1U;
                                __Vdly__rampart_i2c__DOT__tgt_state = 6U;
                                __Vdly__rampart_i2c__DOT__tgt_bit_idx = 0U;
                                vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low 
                                    = (1U & (~ ((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata) 
                                                >> 7U)));
                                if ((0x00000080U & (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata))) {
                                    ++(vlSymsp->__Vcoverage[2239]);
                                }
                                ++(vlSymsp->__Vcoverage[2241]);
                            }
                            ++(vlSymsp->__Vcoverage[2242]);
                        } else {
                            ++(vlSymsp->__Vcoverage[2243]);
                            __Vdly__rampart_i2c__DOT__tgt_state = 4U;
                            __Vdly__rampart_i2c__DOT__tgt_bit_idx = 0U;
                        }
                        ++(vlSymsp->__Vcoverage[2244]);
                    } else {
                        ++(vlSymsp->__Vcoverage[2245]);
                    }
                    ++(vlSymsp->__Vcoverage[2246]);
                } else {
                    if (vlSelfRef.rampart_i2c__DOT__start_det) {
                        ++(vlSymsp->__Vcoverage[2236]);
                        __Vdly__rampart_i2c__DOT__tgt_bit_idx = 0U;
                        __Vdly__rampart_i2c__DOT__tgt_state = 2U;
                    } else if (vlSelfRef.rampart_i2c__DOT__scl_rising) {
                        if ((7U > (IData)(vlSelfRef.rampart_i2c__DOT__tgt_bit_idx))) {
                            __Vdly__rampart_i2c__DOT__tgt_bit_idx 
                                = (0x0000000fU & ((IData)(1U) 
                                                  + (IData)(vlSelfRef.rampart_i2c__DOT__tgt_bit_idx)));
                            __Vdly__rampart_i2c__DOT__tgt_addr_shift 
                                = ((0x0000007eU & ((IData)(vlSelfRef.rampart_i2c__DOT__tgt_addr_shift) 
                                                   << 1U)) 
                                   | (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q));
                            ++(vlSymsp->__Vcoverage[2225]);
                        } else {
                            ++(vlSymsp->__Vcoverage[2226]);
                            __Vdly__rampart_i2c__DOT__tgt_rw_bit 
                                = vlSelfRef.rampart_i2c__DOT__sda_in_q;
                            __Vdly__rampart_i2c__DOT__tgt_bit_idx = 0U;
                            __Vdly__rampart_i2c__DOT__tgt_addr_match 
                                = (0U == (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_addr_shift) 
                                           ^ (IData)(vlSelfRef.rampart_i2c__DOT__target_address)) 
                                          & (IData)(vlSelfRef.rampart_i2c__DOT__target_mask)));
                        }
                        ++(vlSymsp->__Vcoverage[2235]);
                    } else {
                        if ((((IData)(vlSelfRef.rampart_i2c__DOT__scl_falling) 
                              & (0U == (IData)(vlSelfRef.rampart_i2c__DOT__tgt_bit_idx))) 
                             & (0U != (IData)(vlSelfRef.rampart_i2c__DOT__tgt_addr_shift)))) {
                            if (vlSelfRef.rampart_i2c__DOT__tgt_addr_match) {
                                ++(vlSymsp->__Vcoverage[2227]);
                                __Vdly__rampart_i2c__DOT__tgt_state = 3U;
                                vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low = 1U;
                                vlSelfRef.rampart_i2c__DOT__acq_fifo_push = 1U;
                                vlSelfRef.rampart_i2c__DOT__acq_fifo_wdata 
                                    = (0x00000100U 
                                       | (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_addr_shift) 
                                           << 1U) | (IData)(vlSelfRef.rampart_i2c__DOT__tgt_rw_bit)));
                            } else {
                                ++(vlSymsp->__Vcoverage[2228]);
                                __Vdly__rampart_i2c__DOT__tgt_state = 0U;
                                vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low = 0U;
                            }
                            ++(vlSymsp->__Vcoverage[2229]);
                        } else {
                            ++(vlSymsp->__Vcoverage[2230]);
                        }
                        if ((((IData)(vlSelfRef.rampart_i2c__DOT__scl_falling) 
                              & (0U == (IData)(vlSelfRef.rampart_i2c__DOT__tgt_bit_idx))) 
                             & (0U != (IData)(vlSelfRef.rampart_i2c__DOT__tgt_addr_shift)))) {
                            ++(vlSymsp->__Vcoverage[2231]);
                        }
                        if ((0U == (IData)(vlSelfRef.rampart_i2c__DOT__tgt_addr_shift))) {
                            ++(vlSymsp->__Vcoverage[2232]);
                        }
                        if ((0U != (IData)(vlSelfRef.rampart_i2c__DOT__tgt_bit_idx))) {
                            ++(vlSymsp->__Vcoverage[2233]);
                        }
                        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_falling)))) {
                            ++(vlSymsp->__Vcoverage[2234]);
                        }
                    }
                    ++(vlSymsp->__Vcoverage[2237]);
                }
            } else if ((1U & (IData)(vlSelfRef.rampart_i2c__DOT__tgt_state))) {
                ++(vlSymsp->__Vcoverage[2301]);
                __Vdly__rampart_i2c__DOT__tgt_state = 0U;
            } else {
                vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low = 0U;
                vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low = 0U;
                __Vdly__rampart_i2c__DOT__tgt_bit_idx = 0U;
                __Vdly__rampart_i2c__DOT__tgt_addr_match = 0U;
                vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed = 0U;
                if (((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable) 
                     & (IData)(vlSelfRef.rampart_i2c__DOT__start_det))) {
                    ++(vlSymsp->__Vcoverage[2219]);
                    __Vdly__rampart_i2c__DOT__tgt_state = 2U;
                    __Vdly__rampart_i2c__DOT__tgt_bit_idx = 0U;
                } else {
                    ++(vlSymsp->__Vcoverage[2220]);
                }
                ++(vlSymsp->__Vcoverage[2224]);
            }
            if (((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable) 
                 & (IData)(vlSelfRef.rampart_i2c__DOT__start_det))) {
                ++(vlSymsp->__Vcoverage[2221]);
            }
            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__start_det)))) {
                ++(vlSymsp->__Vcoverage[2222]);
            }
            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable)))) {
                ++(vlSymsp->__Vcoverage[2223]);
            }
            if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_rw_bit) 
                 & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_empty)))) {
                ++(vlSymsp->__Vcoverage[2296]);
            }
            if (vlSelfRef.rampart_i2c__DOT__tx_fifo_empty) {
                ++(vlSymsp->__Vcoverage[2297]);
            }
            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tgt_rw_bit)))) {
                ++(vlSymsp->__Vcoverage[2298]);
            }
            ++(vlSymsp->__Vcoverage[2303]);
        }
        if (vlSelfRef.rampart_i2c__DOT__ctrl_target_enable) {
            ++(vlSymsp->__Vcoverage[2308]);
        } else {
            ++(vlSymsp->__Vcoverage[2307]);
            __Vdly__rampart_i2c__DOT__tgt_state = 0U;
            vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low = 0U;
            vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low = 0U;
            vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed = 0U;
        }
        if (((IData)(vlSelfRef.rampart_i2c__DOT__stop_det) 
             & (0U != (IData)(vlSelfRef.rampart_i2c__DOT__tgt_state)))) {
            ++(vlSymsp->__Vcoverage[2304]);
        }
        if ((0U == (IData)(vlSelfRef.rampart_i2c__DOT__tgt_state))) {
            ++(vlSymsp->__Vcoverage[2305]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__stop_det)))) {
            ++(vlSymsp->__Vcoverage[2306]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable)))) {
            ++(vlSymsp->__Vcoverage[2309]);
        }
        if (vlSelfRef.rampart_i2c__DOT__ctrl_target_enable) {
            ++(vlSymsp->__Vcoverage[2310]);
        }
        ++(vlSymsp->__Vcoverage[2312]);
    } else {
        __Vdly__rampart_i2c__DOT__tgt_addr_shift = 0U;
        __Vdly__rampart_i2c__DOT__tgt_rx_shift = 0U;
        ++(vlSymsp->__Vcoverage[2311]);
        __Vdly__rampart_i2c__DOT__tgt_state = 0U;
        __Vdly__rampart_i2c__DOT__tgt_rw_bit = 0U;
        __Vdly__rampart_i2c__DOT__tgt_bit_idx = 0U;
        __Vdly__rampart_i2c__DOT__tgt_tx_shift = 0U;
        __Vdly__rampart_i2c__DOT__tgt_addr_match = 0U;
        vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed = 0U;
        vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low = 0U;
        vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low = 0U;
        vlSelfRef.rampart_i2c__DOT__acq_fifo_push = 0U;
        vlSelfRef.rampart_i2c__DOT__acq_fifo_wdata = 0U;
        vlSelfRef.rampart_i2c__DOT__tx_fifo_pop = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[2313]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[2314]);
    }
    ++(vlSymsp->__Vcoverage[2315]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__bus_active) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__bus_active))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1490, vlSelfRef.rampart_i2c__DOT__bus_active, vlSelfRef.rampart_i2c__DOT____Vtogcov__bus_active);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__bus_active 
            = vlSelfRef.rampart_i2c__DOT__bus_active;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_push_data) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_push_data))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 2186, vlSelfRef.rampart_i2c__DOT__rx_push_data, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_push_data);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_push_data 
            = vlSelfRef.rampart_i2c__DOT__rx_push_data;
    }
    vlSelfRef.rampart_i2c__DOT__rx_fifo_wdata = vlSelfRef.rampart_i2c__DOT__rx_push_data;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_push_valid) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_push_valid))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2184, vlSelfRef.rampart_i2c__DOT__rx_push_valid, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_push_valid);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_push_valid 
            = vlSelfRef.rampart_i2c__DOT__rx_push_valid;
    }
    vlSelfRef.rampart_i2c__DOT__rx_fifo_push = vlSelfRef.rampart_i2c__DOT__rx_push_valid;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_d_valid_o) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_valid_o))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 170, vlSelfRef.rampart_i2c__DOT__tl_d_valid_o, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_valid_o);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_valid_o 
            = vlSelfRef.rampart_i2c__DOT__tl_d_valid_o;
    }
    vlSelfRef.tl_d_valid_o = vlSelfRef.rampart_i2c__DOT__tl_d_valid_o;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_d_opcode_o) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_opcode_o))) {
        VL_COV_TOGGLE_CHG_ST_I(3, vlSymsp->__Vcoverage + 174, vlSelfRef.rampart_i2c__DOT__tl_d_opcode_o, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_opcode_o);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_opcode_o 
            = vlSelfRef.rampart_i2c__DOT__tl_d_opcode_o;
    }
    vlSelfRef.tl_d_opcode_o = vlSelfRef.rampart_i2c__DOT__tl_d_opcode_o;
    if ((vlSelfRef.rampart_i2c__DOT__tl_d_data_o ^ vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_data_o)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 180, vlSelfRef.rampart_i2c__DOT__tl_d_data_o, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_data_o);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_data_o 
            = vlSelfRef.rampart_i2c__DOT__tl_d_data_o;
    }
    vlSelfRef.tl_d_data_o = vlSelfRef.rampart_i2c__DOT__tl_d_data_o;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_d_source_o) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_source_o))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 244, vlSelfRef.rampart_i2c__DOT__tl_d_source_o, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_source_o);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_source_o 
            = vlSelfRef.rampart_i2c__DOT__tl_d_source_o;
    }
    vlSelfRef.tl_d_source_o = vlSelfRef.rampart_i2c__DOT__tl_d_source_o;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_d_error_o) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_error_o))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 260, vlSelfRef.rampart_i2c__DOT__tl_d_error_o, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_error_o);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_d_error_o 
            = vlSelfRef.rampart_i2c__DOT__tl_d_error_o;
    }
    vlSelfRef.tl_d_error_o = vlSelfRef.rampart_i2c__DOT__tl_d_error_o;
    if (vlSelfRef.rampart_i2c__DOT__tl_d_ready_i) {
        ++(vlSymsp->__Vcoverage[1723]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_rsp_pending)))) {
        ++(vlSymsp->__Vcoverage[1724]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_rsp_pending) 
         & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_d_ready_i)))) {
        ++(vlSymsp->__Vcoverage[1725]);
    }
    ++(vlSymsp->__Vcoverage[1726]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_rsp_pending) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_rsp_pending))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1714, vlSelfRef.rampart_i2c__DOT__tl_rsp_pending, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_rsp_pending);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_rsp_pending 
            = vlSelfRef.rampart_i2c__DOT__tl_rsp_pending;
    }
    vlSelfRef.rampart_i2c__DOT__tl_a_ready_o = (1U 
                                                & ((~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_rsp_pending)) 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__tl_d_ready_i)));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__intr_state) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_state))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 770, vlSelfRef.rampart_i2c__DOT__intr_state, vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_state);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_state 
            = vlSelfRef.rampart_i2c__DOT__intr_state;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__intr_enable) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_enable))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 802, vlSelfRef.rampart_i2c__DOT__intr_enable, vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_enable);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_enable 
            = vlSelfRef.rampart_i2c__DOT__intr_enable;
    }
    vlSelfRef.rampart_i2c__DOT__intr_o = ((IData)(vlSelfRef.rampart_i2c__DOT__intr_enable) 
                                          & (IData)(vlSelfRef.rampart_i2c__DOT__intr_state));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__ovrd_txovrden) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__ovrd_txovrden))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 722, vlSelfRef.rampart_i2c__DOT__ovrd_txovrden, vlSelfRef.rampart_i2c__DOT____Vtogcov__ovrd_txovrden);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__ovrd_txovrden 
            = vlSelfRef.rampart_i2c__DOT__ovrd_txovrden;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__ovrd_sclval) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__ovrd_sclval))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 724, vlSelfRef.rampart_i2c__DOT__ovrd_sclval, vlSelfRef.rampart_i2c__DOT____Vtogcov__ovrd_sclval);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__ovrd_sclval 
            = vlSelfRef.rampart_i2c__DOT__ovrd_sclval;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__ovrd_sdaval) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__ovrd_sdaval))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 726, vlSelfRef.rampart_i2c__DOT__ovrd_sdaval, vlSelfRef.rampart_i2c__DOT____Vtogcov__ovrd_sdaval);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__ovrd_sdaval 
            = vlSelfRef.rampart_i2c__DOT__ovrd_sdaval;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_in_qq))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1238, vlSelfRef.rampart_i2c__DOT__scl_in_qq, vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_in_qq);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_in_qq 
            = vlSelfRef.rampart_i2c__DOT__scl_in_qq;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_in_qq))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1240, vlSelfRef.rampart_i2c__DOT__sda_in_qq, vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_in_qq);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_in_qq 
            = vlSelfRef.rampart_i2c__DOT__sda_in_qq;
    }
    if ((vlSelfRef.rampart_i2c__DOT__host_timeout_cnt 
         ^ vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_cnt)) {
        VL_COV_TOGGLE_CHG_ST_I(20, vlSymsp->__Vcoverage + 1448, vlSelfRef.rampart_i2c__DOT__host_timeout_cnt, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_cnt);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_cnt 
            = vlSelfRef.rampart_i2c__DOT__host_timeout_cnt;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_timeout_event) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_event))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1488, vlSelfRef.rampart_i2c__DOT__host_timeout_event, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_event);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_event 
            = vlSelfRef.rampart_i2c__DOT__host_timeout_event;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_in_q))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1234, vlSelfRef.rampart_i2c__DOT__scl_in_q, vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_in_q);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_in_q 
            = vlSelfRef.rampart_i2c__DOT__scl_in_q;
    }
    __VdfgRegularize_h6e95ff9d_0_5 = ((IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q) 
                                      & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq));
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        if ((((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid) 
              & (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)) 
             & (0x0000003cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr))) {
            ++(vlSymsp->__Vcoverage[1823]);
            vlSelfRef.rampart_i2c__DOT__host_timeout_val 
                = (0x000fffffU & vlSelfRef.rampart_i2c__DOT__tl_req_wdata);
            vlSelfRef.rampart_i2c__DOT__host_timeout_en 
                = (1U & (vlSelfRef.rampart_i2c__DOT__tl_req_wdata 
                         >> 0x14U));
        } else {
            ++(vlSymsp->__Vcoverage[1824]);
        }
        if ((((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid) 
              & (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)) 
             & (0x0000003cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr))) {
            ++(vlSymsp->__Vcoverage[1825]);
        }
        if ((0x0000003cU != vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
            ++(vlSymsp->__Vcoverage[1826]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)))) {
            ++(vlSymsp->__Vcoverage[1827]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid)))) {
            ++(vlSymsp->__Vcoverage[1828]);
        }
    } else {
        ++(vlSymsp->__Vcoverage[1829]);
        vlSelfRef.rampart_i2c__DOT__host_timeout_val = 0U;
        vlSelfRef.rampart_i2c__DOT__host_timeout_en = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[1830]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[1831]);
    }
    ++(vlSymsp->__Vcoverage[1832]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_bit_idx) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_bit_idx))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 1298, vlSelfRef.rampart_i2c__DOT__host_bit_idx, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_bit_idx);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_bit_idx 
            = vlSelfRef.rampart_i2c__DOT__host_bit_idx;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_shift_reg) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_shift_reg))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1306, vlSelfRef.rampart_i2c__DOT__host_shift_reg, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_shift_reg);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_shift_reg 
            = vlSelfRef.rampart_i2c__DOT__host_shift_reg;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_read_byte_cnt) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_byte_cnt))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1324, vlSelfRef.rampart_i2c__DOT__host_read_byte_cnt, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_byte_cnt);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_byte_cnt 
            = vlSelfRef.rampart_i2c__DOT__host_read_byte_cnt;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_read_shift) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_shift))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1340, vlSelfRef.rampart_i2c__DOT__host_read_shift, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_shift);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_shift 
            = vlSelfRef.rampart_i2c__DOT__host_read_shift;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_ack_received) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_ack_received))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1322, vlSelfRef.rampart_i2c__DOT__host_ack_received, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_ack_received);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_ack_received 
            = vlSelfRef.rampart_i2c__DOT__host_ack_received;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_read_rcont) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_rcont))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1356, vlSelfRef.rampart_i2c__DOT__host_read_rcont, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_rcont);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_rcont 
            = vlSelfRef.rampart_i2c__DOT__host_read_rcont;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_read_stop) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_stop))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1358, vlSelfRef.rampart_i2c__DOT__host_read_stop, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_stop);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_read_stop 
            = vlSelfRef.rampart_i2c__DOT__host_read_stop;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_pop_req) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_pop_req))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2037, vlSelfRef.rampart_i2c__DOT__fmt_pop_req, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_pop_req);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_pop_req 
            = vlSelfRef.rampart_i2c__DOT__fmt_pop_req;
    }
    vlSelfRef.rampart_i2c__DOT__fmt_fifo_pop = vlSelfRef.rampart_i2c__DOT__fmt_pop_req;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_arb_lost) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_arb_lost))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1386, vlSelfRef.rampart_i2c__DOT__host_arb_lost, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_arb_lost);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_arb_lost 
            = vlSelfRef.rampart_i2c__DOT__host_arb_lost;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_timing_cnt) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timing_cnt))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 1266, vlSelfRef.rampart_i2c__DOT__host_timing_cnt, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timing_cnt);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timing_cnt 
            = vlSelfRef.rampart_i2c__DOT__host_timing_cnt;
    }
    vlSelfRef.rampart_i2c__DOT__host_timing_done = 
        (0U == (IData)(vlSelfRef.rampart_i2c__DOT__host_timing_cnt));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_sda_drive_low) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_sda_drive_low))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2045, vlSelfRef.rampart_i2c__DOT__host_sda_drive_low, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_sda_drive_low);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_sda_drive_low 
            = vlSelfRef.rampart_i2c__DOT__host_sda_drive_low;
    }
    vlSelfRef.rampart_i2c__DOT__host_sda_oe = vlSelfRef.rampart_i2c__DOT__host_sda_drive_low;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_scl_drive_low) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_scl_drive_low))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2043, vlSelfRef.rampart_i2c__DOT__host_scl_drive_low, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_scl_drive_low);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_scl_drive_low 
            = vlSelfRef.rampart_i2c__DOT__host_scl_drive_low;
    }
    vlSelfRef.rampart_i2c__DOT__host_scl_oe = vlSelfRef.rampart_i2c__DOT__host_scl_drive_low;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_state) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_state))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 1250, vlSelfRef.rampart_i2c__DOT__host_state, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_state);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_state 
            = vlSelfRef.rampart_i2c__DOT__host_state;
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid) 
             & (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write))) {
            if ((0x0000001cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                ++(vlSymsp->__Vcoverage[1788]);
                vlSelfRef.rampart_i2c__DOT__timing_tlow 
                    = (0x0000ffffU & vlSelfRef.rampart_i2c__DOT__tl_req_wdata);
                vlSelfRef.rampart_i2c__DOT__timing_thigh 
                    = (vlSelfRef.rampart_i2c__DOT__tl_req_wdata 
                       >> 0x10U);
            } else if ((0x00000020U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                ++(vlSymsp->__Vcoverage[1789]);
                vlSelfRef.rampart_i2c__DOT__timing_t_f 
                    = (0x0000ffffU & vlSelfRef.rampart_i2c__DOT__tl_req_wdata);
                vlSelfRef.rampart_i2c__DOT__timing_t_r 
                    = (vlSelfRef.rampart_i2c__DOT__tl_req_wdata 
                       >> 0x10U);
            } else if ((0x00000024U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                ++(vlSymsp->__Vcoverage[1790]);
                vlSelfRef.rampart_i2c__DOT__timing_thd_sta 
                    = (0x0000ffffU & vlSelfRef.rampart_i2c__DOT__tl_req_wdata);
                vlSelfRef.rampart_i2c__DOT__timing_tsu_sta 
                    = (vlSelfRef.rampart_i2c__DOT__tl_req_wdata 
                       >> 0x10U);
            } else if ((0x00000028U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                ++(vlSymsp->__Vcoverage[1791]);
                vlSelfRef.rampart_i2c__DOT__timing_thd_dat 
                    = (0x0000ffffU & vlSelfRef.rampart_i2c__DOT__tl_req_wdata);
                vlSelfRef.rampart_i2c__DOT__timing_tsu_dat 
                    = (vlSelfRef.rampart_i2c__DOT__tl_req_wdata 
                       >> 0x10U);
            } else if ((0x0000002cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                ++(vlSymsp->__Vcoverage[1792]);
                vlSelfRef.rampart_i2c__DOT__timing_t_buf 
                    = (0x0000ffffU & vlSelfRef.rampart_i2c__DOT__tl_req_wdata);
                vlSelfRef.rampart_i2c__DOT__timing_tsu_sto 
                    = (vlSelfRef.rampart_i2c__DOT__tl_req_wdata 
                       >> 0x10U);
            } else {
                ++(vlSymsp->__Vcoverage[1793]);
            }
            ++(vlSymsp->__Vcoverage[1794]);
        } else {
            ++(vlSymsp->__Vcoverage[1795]);
        }
        if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid) 
             & (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write))) {
            ++(vlSymsp->__Vcoverage[1796]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)))) {
            ++(vlSymsp->__Vcoverage[1797]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid)))) {
            ++(vlSymsp->__Vcoverage[1798]);
        }
    } else {
        ++(vlSymsp->__Vcoverage[1799]);
        vlSelfRef.rampart_i2c__DOT__timing_tlow = 0U;
        vlSelfRef.rampart_i2c__DOT__timing_thigh = 0U;
        vlSelfRef.rampart_i2c__DOT__timing_t_f = 0U;
        vlSelfRef.rampart_i2c__DOT__timing_t_r = 0U;
        vlSelfRef.rampart_i2c__DOT__timing_thd_sta = 0U;
        vlSelfRef.rampart_i2c__DOT__timing_tsu_sta = 0U;
        vlSelfRef.rampart_i2c__DOT__timing_thd_dat = 0U;
        vlSelfRef.rampart_i2c__DOT__timing_tsu_dat = 0U;
        vlSelfRef.rampart_i2c__DOT__timing_t_buf = 0U;
        vlSelfRef.rampart_i2c__DOT__timing_tsu_sto = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[1800]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[1801]);
    }
    ++(vlSymsp->__Vcoverage[1802]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_rdata) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_rdata))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1034, vlSelfRef.rampart_i2c__DOT__rx_fifo_rdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_rdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_rdata 
            = vlSelfRef.rampart_i2c__DOT__rx_fifo_rdata;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_empty) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_empty))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 996, vlSelfRef.rampart_i2c__DOT__rx_fifo_empty, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_empty);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_empty 
            = vlSelfRef.rampart_i2c__DOT__rx_fifo_empty;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_level) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_level))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 1000, vlSelfRef.rampart_i2c__DOT__rx_fifo_level, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_level);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_level 
            = vlSelfRef.rampart_i2c__DOT__rx_fifo_level;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_full) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_full))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 998, vlSelfRef.rampart_i2c__DOT__rx_fifo_full, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_full);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_full 
            = vlSelfRef.rampart_i2c__DOT__rx_fifo_full;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_rdata))) {
        VL_COV_TOGGLE_CHG_ST_I(13, vlSymsp->__Vcoverage + 942, vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_rdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_rdata 
            = vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata;
    }
    vlSelfRef.rampart_i2c__DOT__host_cmd_byte = (0x000000ffU 
                                                 & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata));
    vlSelfRef.rampart_i2c__DOT__host_cmd_start = (1U 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata) 
                                                     >> 8U));
    vlSelfRef.rampart_i2c__DOT__host_cmd_stop = (1U 
                                                 & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata) 
                                                    >> 9U));
    vlSelfRef.rampart_i2c__DOT__host_cmd_readb = (1U 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata) 
                                                     >> 0x0000000aU));
    vlSelfRef.rampart_i2c__DOT__host_cmd_rcont = (1U 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata) 
                                                     >> 0x0000000bU));
    vlSelfRef.rampart_i2c__DOT__host_cmd_nakok = (1U 
                                                  & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_rdata) 
                                                     >> 0x0000000cU));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_full) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_full))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 896, vlSelfRef.rampart_i2c__DOT__fmt_fifo_full, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_full);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_full 
            = vlSelfRef.rampart_i2c__DOT__fmt_fifo_full;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_level) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_level))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 898, vlSelfRef.rampart_i2c__DOT__fmt_fifo_level, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_level);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_level 
            = vlSelfRef.rampart_i2c__DOT__fmt_fifo_level;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_empty))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 894, vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_empty);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_empty 
            = vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_full) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_full))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1080, vlSelfRef.rampart_i2c__DOT__tx_fifo_full, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_full);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_full 
            = vlSelfRef.rampart_i2c__DOT__tx_fifo_full;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_level) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_level))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 1082, vlSelfRef.rampart_i2c__DOT__tx_fifo_level, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_level);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_level 
            = vlSelfRef.rampart_i2c__DOT__tx_fifo_level;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_rdata) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_rdata))) {
        VL_COV_TOGGLE_CHG_ST_I(10, vlSymsp->__Vcoverage + 1202, vlSelfRef.rampart_i2c__DOT__acq_fifo_rdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_rdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_rdata 
            = vlSelfRef.rampart_i2c__DOT__acq_fifo_rdata;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_empty) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_empty))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1160, vlSelfRef.rampart_i2c__DOT__acq_fifo_empty, vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_empty);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_empty 
            = vlSelfRef.rampart_i2c__DOT__acq_fifo_empty;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_level) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_level))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 1164, vlSelfRef.rampart_i2c__DOT__acq_fifo_level, vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_level);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_level 
            = vlSelfRef.rampart_i2c__DOT__acq_fifo_level;
    }
    vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata = vlSelfRef.rampart_i2c__DOT__tx_fifo_mem
        [(0x0000003fU & (IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr))];
    vlSelfRef.rampart_i2c__DOT__tgt_tx_shift = __Vdly__rampart_i2c__DOT__tgt_tx_shift;
    vlSelfRef.rampart_i2c__DOT__tgt_bit_idx = __Vdly__rampart_i2c__DOT__tgt_bit_idx;
    vlSelfRef.rampart_i2c__DOT__scl_rising = ((~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq)) 
                                              & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q));
    vlSelfRef.rampart_i2c__DOT__scl_falling = ((~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)) 
                                               & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq));
    vlSelfRef.rampart_i2c__DOT__tgt_rx_shift = __Vdly__rampart_i2c__DOT__tgt_rx_shift;
    vlSelfRef.rampart_i2c__DOT__tgt_addr_shift = __Vdly__rampart_i2c__DOT__tgt_addr_shift;
    vlSelfRef.rampart_i2c__DOT__tgt_rw_bit = __Vdly__rampart_i2c__DOT__tgt_rw_bit;
    vlSelfRef.rampart_i2c__DOT__tgt_addr_match = __Vdly__rampart_i2c__DOT__tgt_addr_match;
    vlSelfRef.rampart_i2c__DOT__acq_fifo_full = (((1U 
                                                   & ((IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr) 
                                                      >> 6U)) 
                                                  != 
                                                  (1U 
                                                   & ((IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr) 
                                                      >> 6U))) 
                                                 & ((0x0000003fU 
                                                     & (IData)(vlSelfRef.rampart_i2c__DOT__acq_wptr)) 
                                                    == 
                                                    (0x0000003fU 
                                                     & (IData)(vlSelfRef.rampart_i2c__DOT__acq_rptr))));
    vlSelfRef.rampart_i2c__DOT__tgt_state = __Vdly__rampart_i2c__DOT__tgt_state;
    vlSelfRef.rampart_i2c__DOT__tx_fifo_empty = ((IData)(vlSelfRef.rampart_i2c__DOT__tx_rptr) 
                                                 == (IData)(vlSelfRef.rampart_i2c__DOT__tx_wptr));
    vlSelfRef.rampart_i2c__DOT__sda_in_q = __Vdly__rampart_i2c__DOT__sda_in_q;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_wdata) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_wdata))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1018, vlSelfRef.rampart_i2c__DOT__rx_fifo_wdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_wdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_wdata 
            = vlSelfRef.rampart_i2c__DOT__rx_fifo_wdata;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_push) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_push))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1014, vlSelfRef.rampart_i2c__DOT__rx_fifo_push, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_push);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_push 
            = vlSelfRef.rampart_i2c__DOT__rx_fifo_push;
    }
    vlSelfRef.rampart_i2c__DOT__rx_overflow_det = ((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_full) 
                                                   & (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_push));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_a_valid_i) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__tl_a_ready_o))) {
        ++(vlSymsp->__Vcoverage[1716]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_a_ready_o)))) {
        ++(vlSymsp->__Vcoverage[1717]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_a_valid_i)))) {
        ++(vlSymsp->__Vcoverage[1718]);
    }
    if ((1U == (IData)(vlSelfRef.rampart_i2c__DOT__tl_a_opcode_i))) {
        ++(vlSymsp->__Vcoverage[1719]);
    }
    if ((0U == (IData)(vlSelfRef.rampart_i2c__DOT__tl_a_opcode_i))) {
        ++(vlSymsp->__Vcoverage[1720]);
    }
    if (((0U != (IData)(vlSelfRef.rampart_i2c__DOT__tl_a_opcode_i)) 
         & (1U != (IData)(vlSelfRef.rampart_i2c__DOT__tl_a_opcode_i)))) {
        ++(vlSymsp->__Vcoverage[1721]);
    }
    ++(vlSymsp->__Vcoverage[1722]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_a_ready_o) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_ready_o))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 6, vlSelfRef.rampart_i2c__DOT__tl_a_ready_o, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_ready_o);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_a_ready_o 
            = vlSelfRef.rampart_i2c__DOT__tl_a_ready_o;
    }
    vlSelfRef.tl_a_ready_o = vlSelfRef.rampart_i2c__DOT__tl_a_ready_o;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__intr_o) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_o))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 272, vlSelfRef.rampart_i2c__DOT__intr_o, vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_o);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_o 
            = vlSelfRef.rampart_i2c__DOT__intr_o;
    }
    vlSelfRef.intr_o = vlSelfRef.rampart_i2c__DOT__intr_o;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_pop) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_pop))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 914, vlSelfRef.rampart_i2c__DOT__fmt_fifo_pop, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_pop);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_pop 
            = vlSelfRef.rampart_i2c__DOT__fmt_fifo_pop;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timing_done))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2040, vlSelfRef.rampart_i2c__DOT__host_timing_done, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timing_done);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timing_done 
            = vlSelfRef.rampart_i2c__DOT__host_timing_done;
    }
    vlSelfRef.rampart_i2c__DOT__trans_complete_det 
        = ((0U != (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
           & ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty) 
              & ((0x0aU == (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
                 & (IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done))));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_sda_oe) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_sda_oe))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1244, vlSelfRef.rampart_i2c__DOT__host_sda_oe, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_sda_oe);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_sda_oe 
            = vlSelfRef.rampart_i2c__DOT__host_sda_oe;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_scl_oe) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_scl_oe))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1242, vlSelfRef.rampart_i2c__DOT__host_scl_oe, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_scl_oe);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_scl_oe 
            = vlSelfRef.rampart_i2c__DOT__host_scl_oe;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_byte) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_byte))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1370, vlSelfRef.rampart_i2c__DOT__host_cmd_byte, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_byte);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_byte 
            = vlSelfRef.rampart_i2c__DOT__host_cmd_byte;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_start) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_start))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1360, vlSelfRef.rampart_i2c__DOT__host_cmd_start, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_start);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_start 
            = vlSelfRef.rampart_i2c__DOT__host_cmd_start;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_stop) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_stop))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1362, vlSelfRef.rampart_i2c__DOT__host_cmd_stop, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_stop);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_stop 
            = vlSelfRef.rampart_i2c__DOT__host_cmd_stop;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_readb) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_readb))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1364, vlSelfRef.rampart_i2c__DOT__host_cmd_readb, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_readb);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_readb 
            = vlSelfRef.rampart_i2c__DOT__host_cmd_readb;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_rcont) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_rcont))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1366, vlSelfRef.rampart_i2c__DOT__host_cmd_rcont, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_rcont);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_rcont 
            = vlSelfRef.rampart_i2c__DOT__host_cmd_rcont;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_nakok) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_nakok))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1368, vlSelfRef.rampart_i2c__DOT__host_cmd_nakok, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_nakok);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_cmd_nakok 
            = vlSelfRef.rampart_i2c__DOT__host_cmd_nakok;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_push) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_push))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1178, vlSelfRef.rampart_i2c__DOT__acq_fifo_push, vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_push);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_push 
            = vlSelfRef.rampart_i2c__DOT__acq_fifo_push;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_pop) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_pop))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1098, vlSelfRef.rampart_i2c__DOT__tx_fifo_pop, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_pop);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_pop 
            = vlSelfRef.rampart_i2c__DOT__tx_fifo_pop;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_wdata) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_wdata))) {
        VL_COV_TOGGLE_CHG_ST_I(10, vlSymsp->__Vcoverage + 1182, vlSelfRef.rampart_i2c__DOT__acq_fifo_wdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_wdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_wdata 
            = vlSelfRef.rampart_i2c__DOT__acq_fifo_wdata;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_rdata))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1116, vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_rdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_rdata 
            = vlSelfRef.rampart_i2c__DOT__tx_fifo_rdata;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_tx_shift) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_tx_shift))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1428, vlSelfRef.rampart_i2c__DOT__tgt_tx_shift, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_tx_shift);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_tx_shift 
            = vlSelfRef.rampart_i2c__DOT__tgt_tx_shift;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_bit_idx) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_bit_idx))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 1404, vlSelfRef.rampart_i2c__DOT__tgt_bit_idx, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_bit_idx);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_bit_idx 
            = vlSelfRef.rampart_i2c__DOT__tgt_bit_idx;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_rising) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_rising))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1981, vlSelfRef.rampart_i2c__DOT__scl_rising, vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_rising);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_rising 
            = vlSelfRef.rampart_i2c__DOT__scl_rising;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_falling) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_falling))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1983, vlSelfRef.rampart_i2c__DOT__scl_falling, vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_falling);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_falling 
            = vlSelfRef.rampart_i2c__DOT__scl_falling;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_rx_shift) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_rx_shift))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1412, vlSelfRef.rampart_i2c__DOT__tgt_rx_shift, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_rx_shift);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_rx_shift 
            = vlSelfRef.rampart_i2c__DOT__tgt_rx_shift;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_addr_shift) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_addr_shift))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 1388, vlSelfRef.rampart_i2c__DOT__tgt_addr_shift, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_addr_shift);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_addr_shift 
            = vlSelfRef.rampart_i2c__DOT__tgt_addr_shift;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_rw_bit) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_rw_bit))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1402, vlSelfRef.rampart_i2c__DOT__tgt_rw_bit, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_rw_bit);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_rw_bit 
            = vlSelfRef.rampart_i2c__DOT__tgt_rw_bit;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_addr_match) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_addr_match))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1444, vlSelfRef.rampart_i2c__DOT__tgt_addr_match, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_addr_match);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_addr_match 
            = vlSelfRef.rampart_i2c__DOT__tgt_addr_match;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_full) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_full))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1162, vlSelfRef.rampart_i2c__DOT__acq_fifo_full, vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_full);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_full 
            = vlSelfRef.rampart_i2c__DOT__acq_fifo_full;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_state) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_state))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 1258, vlSelfRef.rampart_i2c__DOT__tgt_state, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_state);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_state 
            = vlSelfRef.rampart_i2c__DOT__tgt_state;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_scl_drive_low))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2213, vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_scl_drive_low);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_scl_drive_low 
            = vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low;
    }
    vlSelfRef.rampart_i2c__DOT__tgt_scl_oe = vlSelfRef.rampart_i2c__DOT__tgt_scl_drive_low;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_sda_drive_low))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2215, vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_sda_drive_low);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_sda_drive_low 
            = vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low;
    }
    vlSelfRef.rampart_i2c__DOT__tgt_sda_oe = vlSelfRef.rampart_i2c__DOT__tgt_sda_drive_low;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_stretch_needed))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1446, vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_stretch_needed);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_stretch_needed 
            = vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_empty) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_empty))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1078, vlSelfRef.rampart_i2c__DOT__tx_fifo_empty, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_empty);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_empty 
            = vlSelfRef.rampart_i2c__DOT__tx_fifo_empty;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_in_q))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1236, vlSelfRef.rampart_i2c__DOT__sda_in_q, vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_in_q);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_in_q 
            = vlSelfRef.rampart_i2c__DOT__sda_in_q;
    }
    if (((~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q))) {
        ++(vlSymsp->__Vcoverage[1993]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)))) {
        ++(vlSymsp->__Vcoverage[1994]);
    }
    if (vlSelfRef.rampart_i2c__DOT__scl_in_qq) {
        ++(vlSymsp->__Vcoverage[1995]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq) 
         & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)))) {
        ++(vlSymsp->__Vcoverage[1996]);
    }
    if (vlSelfRef.rampart_i2c__DOT__scl_in_q) {
        ++(vlSymsp->__Vcoverage[1997]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq)))) {
        ++(vlSymsp->__Vcoverage[1998]);
    }
    if (((~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q))) {
        ++(vlSymsp->__Vcoverage[1999]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)))) {
        ++(vlSymsp->__Vcoverage[2000]);
    }
    if (vlSelfRef.rampart_i2c__DOT__sda_in_qq) {
        ++(vlSymsp->__Vcoverage[2001]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq) 
         & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)))) {
        ++(vlSymsp->__Vcoverage[2002]);
    }
    if (vlSelfRef.rampart_i2c__DOT__sda_in_q) {
        ++(vlSymsp->__Vcoverage[2003]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq)))) {
        ++(vlSymsp->__Vcoverage[2004]);
    }
    if (((((IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq) 
           & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)) 
          & (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq)) 
         & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)))) {
        ++(vlSymsp->__Vcoverage[2005]);
    }
    if (vlSelfRef.rampart_i2c__DOT__sda_in_q) {
        ++(vlSymsp->__Vcoverage[2006]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq)))) {
        ++(vlSymsp->__Vcoverage[2007]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)))) {
        ++(vlSymsp->__Vcoverage[2008]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq)))) {
        ++(vlSymsp->__Vcoverage[2009]);
    }
    if (((((IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq) 
           & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)) 
          & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq))) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q))) {
        ++(vlSymsp->__Vcoverage[2010]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)))) {
        ++(vlSymsp->__Vcoverage[2011]);
    }
    if (vlSelfRef.rampart_i2c__DOT__sda_in_qq) {
        ++(vlSymsp->__Vcoverage[2012]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)))) {
        ++(vlSymsp->__Vcoverage[2013]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq)))) {
        ++(vlSymsp->__Vcoverage[2014]);
    }
    ++(vlSymsp->__Vcoverage[2015]);
    vlSelfRef.rampart_i2c__DOT__nak_det = (((3U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
                                            | (5U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) 
                                           & ((~ (IData)(vlSelfRef.rampart_i2c__DOT__host_scl_drive_low)) 
                                              & ((IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done) 
                                                 & ((~ (IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_nakok)) 
                                                    & (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)))));
    __VdfgRegularize_h6e95ff9d_0_6 = ((~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)) 
                                      & (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq));
    __VdfgRegularize_h6e95ff9d_0_1 = ((~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq)) 
                                      & (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q));
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        if ((((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid) 
              & (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)) 
             & (0U == vlSelfRef.rampart_i2c__DOT__tl_req_addr))) {
            ++(vlSymsp->__Vcoverage[1778]);
            vlSelfRef.rampart_i2c__DOT__ctrl_reg = vlSelfRef.rampart_i2c__DOT__tl_req_wdata;
            vlSelfRef.rampart_i2c__DOT__ctrl_host_enable 
                = (1U & vlSelfRef.rampart_i2c__DOT__tl_req_wdata);
            vlSelfRef.rampart_i2c__DOT__ctrl_target_enable 
                = (1U & (vlSelfRef.rampart_i2c__DOT__tl_req_wdata 
                         >> 1U));
            vlSelfRef.rampart_i2c__DOT__ctrl_line_loopback 
                = (1U & (vlSelfRef.rampart_i2c__DOT__tl_req_wdata 
                         >> 2U));
        } else {
            ++(vlSymsp->__Vcoverage[1779]);
        }
        if ((((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid) 
              & (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)) 
             & (0U == vlSelfRef.rampart_i2c__DOT__tl_req_addr))) {
            ++(vlSymsp->__Vcoverage[1780]);
        }
        if ((0U != vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
            ++(vlSymsp->__Vcoverage[1781]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)))) {
            ++(vlSymsp->__Vcoverage[1782]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid)))) {
            ++(vlSymsp->__Vcoverage[1783]);
        }
    } else {
        ++(vlSymsp->__Vcoverage[1784]);
        vlSelfRef.rampart_i2c__DOT__ctrl_reg = 0U;
        vlSelfRef.rampart_i2c__DOT__ctrl_host_enable = 0U;
        vlSelfRef.rampart_i2c__DOT__ctrl_target_enable = 0U;
        vlSelfRef.rampart_i2c__DOT__ctrl_line_loopback = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[1785]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[1786]);
    }
    ++(vlSymsp->__Vcoverage[1787]);
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        if ((((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid) 
              & (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)) 
             & (0x00000030U == vlSelfRef.rampart_i2c__DOT__tl_req_addr))) {
            ++(vlSymsp->__Vcoverage[1803]);
            vlSelfRef.rampart_i2c__DOT__target_address 
                = (0x0000007fU & vlSelfRef.rampart_i2c__DOT__tl_req_wdata);
            vlSelfRef.rampart_i2c__DOT__target_mask 
                = (0x0000007fU & (vlSelfRef.rampart_i2c__DOT__tl_req_wdata 
                                  >> 7U));
        } else {
            ++(vlSymsp->__Vcoverage[1804]);
        }
        if ((((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid) 
              & (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)) 
             & (0x00000030U == vlSelfRef.rampart_i2c__DOT__tl_req_addr))) {
            ++(vlSymsp->__Vcoverage[1805]);
        }
        if ((0x00000030U != vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
            ++(vlSymsp->__Vcoverage[1806]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_write)))) {
            ++(vlSymsp->__Vcoverage[1807]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid)))) {
            ++(vlSymsp->__Vcoverage[1808]);
        }
    } else {
        ++(vlSymsp->__Vcoverage[1809]);
        vlSelfRef.rampart_i2c__DOT__target_address = 0U;
        vlSelfRef.rampart_i2c__DOT__target_mask = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rst_ni)))) {
        ++(vlSymsp->__Vcoverage[1810]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rst_ni) {
        ++(vlSymsp->__Vcoverage[1811]);
    }
    ++(vlSymsp->__Vcoverage[1812]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_overflow_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_overflow_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2357, vlSelfRef.rampart_i2c__DOT__rx_overflow_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_overflow_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_overflow_det 
            = vlSelfRef.rampart_i2c__DOT__rx_overflow_det;
    }
    if ((vlSelfRef.rampart_i2c__DOT__host_timeout_val 
         ^ vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_val)) {
        VL_COV_TOGGLE_CHG_ST_I(20, vlSymsp->__Vcoverage + 728, vlSelfRef.rampart_i2c__DOT__host_timeout_val, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_val);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_val 
            = vlSelfRef.rampart_i2c__DOT__host_timeout_val;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__host_timeout_en) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_en))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 768, vlSelfRef.rampart_i2c__DOT__host_timeout_en, vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_en);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__host_timeout_en 
            = vlSelfRef.rampart_i2c__DOT__host_timeout_en;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__trans_complete_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__trans_complete_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2363, vlSelfRef.rampart_i2c__DOT__trans_complete_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__trans_complete_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__trans_complete_det 
            = vlSelfRef.rampart_i2c__DOT__trans_complete_det;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_tlow) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tlow))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 374, vlSelfRef.rampart_i2c__DOT__timing_tlow, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tlow);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tlow 
            = vlSelfRef.rampart_i2c__DOT__timing_tlow;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_thigh) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_thigh))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 406, vlSelfRef.rampart_i2c__DOT__timing_thigh, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_thigh);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_thigh 
            = vlSelfRef.rampart_i2c__DOT__timing_thigh;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_t_f) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_t_f))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 470, vlSelfRef.rampart_i2c__DOT__timing_t_f, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_t_f);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_t_f 
            = vlSelfRef.rampart_i2c__DOT__timing_t_f;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_t_r) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_t_r))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 438, vlSelfRef.rampart_i2c__DOT__timing_t_r, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_t_r);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_t_r 
            = vlSelfRef.rampart_i2c__DOT__timing_t_r;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_thd_sta) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_thd_sta))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 534, vlSelfRef.rampart_i2c__DOT__timing_thd_sta, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_thd_sta);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_thd_sta 
            = vlSelfRef.rampart_i2c__DOT__timing_thd_sta;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_tsu_sta) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tsu_sta))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 502, vlSelfRef.rampart_i2c__DOT__timing_tsu_sta, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tsu_sta);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tsu_sta 
            = vlSelfRef.rampart_i2c__DOT__timing_tsu_sta;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_thd_dat) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_thd_dat))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 598, vlSelfRef.rampart_i2c__DOT__timing_thd_dat, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_thd_dat);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_thd_dat 
            = vlSelfRef.rampart_i2c__DOT__timing_thd_dat;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_tsu_dat) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tsu_dat))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 566, vlSelfRef.rampart_i2c__DOT__timing_tsu_dat, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tsu_dat);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tsu_dat 
            = vlSelfRef.rampart_i2c__DOT__timing_tsu_dat;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_t_buf) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_t_buf))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 662, vlSelfRef.rampart_i2c__DOT__timing_t_buf, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_t_buf);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_t_buf 
            = vlSelfRef.rampart_i2c__DOT__timing_t_buf;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__timing_tsu_sto) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tsu_sto))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 630, vlSelfRef.rampart_i2c__DOT__timing_tsu_sto, vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tsu_sto);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__timing_tsu_sto 
            = vlSelfRef.rampart_i2c__DOT__timing_tsu_sto;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_scl_oe) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_scl_oe))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1246, vlSelfRef.rampart_i2c__DOT__tgt_scl_oe, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_scl_oe);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_scl_oe 
            = vlSelfRef.rampart_i2c__DOT__tgt_scl_oe;
    }
    rampart_i2c__DOT____VdfgExtracted_h748dde20__0 
        = ((IData)(vlSelfRef.rampart_i2c__DOT__host_scl_oe) 
           | (IData)(vlSelfRef.rampart_i2c__DOT__tgt_scl_oe));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_sda_oe) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_sda_oe))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1248, vlSelfRef.rampart_i2c__DOT__tgt_sda_oe, vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_sda_oe);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tgt_sda_oe 
            = vlSelfRef.rampart_i2c__DOT__tgt_sda_oe;
    }
    rampart_i2c__DOT____VdfgExtracted_he4f4c8eb__0 
        = ((IData)(vlSelfRef.rampart_i2c__DOT__host_sda_oe) 
           | (IData)(vlSelfRef.rampart_i2c__DOT__tgt_sda_oe));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__nak_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__nak_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2361, vlSelfRef.rampart_i2c__DOT__nak_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__nak_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__nak_det 
            = vlSelfRef.rampart_i2c__DOT__nak_det;
    }
    vlSelfRef.rampart_i2c__DOT__sda_falling = __VdfgRegularize_h6e95ff9d_0_6;
    vlSelfRef.rampart_i2c__DOT__start_det = ((IData)(__VdfgRegularize_h6e95ff9d_0_5) 
                                             & (IData)(__VdfgRegularize_h6e95ff9d_0_6));
    vlSelfRef.rampart_i2c__DOT__sda_rising = __VdfgRegularize_h6e95ff9d_0_1;
    vlSelfRef.rampart_i2c__DOT__stop_det = ((IData)(__VdfgRegularize_h6e95ff9d_0_5) 
                                            & (IData)(__VdfgRegularize_h6e95ff9d_0_1));
    vlSelfRef.rampart_i2c__DOT__tl_req_valid = ((IData)(vlSelfRef.rampart_i2c__DOT__tl_a_ready_o) 
                                                & (IData)(vlSelfRef.rampart_i2c__DOT__tl_a_valid_i));
    if (vlSelfRef.rampart_i2c__DOT__ovrd_txovrden) {
        vlSelfRef.rampart_i2c__DOT__scl_oe_o = (1U 
                                                & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ovrd_sclval)));
        vlSelfRef.rampart_i2c__DOT__sda_oe_o = (1U 
                                                & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ovrd_sdaval)));
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ovrd_sclval)))) {
            ++(vlSymsp->__Vcoverage[2024]);
        }
        if (vlSelfRef.rampart_i2c__DOT__ovrd_sclval) {
            ++(vlSymsp->__Vcoverage[2025]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ovrd_sdaval)))) {
            ++(vlSymsp->__Vcoverage[2026]);
        }
        if (vlSelfRef.rampart_i2c__DOT__ovrd_sdaval) {
            ++(vlSymsp->__Vcoverage[2027]);
        }
        ++(vlSymsp->__Vcoverage[2034]);
    } else {
        vlSelfRef.rampart_i2c__DOT__scl_oe_o = rampart_i2c__DOT____VdfgExtracted_h748dde20__0;
        vlSelfRef.rampart_i2c__DOT__sda_oe_o = rampart_i2c__DOT____VdfgExtracted_he4f4c8eb__0;
        if (vlSelfRef.rampart_i2c__DOT__tgt_scl_oe) {
            ++(vlSymsp->__Vcoverage[2028]);
        }
        if (vlSelfRef.rampart_i2c__DOT__host_scl_oe) {
            ++(vlSymsp->__Vcoverage[2029]);
        }
        if ((1U & (~ (IData)(rampart_i2c__DOT____VdfgExtracted_h748dde20__0)))) {
            ++(vlSymsp->__Vcoverage[2030]);
        }
        if (vlSelfRef.rampart_i2c__DOT__tgt_sda_oe) {
            ++(vlSymsp->__Vcoverage[2031]);
        }
        if (vlSelfRef.rampart_i2c__DOT__host_sda_oe) {
            ++(vlSymsp->__Vcoverage[2032]);
        }
        if ((1U & (~ (IData)(rampart_i2c__DOT____VdfgExtracted_he4f4c8eb__0)))) {
            ++(vlSymsp->__Vcoverage[2033]);
        }
        ++(vlSymsp->__Vcoverage[2035]);
    }
    ++(vlSymsp->__Vcoverage[2036]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_falling) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_falling))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1987, vlSelfRef.rampart_i2c__DOT__sda_falling, vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_falling);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_falling 
            = vlSelfRef.rampart_i2c__DOT__sda_falling;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__start_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__start_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1989, vlSelfRef.rampart_i2c__DOT__start_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__start_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__start_det 
            = vlSelfRef.rampart_i2c__DOT__start_det;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_rising) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_rising))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1985, vlSelfRef.rampart_i2c__DOT__sda_rising, vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_rising);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_rising 
            = vlSelfRef.rampart_i2c__DOT__sda_rising;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__stop_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__stop_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1991, vlSelfRef.rampart_i2c__DOT__stop_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__stop_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__stop_det 
            = vlSelfRef.rampart_i2c__DOT__stop_det;
    }
    vlSelfRef.rampart_i2c__DOT__sda_unstable_det = 
        ((IData)(__VdfgRegularize_h6e95ff9d_0_5) & 
         ((~ (IData)(vlSelfRef.rampart_i2c__DOT__start_det)) 
          & (((IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q) 
              != (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq)) 
             & ((~ (IData)(vlSelfRef.rampart_i2c__DOT__stop_det)) 
                & (IData)(vlSelfRef.rampart_i2c__DOT__bus_active)))));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_line_loopback) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_line_loopback))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 308, vlSelfRef.rampart_i2c__DOT__ctrl_line_loopback, vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_line_loopback);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_line_loopback 
            = vlSelfRef.rampart_i2c__DOT__ctrl_line_loopback;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_target_enable))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 306, vlSelfRef.rampart_i2c__DOT__ctrl_target_enable, vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_target_enable);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_target_enable 
            = vlSelfRef.rampart_i2c__DOT__ctrl_target_enable;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_host_enable))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 304, vlSelfRef.rampart_i2c__DOT__ctrl_host_enable, vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_host_enable);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_host_enable 
            = vlSelfRef.rampart_i2c__DOT__ctrl_host_enable;
    }
    if (((((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable) 
           & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_scl_drive_low))) 
          & (0U != (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) 
         & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)))) {
        ++(vlSymsp->__Vcoverage[2335]);
    }
    if (vlSelfRef.rampart_i2c__DOT__scl_in_q) {
        ++(vlSymsp->__Vcoverage[2336]);
    }
    if ((0U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
        ++(vlSymsp->__Vcoverage[2337]);
    }
    if (vlSelfRef.rampart_i2c__DOT__host_scl_drive_low) {
        ++(vlSymsp->__Vcoverage[2338]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable)))) {
        ++(vlSymsp->__Vcoverage[2339]);
    }
    if ((((((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable) 
            & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_sda_drive_low))) 
           & (2U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) 
          & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q))) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q))) {
        ++(vlSymsp->__Vcoverage[2340]);
    }
    if ((((((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable) 
            & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_sda_drive_low))) 
           & (4U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) 
          & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q))) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q))) {
        ++(vlSymsp->__Vcoverage[2341]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)))) {
        ++(vlSymsp->__Vcoverage[2342]);
    }
    if (vlSelfRef.rampart_i2c__DOT__sda_in_q) {
        ++(vlSymsp->__Vcoverage[2343]);
    }
    if (((4U != (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
         & (2U != (IData)(vlSelfRef.rampart_i2c__DOT__host_state)))) {
        ++(vlSymsp->__Vcoverage[2344]);
    }
    if (vlSelfRef.rampart_i2c__DOT__host_sda_drive_low) {
        ++(vlSymsp->__Vcoverage[2345]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable)))) {
        ++(vlSymsp->__Vcoverage[2346]);
    }
    if (((((((IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q) 
             & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq)) 
            & ((IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q) 
               != (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq))) 
           & (~ (IData)(vlSelfRef.rampart_i2c__DOT__start_det))) 
          & (~ (IData)(vlSelfRef.rampart_i2c__DOT__stop_det))) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__bus_active))) {
        ++(vlSymsp->__Vcoverage[2347]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__bus_active)))) {
        ++(vlSymsp->__Vcoverage[2348]);
    }
    if (vlSelfRef.rampart_i2c__DOT__stop_det) {
        ++(vlSymsp->__Vcoverage[2349]);
    }
    if (vlSelfRef.rampart_i2c__DOT__start_det) {
        ++(vlSymsp->__Vcoverage[2350]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q) 
         == (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_qq))) {
        ++(vlSymsp->__Vcoverage[2351]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_qq)))) {
        ++(vlSymsp->__Vcoverage[2352]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)))) {
        ++(vlSymsp->__Vcoverage[2353]);
    }
    ++(vlSymsp->__Vcoverage[2354]);
    vlSelfRef.rampart_i2c__DOT__scl_interference_det 
        = ((~ (IData)(vlSelfRef.rampart_i2c__DOT__host_scl_drive_low)) 
           & ((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable) 
              & ((~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q)) 
                 & (0U != (IData)(vlSelfRef.rampart_i2c__DOT__host_state)))));
    vlSelfRef.rampart_i2c__DOT__sda_interference_det 
        = ((IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable) 
           & (((~ (IData)(vlSelfRef.rampart_i2c__DOT__host_sda_drive_low)) 
               & ((4U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
                  | (2U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state)))) 
              & ((~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)) 
                 & (IData)(vlSelfRef.rampart_i2c__DOT__scl_in_q))));
    if ((vlSelfRef.rampart_i2c__DOT__ctrl_reg ^ vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_reg)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 310, vlSelfRef.rampart_i2c__DOT__ctrl_reg, vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_reg);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__ctrl_reg 
            = vlSelfRef.rampart_i2c__DOT__ctrl_reg;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__target_address) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__target_address))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 694, vlSelfRef.rampart_i2c__DOT__target_address, vlSelfRef.rampart_i2c__DOT____Vtogcov__target_address);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__target_address 
            = vlSelfRef.rampart_i2c__DOT__target_address;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__target_mask) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__target_mask))) {
        VL_COV_TOGGLE_CHG_ST_I(7, vlSymsp->__Vcoverage + 708, vlSelfRef.rampart_i2c__DOT__target_mask, vlSelfRef.rampart_i2c__DOT____Vtogcov__target_mask);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__target_mask 
            = vlSelfRef.rampart_i2c__DOT__target_mask;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_req_valid) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_valid))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1492, vlSelfRef.rampart_i2c__DOT__tl_req_valid, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_valid);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_req_valid 
            = vlSelfRef.rampart_i2c__DOT__tl_req_valid;
    }
    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata = 0U;
    vlSelfRef.rampart_i2c__DOT__tl_rsp_error = 0U;
    vlSelfRef.rampart_i2c__DOT__fmt_fifo_push = 0U;
    vlSelfRef.rampart_i2c__DOT__fmt_fifo_wdata = 0U;
    vlSelfRef.rampart_i2c__DOT__rx_fifo_pop = 0U;
    vlSelfRef.rampart_i2c__DOT__tx_fifo_push = 0U;
    vlSelfRef.rampart_i2c__DOT__tx_fifo_wdata = 0U;
    vlSelfRef.rampart_i2c__DOT__acq_fifo_pop = 0U;
    if (vlSelfRef.rampart_i2c__DOT__tl_req_valid) {
        if (vlSelfRef.rampart_i2c__DOT__tl_req_write) {
            if ((((((((((((((((0U == vlSelfRef.rampart_i2c__DOT__tl_req_addr) 
                              || (0x0000000cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                             || (0x00000010U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                            || (0x00000018U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                           || (0x0000001cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                          || (0x00000020U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                         || (0x00000024U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                        || (0x00000028U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                       || (0x0000002cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                      || (0x00000030U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                     || (0x00000038U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                    || (0x0000003cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                   || (0x00000040U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                  || (0x00000044U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                 || (0x00000048U == vlSelfRef.rampart_i2c__DOT__tl_req_addr))) {
                ++(vlSymsp->__Vcoverage[1743]);
            } else {
                vlSelfRef.rampart_i2c__DOT__tl_rsp_error = 1U;
                ++(vlSymsp->__Vcoverage[1744]);
            }
            if ((0x0000000cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                vlSelfRef.rampart_i2c__DOT__fmt_fifo_push = 1U;
                vlSelfRef.rampart_i2c__DOT__fmt_fifo_wdata 
                    = (0x00001fffU & vlSelfRef.rampart_i2c__DOT__tl_req_wdata);
                ++(vlSymsp->__Vcoverage[1745]);
            } else {
                ++(vlSymsp->__Vcoverage[1746]);
            }
            if ((0x00000038U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                vlSelfRef.rampart_i2c__DOT__tx_fifo_push = 1U;
                vlSelfRef.rampart_i2c__DOT__tx_fifo_wdata 
                    = (0x000000ffU & vlSelfRef.rampart_i2c__DOT__tl_req_wdata);
                ++(vlSymsp->__Vcoverage[1747]);
            } else {
                ++(vlSymsp->__Vcoverage[1748]);
            }
            ++(vlSymsp->__Vcoverage[1773]);
        } else {
            if (((((((((0U == vlSelfRef.rampart_i2c__DOT__tl_req_addr) 
                       | (4U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                      | (8U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                     | (0x0000000cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                    | (0x00000010U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                   | (0x00000014U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                  | (0x00000018U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                 | (0x0000001cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr))) {
                if ((0U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = vlSelfRef.rampart_i2c__DOT__ctrl_reg;
                    ++(vlSymsp->__Vcoverage[1749]);
                } else if ((4U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed) 
                            << 9U) | ((((((IData)(vlSelfRef.rampart_i2c__DOT__bus_active) 
                                          << 4U) | 
                                         (((0U == (IData)(vlSelfRef.rampart_i2c__DOT__tgt_state)) 
                                           << 3U) | 
                                          ((0U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
                                           << 2U))) 
                                        | (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_empty) 
                                            << 1U) 
                                           | (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_full))) 
                                       << 4U) | ((((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_empty) 
                                                   << 3U) 
                                                  | ((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_full) 
                                                     << 2U)) 
                                                 | (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty) 
                                                     << 1U) 
                                                    | (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_full)))));
                    ++(vlSymsp->__Vcoverage[1750]);
                } else if ((8U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = vlSelfRef.rampart_i2c__DOT__rx_fifo_rdata;
                    vlSelfRef.rampart_i2c__DOT__rx_fifo_pop 
                        = (1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_empty)));
                    ++(vlSymsp->__Vcoverage[1753]);
                } else if ((0x0000000cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata = 0U;
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_error = 1U;
                    ++(vlSymsp->__Vcoverage[1754]);
                } else if ((0x00000010U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata = 0U;
                    ++(vlSymsp->__Vcoverage[1755]);
                } else if ((0x00000014U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_level) 
                            << 0x00000015U) | (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_level) 
                                                << 0x0000000eU) 
                                               | (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_level) 
                                                   << 7U) 
                                                  | (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_level))));
                    ++(vlSymsp->__Vcoverage[1756]);
                } else if ((0x00000018U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__ovrd_sdaval) 
                            << 2U) | (((IData)(vlSelfRef.rampart_i2c__DOT__ovrd_sclval) 
                                       << 1U) | (IData)(vlSelfRef.rampart_i2c__DOT__ovrd_txovrden)));
                    ++(vlSymsp->__Vcoverage[1757]);
                } else {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__timing_thigh) 
                            << 0x00000010U) | (IData)(vlSelfRef.rampart_i2c__DOT__timing_tlow));
                    ++(vlSymsp->__Vcoverage[1758]);
                }
            } else if (((((((((0x00000020U == vlSelfRef.rampart_i2c__DOT__tl_req_addr) 
                              | (0x00000024U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                             | (0x00000028U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                            | (0x0000002cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                           | (0x00000030U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                          | (0x00000034U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                         | (0x00000038U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) 
                        | (0x0000003cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr))) {
                if ((0x00000020U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__timing_t_r) 
                            << 0x00000010U) | (IData)(vlSelfRef.rampart_i2c__DOT__timing_t_f));
                    ++(vlSymsp->__Vcoverage[1759]);
                } else if ((0x00000024U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__timing_tsu_sta) 
                            << 0x00000010U) | (IData)(vlSelfRef.rampart_i2c__DOT__timing_thd_sta));
                    ++(vlSymsp->__Vcoverage[1760]);
                } else if ((0x00000028U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__timing_tsu_dat) 
                            << 0x00000010U) | (IData)(vlSelfRef.rampart_i2c__DOT__timing_thd_dat));
                    ++(vlSymsp->__Vcoverage[1761]);
                } else if ((0x0000002cU == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__timing_tsu_sto) 
                            << 0x00000010U) | (IData)(vlSelfRef.rampart_i2c__DOT__timing_t_buf));
                    ++(vlSymsp->__Vcoverage[1762]);
                } else if ((0x00000030U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__target_mask) 
                            << 7U) | (IData)(vlSelfRef.rampart_i2c__DOT__target_address));
                    ++(vlSymsp->__Vcoverage[1763]);
                } else if ((0x00000034U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = vlSelfRef.rampart_i2c__DOT__acq_fifo_rdata;
                    vlSelfRef.rampart_i2c__DOT__acq_fifo_pop 
                        = (1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_empty)));
                    ++(vlSymsp->__Vcoverage[1766]);
                } else if ((0x00000038U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata = 0U;
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_error = 1U;
                    ++(vlSymsp->__Vcoverage[1767]);
                } else {
                    vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                        = (((IData)(vlSelfRef.rampart_i2c__DOT__host_timeout_en) 
                            << 0x00000014U) | vlSelfRef.rampart_i2c__DOT__host_timeout_val);
                    ++(vlSymsp->__Vcoverage[1768]);
                }
            } else if ((0x00000040U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                    = vlSelfRef.rampart_i2c__DOT__intr_state;
                ++(vlSymsp->__Vcoverage[1769]);
            } else if ((0x00000044U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata 
                    = vlSelfRef.rampart_i2c__DOT__intr_enable;
                ++(vlSymsp->__Vcoverage[1770]);
            } else if ((0x00000048U == vlSelfRef.rampart_i2c__DOT__tl_req_addr)) {
                vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata = 0U;
                ++(vlSymsp->__Vcoverage[1771]);
            } else {
                vlSelfRef.rampart_i2c__DOT__tl_rsp_error = 1U;
                ++(vlSymsp->__Vcoverage[1772]);
            }
            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_empty)))) {
                ++(vlSymsp->__Vcoverage[1751]);
            }
            if (vlSelfRef.rampart_i2c__DOT__rx_fifo_empty) {
                ++(vlSymsp->__Vcoverage[1752]);
            }
            if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_empty)))) {
                ++(vlSymsp->__Vcoverage[1764]);
            }
            if (vlSelfRef.rampart_i2c__DOT__acq_fifo_empty) {
                ++(vlSymsp->__Vcoverage[1765]);
            }
            ++(vlSymsp->__Vcoverage[1774]);
        }
        ++(vlSymsp->__Vcoverage[1775]);
    } else {
        ++(vlSymsp->__Vcoverage[1776]);
    }
    ++(vlSymsp->__Vcoverage[1777]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_oe_o) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_oe_o))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 266, vlSelfRef.rampart_i2c__DOT__scl_oe_o, vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_oe_o);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_oe_o 
            = vlSelfRef.rampart_i2c__DOT__scl_oe_o;
    }
    vlSelfRef.scl_oe_o = vlSelfRef.rampart_i2c__DOT__scl_oe_o;
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_oe_o) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_oe_o))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 270, vlSelfRef.rampart_i2c__DOT__sda_oe_o, vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_oe_o);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_oe_o 
            = vlSelfRef.rampart_i2c__DOT__sda_oe_o;
    }
    vlSelfRef.sda_oe_o = vlSelfRef.rampart_i2c__DOT__sda_oe_o;
    if (vlSelfRef.rampart_i2c__DOT__ctrl_line_loopback) {
        vlSelfRef.rampart_i2c__DOT__scl_in = (1U & 
                                              (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_oe_o)));
        vlSelfRef.rampart_i2c__DOT__sda_in = (1U & 
                                              (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_oe_o)));
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__scl_oe_o)))) {
            ++(vlSymsp->__Vcoverage[1969]);
        }
        if (vlSelfRef.rampart_i2c__DOT__scl_oe_o) {
            ++(vlSymsp->__Vcoverage[1970]);
        }
        if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_oe_o)))) {
            ++(vlSymsp->__Vcoverage[1971]);
        }
        if (vlSelfRef.rampart_i2c__DOT__sda_oe_o) {
            ++(vlSymsp->__Vcoverage[1972]);
        }
        ++(vlSymsp->__Vcoverage[1973]);
    } else {
        vlSelfRef.rampart_i2c__DOT__scl_in = vlSelfRef.rampart_i2c__DOT__scl_i;
        vlSelfRef.rampart_i2c__DOT__sda_in = vlSelfRef.rampart_i2c__DOT__sda_i;
        ++(vlSymsp->__Vcoverage[1974]);
    }
    ++(vlSymsp->__Vcoverage[1975]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_unstable_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_unstable_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2333, vlSelfRef.rampart_i2c__DOT__sda_unstable_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_unstable_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_unstable_det 
            = vlSelfRef.rampart_i2c__DOT__sda_unstable_det;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_interference_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_interference_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2331, vlSelfRef.rampart_i2c__DOT__scl_interference_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_interference_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_interference_det 
            = vlSelfRef.rampart_i2c__DOT__scl_interference_det;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_interference_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_interference_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2329, vlSelfRef.rampart_i2c__DOT__sda_interference_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_interference_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_interference_det 
            = vlSelfRef.rampart_i2c__DOT__sda_interference_det;
    }
    vlSelfRef.rampart_i2c__DOT__intr_hw_set = 0U;
    if (((1U >= (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_level)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable))) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (1U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2387]);
    } else {
        ++(vlSymsp->__Vcoverage[2388]);
    }
    if (((1U <= (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_level)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable))) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (2U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2392]);
    } else {
        ++(vlSymsp->__Vcoverage[2393]);
    }
    if (((1U <= (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_level)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (4U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2397]);
    } else {
        ++(vlSymsp->__Vcoverage[2398]);
    }
    if (vlSelfRef.rampart_i2c__DOT__rx_overflow_det) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (8U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2402]);
    } else {
        ++(vlSymsp->__Vcoverage[2403]);
    }
    if (vlSelfRef.rampart_i2c__DOT__nak_det) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00000010U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2404]);
    } else {
        ++(vlSymsp->__Vcoverage[2405]);
    }
    if (vlSelfRef.rampart_i2c__DOT__scl_interference_det) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00000020U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2406]);
    } else {
        ++(vlSymsp->__Vcoverage[2407]);
    }
    if (vlSelfRef.rampart_i2c__DOT__sda_interference_det) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00000040U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2408]);
    } else {
        ++(vlSymsp->__Vcoverage[2409]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__host_timeout_event))) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00000080U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2410]);
    } else {
        ++(vlSymsp->__Vcoverage[2411]);
    }
    if (vlSelfRef.rampart_i2c__DOT__sda_unstable_det) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00000100U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2415]);
    } else {
        ++(vlSymsp->__Vcoverage[2416]);
    }
    if (vlSelfRef.rampart_i2c__DOT__trans_complete_det) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00000200U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2417]);
    } else {
        ++(vlSymsp->__Vcoverage[2418]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_empty) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00000400U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2419]);
    } else {
        ++(vlSymsp->__Vcoverage[2420]);
    }
    if (((1U >= (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_level)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00000800U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2424]);
    } else {
        ++(vlSymsp->__Vcoverage[2425]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_full) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00001000U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2429]);
    } else {
        ++(vlSymsp->__Vcoverage[2430]);
    }
    if ((((IData)(vlSelfRef.rampart_i2c__DOT__stop_det) 
          & (IData)(vlSelfRef.rampart_i2c__DOT__tgt_addr_match)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00002000U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2434]);
    } else {
        ++(vlSymsp->__Vcoverage[2435]);
    }
    if (vlSelfRef.rampart_i2c__DOT__host_timeout_event) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00004000U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2440]);
    } else {
        ++(vlSymsp->__Vcoverage[2441]);
    }
    if (vlSelfRef.rampart_i2c__DOT__host_arb_lost) {
        vlSelfRef.rampart_i2c__DOT__intr_hw_set = (0x00008000U 
                                                   | (IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set));
        ++(vlSymsp->__Vcoverage[2442]);
    } else {
        ++(vlSymsp->__Vcoverage[2443]);
    }
    if (((1U >= (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_level)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable))) {
        ++(vlSymsp->__Vcoverage[2389]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable)))) {
        ++(vlSymsp->__Vcoverage[2390]);
    }
    if ((1U < (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_level))) {
        ++(vlSymsp->__Vcoverage[2391]);
    }
    if (((1U <= (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_level)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable))) {
        ++(vlSymsp->__Vcoverage[2394]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_host_enable)))) {
        ++(vlSymsp->__Vcoverage[2395]);
    }
    if ((1U > (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_level))) {
        ++(vlSymsp->__Vcoverage[2396]);
    }
    if (((1U <= (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_level)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        ++(vlSymsp->__Vcoverage[2399]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable)))) {
        ++(vlSymsp->__Vcoverage[2400]);
    }
    if ((1U > (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_level))) {
        ++(vlSymsp->__Vcoverage[2401]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__host_timeout_event))) {
        ++(vlSymsp->__Vcoverage[2412]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_timeout_event)))) {
        ++(vlSymsp->__Vcoverage[2413]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tgt_stretch_needed)))) {
        ++(vlSymsp->__Vcoverage[2414]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_empty) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        ++(vlSymsp->__Vcoverage[2421]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable)))) {
        ++(vlSymsp->__Vcoverage[2422]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_empty)))) {
        ++(vlSymsp->__Vcoverage[2423]);
    }
    if (((1U >= (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_level)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        ++(vlSymsp->__Vcoverage[2426]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable)))) {
        ++(vlSymsp->__Vcoverage[2427]);
    }
    if ((1U < (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_level))) {
        ++(vlSymsp->__Vcoverage[2428]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_full) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        ++(vlSymsp->__Vcoverage[2431]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable)))) {
        ++(vlSymsp->__Vcoverage[2432]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_full)))) {
        ++(vlSymsp->__Vcoverage[2433]);
    }
    if ((((IData)(vlSelfRef.rampart_i2c__DOT__stop_det) 
          & (IData)(vlSelfRef.rampart_i2c__DOT__tgt_addr_match)) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable))) {
        ++(vlSymsp->__Vcoverage[2436]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__ctrl_target_enable)))) {
        ++(vlSymsp->__Vcoverage[2437]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tgt_addr_match)))) {
        ++(vlSymsp->__Vcoverage[2438]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__stop_det)))) {
        ++(vlSymsp->__Vcoverage[2439]);
    }
    ++(vlSymsp->__Vcoverage[2444]);
    if ((vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata ^ vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_rsp_rdata)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 1648, vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_rsp_rdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_rsp_rdata 
            = vlSelfRef.rampart_i2c__DOT__tl_rsp_rdata;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tl_rsp_error) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_rsp_error))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1712, vlSelfRef.rampart_i2c__DOT__tl_rsp_error, vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_rsp_error);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tl_rsp_error 
            = vlSelfRef.rampart_i2c__DOT__tl_rsp_error;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_wdata) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_wdata))) {
        VL_COV_TOGGLE_CHG_ST_I(13, vlSymsp->__Vcoverage + 916, vlSelfRef.rampart_i2c__DOT__fmt_fifo_wdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_wdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_wdata 
            = vlSelfRef.rampart_i2c__DOT__fmt_fifo_wdata;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_pop) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_pop))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1016, vlSelfRef.rampart_i2c__DOT__rx_fifo_pop, vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_pop);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__rx_fifo_pop 
            = vlSelfRef.rampart_i2c__DOT__rx_fifo_pop;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_wdata) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_wdata))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 1100, vlSelfRef.rampart_i2c__DOT__tx_fifo_wdata, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_wdata);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_wdata 
            = vlSelfRef.rampart_i2c__DOT__tx_fifo_wdata;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__acq_fifo_pop) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_pop))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1180, vlSelfRef.rampart_i2c__DOT__acq_fifo_pop, vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_pop);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__acq_fifo_pop 
            = vlSelfRef.rampart_i2c__DOT__acq_fifo_pop;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_push) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_push))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 912, vlSelfRef.rampart_i2c__DOT__fmt_fifo_push, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_push);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_fifo_push 
            = vlSelfRef.rampart_i2c__DOT__fmt_fifo_push;
    }
    vlSelfRef.rampart_i2c__DOT__fmt_overflow_det = 
        ((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_full) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_push));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_push) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_push))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1096, vlSelfRef.rampart_i2c__DOT__tx_fifo_push, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_push);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_fifo_push 
            = vlSelfRef.rampart_i2c__DOT__tx_fifo_push;
    }
    vlSelfRef.rampart_i2c__DOT__tx_overflow_det = ((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_full) 
                                                   & (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_push));
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_push) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_full))) {
        ++(vlSymsp->__Vcoverage[2365]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_full)))) {
        ++(vlSymsp->__Vcoverage[2366]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_push)))) {
        ++(vlSymsp->__Vcoverage[2367]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_push) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_full))) {
        ++(vlSymsp->__Vcoverage[2368]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_full)))) {
        ++(vlSymsp->__Vcoverage[2369]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__rx_fifo_push)))) {
        ++(vlSymsp->__Vcoverage[2370]);
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_push) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_full))) {
        ++(vlSymsp->__Vcoverage[2371]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_full)))) {
        ++(vlSymsp->__Vcoverage[2372]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__tx_fifo_push)))) {
        ++(vlSymsp->__Vcoverage[2373]);
    }
    if ((((((5U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
            & (IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done)) 
           & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_scl_drive_low))) 
          & (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)) 
         & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_nakok)))) {
        ++(vlSymsp->__Vcoverage[2374]);
    }
    if ((((((3U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
            & (IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done)) 
           & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_scl_drive_low))) 
          & (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)) 
         & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_cmd_nakok)))) {
        ++(vlSymsp->__Vcoverage[2375]);
    }
    if (vlSelfRef.rampart_i2c__DOT__host_cmd_nakok) {
        ++(vlSymsp->__Vcoverage[2376]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__sda_in_q)))) {
        ++(vlSymsp->__Vcoverage[2377]);
    }
    if (vlSelfRef.rampart_i2c__DOT__host_scl_drive_low) {
        ++(vlSymsp->__Vcoverage[2378]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done)))) {
        ++(vlSymsp->__Vcoverage[2379]);
    }
    if (((3U != (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
         & (5U != (IData)(vlSelfRef.rampart_i2c__DOT__host_state)))) {
        ++(vlSymsp->__Vcoverage[2380]);
    }
    if (((((0U != (IData)(vlSelfRef.rampart_i2c__DOT__host_state)) 
           & (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty)) 
          & (0x0aU == (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) 
         & (IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done))) {
        ++(vlSymsp->__Vcoverage[2381]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__host_timing_done)))) {
        ++(vlSymsp->__Vcoverage[2382]);
    }
    if ((0x0aU != (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
        ++(vlSymsp->__Vcoverage[2383]);
    }
    if ((1U & (~ (IData)(vlSelfRef.rampart_i2c__DOT__fmt_fifo_empty)))) {
        ++(vlSymsp->__Vcoverage[2384]);
    }
    if ((0U == (IData)(vlSelfRef.rampart_i2c__DOT__host_state))) {
        ++(vlSymsp->__Vcoverage[2385]);
    }
    ++(vlSymsp->__Vcoverage[2386]);
    if (((IData)(vlSelfRef.rampart_i2c__DOT__scl_in) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_in))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1230, vlSelfRef.rampart_i2c__DOT__scl_in, vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_in);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__scl_in 
            = vlSelfRef.rampart_i2c__DOT__scl_in;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__sda_in) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_in))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 1232, vlSelfRef.rampart_i2c__DOT__sda_in, vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_in);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__sda_in 
            = vlSelfRef.rampart_i2c__DOT__sda_in;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__intr_hw_set) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_hw_set))) {
        VL_COV_TOGGLE_CHG_ST_I(16, vlSymsp->__Vcoverage + 834, vlSelfRef.rampart_i2c__DOT__intr_hw_set, vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_hw_set);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__intr_hw_set 
            = vlSelfRef.rampart_i2c__DOT__intr_hw_set;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__fmt_overflow_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_overflow_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2355, vlSelfRef.rampart_i2c__DOT__fmt_overflow_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_overflow_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__fmt_overflow_det 
            = vlSelfRef.rampart_i2c__DOT__fmt_overflow_det;
    }
    if (((IData)(vlSelfRef.rampart_i2c__DOT__tx_overflow_det) 
         ^ (IData)(vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_overflow_det))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2359, vlSelfRef.rampart_i2c__DOT__tx_overflow_det, vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_overflow_det);
        vlSelfRef.rampart_i2c__DOT____Vtogcov__tx_overflow_det 
            = vlSelfRef.rampart_i2c__DOT__tx_overflow_det;
    }
}

void Vtop___024root___eval_nba(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_nba\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((3ULL & vlSelfRef.__VnbaTriggered[0U])) {
        Vtop___024root___nba_sequent__TOP__0(vlSelf);
    }
}

void Vtop___024root___trigger_orInto__act_vec_vec(VlUnpacked<QData/*63:0*/, 1> &out, const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___trigger_orInto__act_vec_vec\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        out[n] = (out[n] | in[n]);
        n = ((IData)(1U) + n);
    } while ((0U >= n));
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtop___024root___dump_triggers__act(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG

bool Vtop___024root___eval_phase__act(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_phase__act\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    Vtop___024root___eval_triggers_vec__act(vlSelf);
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vtop___024root___dump_triggers__act(vlSelfRef.__VactTriggered, "act"s);
    }
#endif
    Vtop___024root___trigger_orInto__act_vec_vec(vlSelfRef.__VnbaTriggered, vlSelfRef.__VactTriggered);
    return (0U);
}

void Vtop___024root___trigger_clear__act(VlUnpacked<QData/*63:0*/, 1> &out) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___trigger_clear__act\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        out[n] = 0ULL;
        n = ((IData)(1U) + n);
    } while ((1U > n));
}

bool Vtop___024root___eval_phase__nba(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_phase__nba\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = Vtop___024root___trigger_anySet__act(vlSelfRef.__VnbaTriggered);
    if (__VnbaExecute) {
        Vtop___024root___eval_nba(vlSelf);
        Vtop___024root___trigger_clear__act(vlSelfRef.__VnbaTriggered);
    }
    return (__VnbaExecute);
}

void Vtop___024root___eval(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __VicoIterCount;
    IData/*31:0*/ __VnbaIterCount;
    // Body
    __VicoIterCount = 0U;
    vlSelfRef.__VicoFirstIteration = 1U;
    do {
        if (VL_UNLIKELY(((0x00000064U < __VicoIterCount)))) {
#ifdef VL_DEBUG
            Vtop___024root___dump_triggers__ico(vlSelfRef.__VicoTriggered, "ico"s);
#endif
            VL_FATAL_MT("/home/abdulbasit/electrical-and-electronics-engineering/VLSI/isqed-2026-dv-challenge/submissions/task-2.1/submission-2.1/baseline_runner/../../../../duts/rampart_i2c/rampart_i2c.sv", 1, "", "DIDNOTCONVERGE: Input combinational region did not converge after '--converge-limit' of 100 tries");
        }
        __VicoIterCount = ((IData)(1U) + __VicoIterCount);
        vlSelfRef.__VicoPhaseResult = Vtop___024root___eval_phase__ico(vlSelf);
        vlSelfRef.__VicoFirstIteration = 0U;
    } while (vlSelfRef.__VicoPhaseResult);
    __VnbaIterCount = 0U;
    do {
        if (VL_UNLIKELY(((0x00000064U < __VnbaIterCount)))) {
#ifdef VL_DEBUG
            Vtop___024root___dump_triggers__act(vlSelfRef.__VnbaTriggered, "nba"s);
#endif
            VL_FATAL_MT("/home/abdulbasit/electrical-and-electronics-engineering/VLSI/isqed-2026-dv-challenge/submissions/task-2.1/submission-2.1/baseline_runner/../../../../duts/rampart_i2c/rampart_i2c.sv", 1, "", "DIDNOTCONVERGE: NBA region did not converge after '--converge-limit' of 100 tries");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        vlSelfRef.__VactIterCount = 0U;
        do {
            if (VL_UNLIKELY(((0x00000064U < vlSelfRef.__VactIterCount)))) {
#ifdef VL_DEBUG
                Vtop___024root___dump_triggers__act(vlSelfRef.__VactTriggered, "act"s);
#endif
                VL_FATAL_MT("/home/abdulbasit/electrical-and-electronics-engineering/VLSI/isqed-2026-dv-challenge/submissions/task-2.1/submission-2.1/baseline_runner/../../../../duts/rampart_i2c/rampart_i2c.sv", 1, "", "DIDNOTCONVERGE: Active region did not converge after '--converge-limit' of 100 tries");
            }
            vlSelfRef.__VactIterCount = ((IData)(1U) 
                                         + vlSelfRef.__VactIterCount);
            vlSelfRef.__VactPhaseResult = Vtop___024root___eval_phase__act(vlSelf);
        } while (vlSelfRef.__VactPhaseResult);
        vlSelfRef.__VnbaPhaseResult = Vtop___024root___eval_phase__nba(vlSelf);
    } while (vlSelfRef.__VnbaPhaseResult);
}

#ifdef VL_DEBUG
void Vtop___024root___eval_debug_assertions(Vtop___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_debug_assertions\n"); );
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (VL_UNLIKELY(((vlSelfRef.clk_i & 0xfeU)))) {
        Verilated::overWidthError("clk_i");
    }
    if (VL_UNLIKELY(((vlSelfRef.rst_ni & 0xfeU)))) {
        Verilated::overWidthError("rst_ni");
    }
    if (VL_UNLIKELY(((vlSelfRef.tl_a_valid_i & 0xfeU)))) {
        Verilated::overWidthError("tl_a_valid_i");
    }
    if (VL_UNLIKELY(((vlSelfRef.tl_a_opcode_i & 0xf8U)))) {
        Verilated::overWidthError("tl_a_opcode_i");
    }
    if (VL_UNLIKELY(((vlSelfRef.tl_a_mask_i & 0xf0U)))) {
        Verilated::overWidthError("tl_a_mask_i");
    }
    if (VL_UNLIKELY(((vlSelfRef.tl_a_size_i & 0xfcU)))) {
        Verilated::overWidthError("tl_a_size_i");
    }
    if (VL_UNLIKELY(((vlSelfRef.tl_d_ready_i & 0xfeU)))) {
        Verilated::overWidthError("tl_d_ready_i");
    }
    if (VL_UNLIKELY(((vlSelfRef.scl_i & 0xfeU)))) {
        Verilated::overWidthError("scl_i");
    }
    if (VL_UNLIKELY(((vlSelfRef.sda_i & 0xfeU)))) {
        Verilated::overWidthError("sda_i");
    }
}
#endif  // VL_DEBUG
