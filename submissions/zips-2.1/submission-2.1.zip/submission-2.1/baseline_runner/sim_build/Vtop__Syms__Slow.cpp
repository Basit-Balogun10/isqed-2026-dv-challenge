// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table implementation internals

#include "Vtop__pch.h"

Vtop__Syms::Vtop__Syms(VerilatedContext* contextp, const char* namep, Vtop* modelp)
    : VerilatedSyms{contextp}
    // Setup internal state of the Syms class
    , __Vm_modelp{modelp}
    // Setup top module instance
    , TOP{this, namep}
{
    // Check resources
    Verilated::stackCheck(374);
    // Setup sub module instances
    TOP__dv_common_pkg.ctor(this, "dv_common_pkg");
    // Configure time unit / time precision
    _vm_contextp__->timeunit(-9);
    _vm_contextp__->timeprecision(-12);
    // Setup each module's pointers to their submodules
    TOP.__PVT__dv_common_pkg = &TOP__dv_common_pkg;
    // Setup each module's pointer back to symbol table (for public functions)
    TOP.__Vconfigure(true);
    TOP__dv_common_pkg.__Vconfigure(true);
    // Setup scopes
    __Vscopep_TOP = new VerilatedScope{this, "TOP", "TOP", "<null>", 0, VerilatedScope::SCOPE_OTHER};
    __Vscopep_dv_common_pkg = new VerilatedScope{this, "dv_common_pkg", "dv_common_pkg", "dv_common_pkg", -9, VerilatedScope::SCOPE_PACKAGE};
    __Vscopep_rampart_i2c = new VerilatedScope{this, "rampart_i2c", "rampart_i2c", "rampart_i2c", -9, VerilatedScope::SCOPE_MODULE};
    // Set up scope hierarchy
    __Vhier.add(0, __Vscopep_dv_common_pkg);
    __Vhier.add(0, __Vscopep_rampart_i2c);
    // Setup export functions - final: 0
    // Setup export functions - final: 1
    // Setup public variables
    __Vscopep_TOP->varInsert("alert_o", &(TOP.alert_o), false, VLVT_UINT8, VLVD_OUT|VLVF_PUB_RW|VLVF_CONTINUOUSLY, 0, 0);
    __Vscopep_TOP->varInsert("clk_i", &(TOP.clk_i), false, VLVT_UINT8, VLVD_IN|VLVF_PUB_RW, 0, 0);
    __Vscopep_TOP->varInsert("intr_o", &(TOP.intr_o), false, VLVT_UINT16, VLVD_OUT|VLVF_PUB_RW, 0, 1 ,15,0);
    __Vscopep_TOP->varInsert("rst_ni", &(TOP.rst_ni), false, VLVT_UINT8, VLVD_IN|VLVF_PUB_RW, 0, 0);
    __Vscopep_TOP->varInsert("scl_i", &(TOP.scl_i), false, VLVT_UINT8, VLVD_IN|VLVF_PUB_RW, 0, 0);
    __Vscopep_TOP->varInsert("scl_o", &(TOP.scl_o), false, VLVT_UINT8, VLVD_OUT|VLVF_PUB_RW|VLVF_CONTINUOUSLY, 0, 0);
    __Vscopep_TOP->varInsert("scl_oe_o", &(TOP.scl_oe_o), false, VLVT_UINT8, VLVD_OUT|VLVF_PUB_RW, 0, 0);
    __Vscopep_TOP->varInsert("sda_i", &(TOP.sda_i), false, VLVT_UINT8, VLVD_IN|VLVF_PUB_RW, 0, 0);
    __Vscopep_TOP->varInsert("sda_o", &(TOP.sda_o), false, VLVT_UINT8, VLVD_OUT|VLVF_PUB_RW|VLVF_CONTINUOUSLY, 0, 0);
    __Vscopep_TOP->varInsert("sda_oe_o", &(TOP.sda_oe_o), false, VLVT_UINT8, VLVD_OUT|VLVF_PUB_RW, 0, 0);
    __Vscopep_TOP->varInsert("tl_a_address_i", &(TOP.tl_a_address_i), false, VLVT_UINT32, VLVD_IN|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_TOP->varInsert("tl_a_data_i", &(TOP.tl_a_data_i), false, VLVT_UINT32, VLVD_IN|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_TOP->varInsert("tl_a_mask_i", &(TOP.tl_a_mask_i), false, VLVT_UINT8, VLVD_IN|VLVF_PUB_RW, 0, 1 ,3,0);
    __Vscopep_TOP->varInsert("tl_a_opcode_i", &(TOP.tl_a_opcode_i), false, VLVT_UINT8, VLVD_IN|VLVF_PUB_RW, 0, 1 ,2,0);
    __Vscopep_TOP->varInsert("tl_a_ready_o", &(TOP.tl_a_ready_o), false, VLVT_UINT8, VLVD_OUT|VLVF_PUB_RW, 0, 0);
    __Vscopep_TOP->varInsert("tl_a_size_i", &(TOP.tl_a_size_i), false, VLVT_UINT8, VLVD_IN|VLVF_PUB_RW, 0, 1 ,1,0);
    __Vscopep_TOP->varInsert("tl_a_source_i", &(TOP.tl_a_source_i), false, VLVT_UINT8, VLVD_IN|VLVF_PUB_RW, 0, 1 ,7,0);
    __Vscopep_TOP->varInsert("tl_a_valid_i", &(TOP.tl_a_valid_i), false, VLVT_UINT8, VLVD_IN|VLVF_PUB_RW, 0, 0);
    __Vscopep_TOP->varInsert("tl_d_data_o", &(TOP.tl_d_data_o), false, VLVT_UINT32, VLVD_OUT|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_TOP->varInsert("tl_d_error_o", &(TOP.tl_d_error_o), false, VLVT_UINT8, VLVD_OUT|VLVF_PUB_RW, 0, 0);
    __Vscopep_TOP->varInsert("tl_d_opcode_o", &(TOP.tl_d_opcode_o), false, VLVT_UINT8, VLVD_OUT|VLVF_PUB_RW, 0, 1 ,2,0);
    __Vscopep_TOP->varInsert("tl_d_ready_i", &(TOP.tl_d_ready_i), false, VLVT_UINT8, VLVD_IN|VLVF_PUB_RW, 0, 0);
    __Vscopep_TOP->varInsert("tl_d_source_o", &(TOP.tl_d_source_o), false, VLVT_UINT8, VLVD_OUT|VLVF_PUB_RW, 0, 1 ,7,0);
    __Vscopep_TOP->varInsert("tl_d_valid_o", &(TOP.tl_d_valid_o), false, VLVT_UINT8, VLVD_OUT|VLVF_PUB_RW, 0, 0);
    __Vscopep_dv_common_pkg->varInsert("TL_OP_ACCESS_ACK", const_cast<void*>(static_cast<const void*>(&(TOP__dv_common_pkg.TL_OP_ACCESS_ACK))), true, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,2,0);
    __Vscopep_dv_common_pkg->varInsert("TL_OP_ACCESS_ACK_DATA", const_cast<void*>(static_cast<const void*>(&(TOP__dv_common_pkg.TL_OP_ACCESS_ACK_DATA))), true, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,2,0);
    __Vscopep_dv_common_pkg->varInsert("TL_OP_GET", const_cast<void*>(static_cast<const void*>(&(TOP__dv_common_pkg.TL_OP_GET))), true, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,2,0);
    __Vscopep_dv_common_pkg->varInsert("TL_OP_PUT_FULL", const_cast<void*>(static_cast<const void*>(&(TOP__dv_common_pkg.TL_OP_PUT_FULL))), true, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,2,0);
    __Vscopep_dv_common_pkg->varInsert("TL_OP_PUT_PARTIAL", const_cast<void*>(static_cast<const void*>(&(TOP__dv_common_pkg.TL_OP_PUT_PARTIAL))), true, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,2,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_ACQDATA", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_ACQDATA))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_CTRL", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_CTRL))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_FDATA", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_FDATA))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_FIFO_CTRL", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_FIFO_CTRL))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_FIFO_STATUS", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_FIFO_STATUS))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_HOST_TIMEOUT_CTRL", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_HOST_TIMEOUT_CTRL))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_INTR_ENABLE", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_INTR_ENABLE))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_INTR_STATE", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_INTR_STATE))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_INTR_TEST", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_INTR_TEST))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_OVRD", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_OVRD))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_RDATA", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_RDATA))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_STATUS", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_STATUS))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_TARGET_ID", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_TARGET_ID))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_TIMING0", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_TIMING0))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_TIMING1", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_TIMING1))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_TIMING2", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_TIMING2))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_TIMING3", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_TIMING3))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_TIMING4", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_TIMING4))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ADDR_TXDATA", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__ADDR_TXDATA))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("FIFO_AW", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__FIFO_AW))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW|VLVF_DPI_CLAY, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("FIFO_DEPTH", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__FIFO_DEPTH))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW|VLVF_DPI_CLAY, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("NUM_IRQS", const_cast<void*>(static_cast<const void*>(&(TOP.rampart_i2c__DOT__NUM_IRQS))), true, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW|VLVF_DPI_CLAY, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("acq_fifo_empty", &(TOP.rampart_i2c__DOT__acq_fifo_empty), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("acq_fifo_full", &(TOP.rampart_i2c__DOT__acq_fifo_full), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("acq_fifo_level", &(TOP.rampart_i2c__DOT__acq_fifo_level), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,6,0);
    __Vscopep_rampart_i2c->varInsert("acq_fifo_mem", &(TOP.rampart_i2c__DOT__acq_fifo_mem), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 1, 1 ,0,63 ,9,0);
    __Vscopep_rampart_i2c->varInsert("acq_fifo_pop", &(TOP.rampart_i2c__DOT__acq_fifo_pop), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("acq_fifo_push", &(TOP.rampart_i2c__DOT__acq_fifo_push), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("acq_fifo_rdata", &(TOP.rampart_i2c__DOT__acq_fifo_rdata), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,9,0);
    __Vscopep_rampart_i2c->varInsert("acq_fifo_wdata", &(TOP.rampart_i2c__DOT__acq_fifo_wdata), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,9,0);
    __Vscopep_rampart_i2c->varInsert("acq_rptr", &(TOP.rampart_i2c__DOT__acq_rptr), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,6,0);
    __Vscopep_rampart_i2c->varInsert("acq_wptr", &(TOP.rampart_i2c__DOT__acq_wptr), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,6,0);
    __Vscopep_rampart_i2c->varInsert("alert_o", &(TOP.rampart_i2c__DOT__alert_o), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW|VLVF_CONTINUOUSLY, 0, 0);
    __Vscopep_rampart_i2c->varInsert("bus_active", &(TOP.rampart_i2c__DOT__bus_active), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("clk_i", &(TOP.rampart_i2c__DOT__clk_i), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("ctrl_host_enable", &(TOP.rampart_i2c__DOT__ctrl_host_enable), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("ctrl_line_loopback", &(TOP.rampart_i2c__DOT__ctrl_line_loopback), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("ctrl_reg", &(TOP.rampart_i2c__DOT__ctrl_reg), false, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("ctrl_target_enable", &(TOP.rampart_i2c__DOT__ctrl_target_enable), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("fifo_ctrl_acq_rst", &(TOP.rampart_i2c__DOT__fifo_ctrl_acq_rst), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("fifo_ctrl_fmt_rst", &(TOP.rampart_i2c__DOT__fifo_ctrl_fmt_rst), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("fifo_ctrl_rx_rst", &(TOP.rampart_i2c__DOT__fifo_ctrl_rx_rst), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("fifo_ctrl_tx_rst", &(TOP.rampart_i2c__DOT__fifo_ctrl_tx_rst), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("fmt_fifo_empty", &(TOP.rampart_i2c__DOT__fmt_fifo_empty), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("fmt_fifo_full", &(TOP.rampart_i2c__DOT__fmt_fifo_full), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("fmt_fifo_level", &(TOP.rampart_i2c__DOT__fmt_fifo_level), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,6,0);
    __Vscopep_rampart_i2c->varInsert("fmt_fifo_mem", &(TOP.rampart_i2c__DOT__fmt_fifo_mem), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 1, 1 ,0,63 ,12,0);
    __Vscopep_rampart_i2c->varInsert("fmt_fifo_pop", &(TOP.rampart_i2c__DOT__fmt_fifo_pop), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW|VLVF_CONTINUOUSLY, 0, 0);
    __Vscopep_rampart_i2c->varInsert("fmt_fifo_push", &(TOP.rampart_i2c__DOT__fmt_fifo_push), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("fmt_fifo_rdata", &(TOP.rampart_i2c__DOT__fmt_fifo_rdata), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,12,0);
    __Vscopep_rampart_i2c->varInsert("fmt_fifo_wdata", &(TOP.rampart_i2c__DOT__fmt_fifo_wdata), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,12,0);
    __Vscopep_rampart_i2c->varInsert("fmt_overflow_det", &(TOP.rampart_i2c__DOT__fmt_overflow_det), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("fmt_pop_req", &(TOP.rampart_i2c__DOT__fmt_pop_req), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("fmt_rptr", &(TOP.rampart_i2c__DOT__fmt_rptr), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,6,0);
    __Vscopep_rampart_i2c->varInsert("fmt_wptr", &(TOP.rampart_i2c__DOT__fmt_wptr), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,6,0);
    __Vscopep_rampart_i2c->varInsert("host_ack_received", &(TOP.rampart_i2c__DOT__host_ack_received), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("host_arb_lost", &(TOP.rampart_i2c__DOT__host_arb_lost), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("host_bit_idx", &(TOP.rampart_i2c__DOT__host_bit_idx), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,3,0);
    __Vscopep_rampart_i2c->varInsert("host_cmd_byte", &(TOP.rampart_i2c__DOT__host_cmd_byte), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,7,0);
    __Vscopep_rampart_i2c->varInsert("host_cmd_nakok", &(TOP.rampart_i2c__DOT__host_cmd_nakok), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("host_cmd_rcont", &(TOP.rampart_i2c__DOT__host_cmd_rcont), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("host_cmd_readb", &(TOP.rampart_i2c__DOT__host_cmd_readb), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("host_cmd_start", &(TOP.rampart_i2c__DOT__host_cmd_start), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("host_cmd_stop", &(TOP.rampart_i2c__DOT__host_cmd_stop), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("host_read_byte_cnt", &(TOP.rampart_i2c__DOT__host_read_byte_cnt), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,7,0);
    __Vscopep_rampart_i2c->varInsert("host_read_rcont", &(TOP.rampart_i2c__DOT__host_read_rcont), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("host_read_shift", &(TOP.rampart_i2c__DOT__host_read_shift), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,7,0);
    __Vscopep_rampart_i2c->varInsert("host_read_stop", &(TOP.rampart_i2c__DOT__host_read_stop), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("host_scl_drive_low", &(TOP.rampart_i2c__DOT__host_scl_drive_low), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("host_scl_oe", &(TOP.rampart_i2c__DOT__host_scl_oe), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW|VLVF_CONTINUOUSLY, 0, 0);
    __Vscopep_rampart_i2c->varInsert("host_sda_drive_low", &(TOP.rampart_i2c__DOT__host_sda_drive_low), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("host_sda_oe", &(TOP.rampart_i2c__DOT__host_sda_oe), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW|VLVF_CONTINUOUSLY, 0, 0);
    __Vscopep_rampart_i2c->varInsert("host_shift_reg", &(TOP.rampart_i2c__DOT__host_shift_reg), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,7,0);
    __Vscopep_rampart_i2c->varInsert("host_state", &(TOP.rampart_i2c__DOT__host_state), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,3,0);
    __Vscopep_rampart_i2c->varInsert("host_timeout_cnt", &(TOP.rampart_i2c__DOT__host_timeout_cnt), false, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,19,0);
    __Vscopep_rampart_i2c->varInsert("host_timeout_en", &(TOP.rampart_i2c__DOT__host_timeout_en), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("host_timeout_event", &(TOP.rampart_i2c__DOT__host_timeout_event), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("host_timeout_val", &(TOP.rampart_i2c__DOT__host_timeout_val), false, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,19,0);
    __Vscopep_rampart_i2c->varInsert("host_timing_cnt", &(TOP.rampart_i2c__DOT__host_timing_cnt), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,15,0);
    __Vscopep_rampart_i2c->varInsert("host_timing_done", &(TOP.rampart_i2c__DOT__host_timing_done), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("intr_enable", &(TOP.rampart_i2c__DOT__intr_enable), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,15,0);
    __Vscopep_rampart_i2c->varInsert("intr_hw_set", &(TOP.rampart_i2c__DOT__intr_hw_set), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,15,0);
    __Vscopep_rampart_i2c->varInsert("intr_o", &(TOP.rampart_i2c__DOT__intr_o), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,15,0);
    __Vscopep_rampart_i2c->varInsert("intr_state", &(TOP.rampart_i2c__DOT__intr_state), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,15,0);
    __Vscopep_rampart_i2c->varInsert("nak_det", &(TOP.rampart_i2c__DOT__nak_det), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("ovrd_sclval", &(TOP.rampart_i2c__DOT__ovrd_sclval), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("ovrd_sdaval", &(TOP.rampart_i2c__DOT__ovrd_sdaval), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("ovrd_txovrden", &(TOP.rampart_i2c__DOT__ovrd_txovrden), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("rst_ni", &(TOP.rampart_i2c__DOT__rst_ni), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("rx_fifo_empty", &(TOP.rampart_i2c__DOT__rx_fifo_empty), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("rx_fifo_full", &(TOP.rampart_i2c__DOT__rx_fifo_full), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("rx_fifo_level", &(TOP.rampart_i2c__DOT__rx_fifo_level), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,6,0);
    __Vscopep_rampart_i2c->varInsert("rx_fifo_mem", &(TOP.rampart_i2c__DOT__rx_fifo_mem), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 1, 1 ,0,63 ,7,0);
    __Vscopep_rampart_i2c->varInsert("rx_fifo_pop", &(TOP.rampart_i2c__DOT__rx_fifo_pop), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("rx_fifo_push", &(TOP.rampart_i2c__DOT__rx_fifo_push), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW|VLVF_CONTINUOUSLY, 0, 0);
    __Vscopep_rampart_i2c->varInsert("rx_fifo_rdata", &(TOP.rampart_i2c__DOT__rx_fifo_rdata), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,7,0);
    __Vscopep_rampart_i2c->varInsert("rx_fifo_wdata", &(TOP.rampart_i2c__DOT__rx_fifo_wdata), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW|VLVF_CONTINUOUSLY, 0, 1 ,7,0);
    __Vscopep_rampart_i2c->varInsert("rx_overflow_det", &(TOP.rampart_i2c__DOT__rx_overflow_det), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("rx_push_data", &(TOP.rampart_i2c__DOT__rx_push_data), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,7,0);
    __Vscopep_rampart_i2c->varInsert("rx_push_valid", &(TOP.rampart_i2c__DOT__rx_push_valid), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("rx_rptr", &(TOP.rampart_i2c__DOT__rx_rptr), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,6,0);
    __Vscopep_rampart_i2c->varInsert("rx_wptr", &(TOP.rampart_i2c__DOT__rx_wptr), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,6,0);
    __Vscopep_rampart_i2c->varInsert("scl_falling", &(TOP.rampart_i2c__DOT__scl_falling), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("scl_i", &(TOP.rampart_i2c__DOT__scl_i), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("scl_in", &(TOP.rampart_i2c__DOT__scl_in), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("scl_in_q", &(TOP.rampart_i2c__DOT__scl_in_q), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("scl_in_qq", &(TOP.rampart_i2c__DOT__scl_in_qq), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("scl_interference_det", &(TOP.rampart_i2c__DOT__scl_interference_det), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("scl_o", &(TOP.rampart_i2c__DOT__scl_o), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW|VLVF_CONTINUOUSLY, 0, 0);
    __Vscopep_rampart_i2c->varInsert("scl_oe_o", &(TOP.rampart_i2c__DOT__scl_oe_o), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("scl_rising", &(TOP.rampart_i2c__DOT__scl_rising), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("sda_falling", &(TOP.rampart_i2c__DOT__sda_falling), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("sda_i", &(TOP.rampart_i2c__DOT__sda_i), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("sda_in", &(TOP.rampart_i2c__DOT__sda_in), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("sda_in_q", &(TOP.rampart_i2c__DOT__sda_in_q), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("sda_in_qq", &(TOP.rampart_i2c__DOT__sda_in_qq), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("sda_interference_det", &(TOP.rampart_i2c__DOT__sda_interference_det), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("sda_o", &(TOP.rampart_i2c__DOT__sda_o), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW|VLVF_CONTINUOUSLY, 0, 0);
    __Vscopep_rampart_i2c->varInsert("sda_oe_o", &(TOP.rampart_i2c__DOT__sda_oe_o), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("sda_rising", &(TOP.rampart_i2c__DOT__sda_rising), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("sda_unstable_det", &(TOP.rampart_i2c__DOT__sda_unstable_det), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("start_det", &(TOP.rampart_i2c__DOT__start_det), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("stop_det", &(TOP.rampart_i2c__DOT__stop_det), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("target_address", &(TOP.rampart_i2c__DOT__target_address), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,6,0);
    __Vscopep_rampart_i2c->varInsert("target_mask", &(TOP.rampart_i2c__DOT__target_mask), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,6,0);
    __Vscopep_rampart_i2c->varInsert("tgt_addr_match", &(TOP.rampart_i2c__DOT__tgt_addr_match), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tgt_addr_shift", &(TOP.rampart_i2c__DOT__tgt_addr_shift), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,6,0);
    __Vscopep_rampart_i2c->varInsert("tgt_bit_idx", &(TOP.rampart_i2c__DOT__tgt_bit_idx), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,3,0);
    __Vscopep_rampart_i2c->varInsert("tgt_rw_bit", &(TOP.rampart_i2c__DOT__tgt_rw_bit), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tgt_rx_shift", &(TOP.rampart_i2c__DOT__tgt_rx_shift), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,7,0);
    __Vscopep_rampart_i2c->varInsert("tgt_scl_drive_low", &(TOP.rampart_i2c__DOT__tgt_scl_drive_low), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tgt_scl_oe", &(TOP.rampart_i2c__DOT__tgt_scl_oe), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW|VLVF_CONTINUOUSLY, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tgt_sda_drive_low", &(TOP.rampart_i2c__DOT__tgt_sda_drive_low), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tgt_sda_oe", &(TOP.rampart_i2c__DOT__tgt_sda_oe), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW|VLVF_CONTINUOUSLY, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tgt_state", &(TOP.rampart_i2c__DOT__tgt_state), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,3,0);
    __Vscopep_rampart_i2c->varInsert("tgt_stretch_needed", &(TOP.rampart_i2c__DOT__tgt_stretch_needed), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tgt_tx_shift", &(TOP.rampart_i2c__DOT__tgt_tx_shift), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,7,0);
    __Vscopep_rampart_i2c->varInsert("timing_t_buf", &(TOP.rampart_i2c__DOT__timing_t_buf), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,15,0);
    __Vscopep_rampart_i2c->varInsert("timing_t_f", &(TOP.rampart_i2c__DOT__timing_t_f), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,15,0);
    __Vscopep_rampart_i2c->varInsert("timing_t_r", &(TOP.rampart_i2c__DOT__timing_t_r), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,15,0);
    __Vscopep_rampart_i2c->varInsert("timing_thd_dat", &(TOP.rampart_i2c__DOT__timing_thd_dat), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,15,0);
    __Vscopep_rampart_i2c->varInsert("timing_thd_sta", &(TOP.rampart_i2c__DOT__timing_thd_sta), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,15,0);
    __Vscopep_rampart_i2c->varInsert("timing_thigh", &(TOP.rampart_i2c__DOT__timing_thigh), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,15,0);
    __Vscopep_rampart_i2c->varInsert("timing_tlow", &(TOP.rampart_i2c__DOT__timing_tlow), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,15,0);
    __Vscopep_rampart_i2c->varInsert("timing_tsu_dat", &(TOP.rampart_i2c__DOT__timing_tsu_dat), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,15,0);
    __Vscopep_rampart_i2c->varInsert("timing_tsu_sta", &(TOP.rampart_i2c__DOT__timing_tsu_sta), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,15,0);
    __Vscopep_rampart_i2c->varInsert("timing_tsu_sto", &(TOP.rampart_i2c__DOT__timing_tsu_sto), false, VLVT_UINT16, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,15,0);
    __Vscopep_rampart_i2c->varInsert("tl_a_address_i", &(TOP.rampart_i2c__DOT__tl_a_address_i), false, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("tl_a_data_i", &(TOP.rampart_i2c__DOT__tl_a_data_i), false, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("tl_a_mask_i", &(TOP.rampart_i2c__DOT__tl_a_mask_i), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,3,0);
    __Vscopep_rampart_i2c->varInsert("tl_a_opcode_i", &(TOP.rampart_i2c__DOT__tl_a_opcode_i), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,2,0);
    __Vscopep_rampart_i2c->varInsert("tl_a_ready_o", &(TOP.rampart_i2c__DOT__tl_a_ready_o), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tl_a_size_i", &(TOP.rampart_i2c__DOT__tl_a_size_i), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,1,0);
    __Vscopep_rampart_i2c->varInsert("tl_a_source_i", &(TOP.rampart_i2c__DOT__tl_a_source_i), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,7,0);
    __Vscopep_rampart_i2c->varInsert("tl_a_valid_i", &(TOP.rampart_i2c__DOT__tl_a_valid_i), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tl_d_data_o", &(TOP.rampart_i2c__DOT__tl_d_data_o), false, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("tl_d_error_o", &(TOP.rampart_i2c__DOT__tl_d_error_o), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tl_d_opcode_o", &(TOP.rampart_i2c__DOT__tl_d_opcode_o), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,2,0);
    __Vscopep_rampart_i2c->varInsert("tl_d_ready_i", &(TOP.rampart_i2c__DOT__tl_d_ready_i), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tl_d_source_o", &(TOP.rampart_i2c__DOT__tl_d_source_o), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,7,0);
    __Vscopep_rampart_i2c->varInsert("tl_d_valid_o", &(TOP.rampart_i2c__DOT__tl_d_valid_o), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tl_req_addr", &(TOP.rampart_i2c__DOT__tl_req_addr), false, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("tl_req_mask", &(TOP.rampart_i2c__DOT__tl_req_mask), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,3,0);
    __Vscopep_rampart_i2c->varInsert("tl_req_source", &(TOP.rampart_i2c__DOT__tl_req_source), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,7,0);
    __Vscopep_rampart_i2c->varInsert("tl_req_valid", &(TOP.rampart_i2c__DOT__tl_req_valid), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tl_req_wdata", &(TOP.rampart_i2c__DOT__tl_req_wdata), false, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("tl_req_write", &(TOP.rampart_i2c__DOT__tl_req_write), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tl_rsp_error", &(TOP.rampart_i2c__DOT__tl_rsp_error), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tl_rsp_pending", &(TOP.rampart_i2c__DOT__tl_rsp_pending), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tl_rsp_rdata", &(TOP.rampart_i2c__DOT__tl_rsp_rdata), false, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,31,0);
    __Vscopep_rampart_i2c->varInsert("trans_complete_det", &(TOP.rampart_i2c__DOT__trans_complete_det), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tx_fifo_empty", &(TOP.rampart_i2c__DOT__tx_fifo_empty), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tx_fifo_full", &(TOP.rampart_i2c__DOT__tx_fifo_full), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tx_fifo_level", &(TOP.rampart_i2c__DOT__tx_fifo_level), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,6,0);
    __Vscopep_rampart_i2c->varInsert("tx_fifo_mem", &(TOP.rampart_i2c__DOT__tx_fifo_mem), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 1, 1 ,0,63 ,7,0);
    __Vscopep_rampart_i2c->varInsert("tx_fifo_pop", &(TOP.rampart_i2c__DOT__tx_fifo_pop), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tx_fifo_push", &(TOP.rampart_i2c__DOT__tx_fifo_push), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tx_fifo_rdata", &(TOP.rampart_i2c__DOT__tx_fifo_rdata), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,7,0);
    __Vscopep_rampart_i2c->varInsert("tx_fifo_wdata", &(TOP.rampart_i2c__DOT__tx_fifo_wdata), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,7,0);
    __Vscopep_rampart_i2c->varInsert("tx_overflow_det", &(TOP.rampart_i2c__DOT__tx_overflow_det), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 0);
    __Vscopep_rampart_i2c->varInsert("tx_rptr", &(TOP.rampart_i2c__DOT__tx_rptr), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,6,0);
    __Vscopep_rampart_i2c->varInsert("tx_wptr", &(TOP.rampart_i2c__DOT__tx_wptr), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RW, 0, 1 ,6,0);
}

Vtop__Syms::~Vtop__Syms() {
    // Tear down scope hierarchy
    __Vhier.remove(0, __Vscopep_dv_common_pkg);
    __Vhier.remove(0, __Vscopep_rampart_i2c);
    // Clear keys from hierarchy map after values have been removed
    __Vhier.clear();
    // Tear down scopes
    VL_DO_CLEAR(delete __Vscopep_TOP, __Vscopep_TOP = nullptr);
    VL_DO_CLEAR(delete __Vscopep_dv_common_pkg, __Vscopep_dv_common_pkg = nullptr);
    VL_DO_CLEAR(delete __Vscopep_rampart_i2c, __Vscopep_rampart_i2c = nullptr);
    // Tear down sub module instances
    TOP__dv_common_pkg.dtor();
}
