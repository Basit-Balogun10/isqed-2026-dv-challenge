// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Model implementation (design independent parts)

#include "Vtop__pch.h"

//============================================================
// Constructors

Vtop::Vtop(VerilatedContext* _vcontextp__, const char* _vcname__)
    : VerilatedModel{*_vcontextp__}
    , vlSymsp{new Vtop__Syms(contextp(), _vcname__, this)}
    , clk_i{vlSymsp->TOP.clk_i}
    , rst_ni{vlSymsp->TOP.rst_ni}
    , tl_a_valid_i{vlSymsp->TOP.tl_a_valid_i}
    , tl_a_ready_o{vlSymsp->TOP.tl_a_ready_o}
    , tl_a_opcode_i{vlSymsp->TOP.tl_a_opcode_i}
    , tl_a_mask_i{vlSymsp->TOP.tl_a_mask_i}
    , tl_a_source_i{vlSymsp->TOP.tl_a_source_i}
    , tl_a_size_i{vlSymsp->TOP.tl_a_size_i}
    , tl_d_valid_o{vlSymsp->TOP.tl_d_valid_o}
    , tl_d_ready_i{vlSymsp->TOP.tl_d_ready_i}
    , tl_d_opcode_o{vlSymsp->TOP.tl_d_opcode_o}
    , tl_d_source_o{vlSymsp->TOP.tl_d_source_o}
    , tl_d_error_o{vlSymsp->TOP.tl_d_error_o}
    , scl_i{vlSymsp->TOP.scl_i}
    , scl_o{vlSymsp->TOP.scl_o}
    , scl_oe_o{vlSymsp->TOP.scl_oe_o}
    , sda_i{vlSymsp->TOP.sda_i}
    , sda_o{vlSymsp->TOP.sda_o}
    , sda_oe_o{vlSymsp->TOP.sda_oe_o}
    , alert_o{vlSymsp->TOP.alert_o}
    , intr_o{vlSymsp->TOP.intr_o}
    , tl_a_address_i{vlSymsp->TOP.tl_a_address_i}
    , tl_a_data_i{vlSymsp->TOP.tl_a_data_i}
    , tl_d_data_o{vlSymsp->TOP.tl_d_data_o}
    , __PVT__dv_common_pkg{vlSymsp->TOP.__PVT__dv_common_pkg}
    , rootp{&(vlSymsp->TOP)}
{
    // Register model with the context
    contextp()->addModel(this);
}

Vtop::Vtop(const char* _vcname__)
    : Vtop(Verilated::threadContextp(), _vcname__)
{
}

//============================================================
// Destructor

Vtop::~Vtop() {
    delete vlSymsp;
}

//============================================================
// Evaluation function

#ifdef VL_DEBUG
void Vtop___024root___eval_debug_assertions(Vtop___024root* vlSelf);
#endif  // VL_DEBUG
void Vtop___024root___eval_static(Vtop___024root* vlSelf);
void Vtop___024root___eval_initial(Vtop___024root* vlSelf);
void Vtop___024root___eval_settle(Vtop___024root* vlSelf);
void Vtop___024root___eval(Vtop___024root* vlSelf);

void Vtop::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vtop::eval_step\n"); );
#ifdef VL_DEBUG
    // Debug assertions
    Vtop___024root___eval_debug_assertions(&(vlSymsp->TOP));
#endif  // VL_DEBUG
    vlSymsp->__Vm_deleter.deleteAll();
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) {
        VL_DEBUG_IF(VL_DBG_MSGF("+ Initial\n"););
        Vtop___024root___eval_static(&(vlSymsp->TOP));
        Vtop___024root___eval_initial(&(vlSymsp->TOP));
        Vtop___024root___eval_settle(&(vlSymsp->TOP));
        vlSymsp->__Vm_didInit = true;
    }
    VL_DEBUG_IF(VL_DBG_MSGF("+ Eval\n"););
    Vtop___024root___eval(&(vlSymsp->TOP));
    // Evaluate cleanup
    Verilated::endOfEval(vlSymsp->__Vm_evalMsgQp);
}

//============================================================
// Events and timing
bool Vtop::eventsPending() { return false; }

uint64_t Vtop::nextTimeSlot() {
    VL_FATAL_MT(__FILE__, __LINE__, "", "No delays in the design");
    return 0;
}

//============================================================
// Utilities

const char* Vtop::name() const {
    return vlSymsp->name();
}

//============================================================
// Invoke final blocks

void Vtop___024root___eval_final(Vtop___024root* vlSelf);

VL_ATTR_COLD void Vtop::final() {
    Vtop___024root___eval_final(&(vlSymsp->TOP));
}

//============================================================
// Implementations of abstract methods from VerilatedModel

const char* Vtop::hierName() const { return vlSymsp->name(); }
const char* Vtop::modelName() const { return "Vtop"; }
unsigned Vtop::threads() const { return 1; }
void Vtop::prepareClone() const { contextp()->prepareClone(); }
void Vtop::atClone() const {
    contextp()->threadPoolpOnClone();
}
