// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtop.h for the primary calling header

#include "Vtop__pch.h"

// Parameter definitions for Vtop___024root
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__FIFO_DEPTH;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__FIFO_AW;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__NUM_IRQS;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_CTRL;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_STATUS;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_RDATA;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_FDATA;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_FIFO_CTRL;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_FIFO_STATUS;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_OVRD;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_TIMING0;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_TIMING1;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_TIMING2;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_TIMING3;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_TIMING4;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_TARGET_ID;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_ACQDATA;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_TXDATA;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_HOST_TIMEOUT_CTRL;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_INTR_STATE;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_INTR_ENABLE;
constexpr IData/*31:0*/ Vtop___024root::rampart_i2c__DOT__ADDR_INTR_TEST;


void Vtop___024root___ctor_var_reset(Vtop___024root* vlSelf);

Vtop___024root::Vtop___024root(Vtop__Syms* symsp, const char* namep)
 {
    vlSymsp = symsp;
    vlNamep = strdup(namep);
    // Reset structure values
    Vtop___024root___ctor_var_reset(this);
}

void Vtop___024root___configure_coverage(Vtop___024root* vlSelf, bool first);

void Vtop___024root::__Vconfigure(bool first) {
    (void)first;  // Prevent unused variable warning
    Vtop___024root___configure_coverage(this, first);
}

Vtop___024root::~Vtop___024root() {
    VL_DO_DANGLING(std::free(const_cast<char*>(vlNamep)), vlNamep);
}

// Coverage
void Vtop___024root::__vlCoverInsert(uint32_t* countp, bool enable, const char* filenamep, int lineno, int column,
    const char* hierp, const char* pagep, const char* commentp, const char* linescovp) {
    uint32_t* count32p = countp;
    static uint32_t fake_zero_count = 0;
    std::string fullhier = std::string{vlNamep} + hierp;
    if (!fullhier.empty() && fullhier[0] == '.') fullhier = fullhier.substr(1);
    if (!enable) count32p = &fake_zero_count;
    *count32p = 0;
    VL_COVER_INSERT(vlSymsp->_vm_contextp__->coveragep(), vlNamep, count32p,  "filename",filenamep,  "lineno",lineno,  "column",column,
        "hier",fullhier,  "page",pagep,  "comment",commentp,  (linescovp[0] ? "linescov" : ""), linescovp);
}

// Toggle Coverage
void Vtop___024root::__vlCoverToggleInsert(int begin, int end, bool ranged, uint32_t* countp, bool enable, const char* filenamep, int lineno, int column,
    const char* hierp, const char* pagep, const char* commentp) {
    int step = (end >= begin) ? 1 : -1;
    for (int i = begin; i != end + step; i += step) {
        for (int j = 0; j < 2; j++) {
            uint32_t* count32p = countp;
            static uint32_t fake_zero_count = 0;
            std::string fullhier = std::string{vlNamep} + hierp;
            if (!fullhier.empty() && fullhier[0] == '.') fullhier = fullhier.substr(1);
            std::string commentWithIndex = commentp;
            if (ranged) commentWithIndex += '[' + std::to_string(i) + ']';
            commentWithIndex += j ? ":0->1" : ":1->0";
            if (!enable) count32p = &fake_zero_count;
            *count32p = 0;
            VL_COVER_INSERT(vlSymsp->_vm_contextp__->coveragep(), vlNamep, count32p,  "filename",filenamep,  "lineno",lineno,  "column",column,
                "hier",fullhier,  "page",pagep,  "comment",commentWithIndex.c_str(),  "", "");
            ++countp;
        }
    }
}
