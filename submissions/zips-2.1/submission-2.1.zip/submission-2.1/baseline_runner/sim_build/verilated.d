verilated.o: /home/abdulbasit/open-source/verilator/include/verilated.cpp \
 /home/abdulbasit/open-source/verilator/include/verilated_config.h \
 /home/abdulbasit/open-source/verilator/include/verilatedos.h \
 /home/abdulbasit/open-source/verilator/include/verilated_imp.h \
 /home/abdulbasit/open-source/verilator/include/verilated.h \
 /home/abdulbasit/open-source/verilator/include/verilated_types.h \
 /home/abdulbasit/open-source/verilator/include/verilated_funcs.h \
 /home/abdulbasit/open-source/verilator/include/verilated_syms.h \
 /home/abdulbasit/open-source/verilator/include/verilated_sym_props.h \
 /home/abdulbasit/open-source/verilator/include/verilated_threads.h \
 /home/abdulbasit/open-source/verilator/include/verilated_trace.h \
 /home/abdulbasit/open-source/verilator/include/verilatedos_c.h
