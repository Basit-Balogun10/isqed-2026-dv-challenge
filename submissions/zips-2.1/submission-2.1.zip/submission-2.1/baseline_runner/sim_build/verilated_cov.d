verilated_cov.o: \
 /home/abdulbasit/open-source/verilator/include/verilated_cov.cpp \
 /home/abdulbasit/open-source/verilator/include/verilatedos.h \
 /home/abdulbasit/open-source/verilator/include/verilated_cov.h \
 /home/abdulbasit/open-source/verilator/include/verilated.h \
 /home/abdulbasit/open-source/verilator/include/verilated_config.h \
 /home/abdulbasit/open-source/verilator/include/verilated_types.h \
 /home/abdulbasit/open-source/verilator/include/verilated_funcs.h \
 /home/abdulbasit/open-source/verilator/include/verilated_cov_key.h
