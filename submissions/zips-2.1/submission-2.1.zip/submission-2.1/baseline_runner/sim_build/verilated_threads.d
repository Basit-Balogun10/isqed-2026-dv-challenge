verilated_threads.o: \
 /home/abdulbasit/open-source/verilator/include/verilated_threads.cpp \
 /home/abdulbasit/open-source/verilator/include/verilatedos.h \
 /home/abdulbasit/open-source/verilator/include/verilated_threads.h \
 /home/abdulbasit/open-source/verilator/include/verilated.h \
 /home/abdulbasit/open-source/verilator/include/verilated_config.h \
 /home/abdulbasit/open-source/verilator/include/verilated_types.h \
 /home/abdulbasit/open-source/verilator/include/verilated_funcs.h
